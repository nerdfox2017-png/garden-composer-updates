"""
app.py — Garden Infographic Composer GUI (macOS / Windows / Linux)
Построен на customtkinter. Поддерживает Gemini и ChatGPT.
"""

from __future__ import annotations

import json
import os
import queue
import signal
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

# ── Настройка stdout/stderr до импорта customtkinter ────────────────────────
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

import customtkinter as ctk
from tkinter import filedialog, messagebox
import tkinter as tk

import config
from compositor import compose
from image_fetcher import fetch_image
from keyword_extractor import extract_keywords
from transcriber import transcribe
from utils import ensure_dirs, sanitize_filename

# ── Тема ────────────────────────────────────────────────────────────────────
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("green")

APP_TITLE   = "🌱 Garden Infographic Composer"
APP_VERSION = "1.1"
WIN_W, WIN_H = 1100, 720


# ─────────────────────────────────────────────────────────────────────────────
# Вспомогательные утилиты
# ─────────────────────────────────────────────────────────────────────────────

def _storyboard_path(input_path: str) -> str:
    base = os.path.splitext(os.path.basename(input_path))[0]
    return os.path.join(config.CACHE_DIR, f"{base}_storyboard.json")


def _save_storyboard(segments: list[dict[str, Any]], input_path: str) -> None:
    ensure_dirs(config.CACHE_DIR)
    path = _storyboard_path(input_path)
    data = [
        {
            "index":      i,
            "start":      s["start"],
            "end":        s["end"],
            "text":       s["text"],
            "show_image": s.get("show_image", False),
            "prompt":     s.get("prompt", ""),
            "image_path": s.get("image_path"),
            "ok":         bool(s.get("image_path") and os.path.isfile(str(s.get("image_path", "")))),
        }
        for i, s in enumerate(segments)
    ]
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def _load_storyboard(input_path: str) -> list[dict[str, Any]] | None:
    path = _storyboard_path(input_path)
    if not os.path.isfile(path):
        return None
    with open(path, encoding="utf-8") as f:
        return json.load(f)


_INFOGRAPHIC_MARKERS = (
    "white background",
    "infographic",
    "educational labeled",
    "labeled diagram",
)
_NATURE_MARKERS = (
    "professional garden photography",
    "garden photography",
)

def _is_infographic_prompt(prompt: str) -> bool:
    """True если промпт — инфографика (белый фон, диаграммы). False — фото природы."""
    low = prompt.lower()
    return any(m in low for m in _INFOGRAPHIC_MARKERS)


def _fetch_all_images(
    segments: list[dict[str, Any]],
    mode: str,
    engine: str,          # FastGen-движок для инфографик (NARWHAL / GEM_PIX_2 / …)
    log_q: queue.Queue,
    progress_cb=None,
    progress_start: float = 0.0,
    progress_end: float = 1.0,
    pexels_mix_enabled: bool = False,
    pexels_mix_ratio: float = 0.0,
    img_source: str = "FastGen",  # "FastGen" | "Pexels" — источник для фото природы
) -> list[dict[str, Any]]:
    import random as _random
    tasks: dict[int, tuple[str, str]] = {}
    for idx, seg in enumerate(segments):
        if not seg.get("show_image"):
            continue
        # Видеоклипы не требуют генерации изображения
        if seg.get("_is_video_clip"):
            continue
        existing = seg.get("image_path")
        if existing and os.path.isfile(str(existing)):
            continue
        prompt = seg.get("prompt") or ""
        if not prompt:
            continue
        # Включаем idx чтобы плакаты с одинаковым началом промпта не коллидировали
        cache_key = f"seg{idx:03d}_{sanitize_filename(prompt)[:60]}"
        tasks[idx] = (prompt, cache_key)

    if not tasks:
        already = sum(1 for s in segments if s.get("image_path") and os.path.isfile(str(s.get("image_path", ""))))
        log_q.put(f"[main] Все изображения уже в кэше ({already} шт.)")
        if progress_cb:
            progress_cb(progress_end)
        return segments

    # Слоты для Pexels-микса (только среди фото природы, не инфографик)
    pexels_mix_indices: set[int] = set()
    has_pexels_key = bool(config.PEXELS_API_KEY)
    if pexels_mix_enabled and pexels_mix_ratio > 0 and has_pexels_key:
        nature_idx = [i for i, (p, _) in tasks.items() if not _is_infographic_prompt(p)]
        n_pexels = max(1, round(len(nature_idx) * pexels_mix_ratio))
        pexels_mix_indices = set(_random.sample(nature_idx, min(n_pexels, len(nature_idx))))

    def _engine_for(idx: int, prompt: str) -> str:
        seg = segments[idx] if idx < len(segments) else {}
        # Если слот явно помечен как Pexels-фото — всегда Pexels
        if seg.get("_pexels_photo"):
            return "PEXELS" if has_pexels_key else engine
        # Инфографика ВСЕГДА через FastGen
        if _is_infographic_prompt(prompt):
            return engine
        # Фото природы — Pexels если: основной источник Pexels ИЛИ попал в микс
        if has_pexels_key and (img_source == "Pexels" or idx in pexels_mix_indices):
            return "PEXELS"
        return engine

    total = len(tasks)
    eng_counts: dict[str, int] = {}
    for idx, (prompt, _) in tasks.items():
        e = _engine_for(idx, prompt)
        eng_counts[e] = eng_counts.get(e, 0) + 1
    parts = [f"{cnt} {e}" for e, cnt in sorted(eng_counts.items())]
    log_q.put(f"[main] Получаю {total} изображений: {', '.join(parts)}...")

    idx_to_path: dict[int, str | None] = {}
    with ThreadPoolExecutor(max_workers=config.IMAGE_FETCH_WORKERS) as ex:
        futures = {
            ex.submit(fetch_image, prompt, mode, _engine_for(idx, prompt), cache_key): idx
            for idx, (prompt, cache_key) in tasks.items()
        }
        done = 0
        for future in as_completed(futures):
            seg_idx = futures[future]
            done += 1
            try:
                path = future.result()
            except Exception as exc:
                path = None
                log_q.put(f"  [!] Ошибка изображения seg {seg_idx}: {exc}")
            idx_to_path[seg_idx] = path
            status = "✓" if path else "✗"
            log_q.put(f"  [{done}/{total}] seg {seg_idx}: {status}")
            # Прогресс пошагово: каждое изображение двигает бар
            if progress_cb:
                pct = progress_start + (progress_end - progress_start) * done / total
                progress_cb(pct)

    for seg in segments:
        seg.setdefault("image_path", None)
    for idx, path in idx_to_path.items():
        segments[idx]["image_path"] = path

    found  = sum(1 for p in idx_to_path.values() if p)
    failed = total - found
    log_q.put(f"[main] Получено: {found}/{total}" + (f", не удалось: {failed}" if failed else ""))
    return segments


# ─────────────────────────────────────────────────────────────────────────────
# Zone Editor Canvas
# ─────────────────────────────────────────────────────────────────────────────

class ZoneCanvas(tk.Canvas):
    """Холст для рисования зон оверлея (до 4 прямоугольников).
    Фоном служит кадр из выбранного видео.

    Архитектура:
    • _bg_item  — ОДИН постоянный canvas item для фона. Никогда не удаляется —
                  только обновляется через itemconfig(image=...). Это устраняет
                  серый мигающий кадр на macOS.
    • zone_rect — прямоугольники зон (stipple="gray25" = ~25% заполнение).
                  Удаляются/создаются только при изменении zones, не во время drag.
    • zone_num  — текстовые метки номеров зон.
    • _preview_id — прямоугольник drag-превью. Обновляется через coords() (не delete/create).
    """
    MAX_ZONES = 4
    COLORS    = ["#e74c3c", "#3498db", "#2ecc71", "#f39c12"]

    def __init__(self, master, **kwargs):
        kwargs.setdefault("bg", "#1a1a1a")
        kwargs.setdefault("cursor", "crosshair")
        super().__init__(master, **kwargs)

        self.zones: list[list[float]] = []   # пусто = полный экран (дефолт)
        self._drag_start: tuple | None = None
        self._dragging   = False

        self._bg_pil   = None   # PIL.Image — кадр видео
        self._bg_photo = None   # PhotoImage (удерживает от GC)
        self._bg_item  = None   # canvas item ID — создаётся один раз, потом itemconfig

        self._preview_id: int | None = None

        # Смещение и размер отображаемого видео внутри canvas (letterbox)
        self._img_ox: int = 0
        self._img_oy: int = 0
        self._img_w:  int = 0
        self._img_h:  int = 0

        self.bind("<ButtonPress-1>",   self._on_press)
        self.bind("<B1-Motion>",       self._on_drag)
        self.bind("<ButtonRelease-1>", self._on_release)
        self.bind("<Configure>",       self._on_resize)

        self._draw_hint()

    # ── Вспомогательные ──────────────────────────────────────────────────────

    def _cw(self) -> int:
        v = self.winfo_width()
        return v if v > 10 else 640

    def _ch(self) -> int:
        v = self.winfo_height()
        return v if v > 10 else 360

    def _norm_to_canvas(self, nx: float, ny: float) -> tuple[float, float]:
        """Нормализованные координаты (0..1) → координаты canvas с учётом letterbox."""
        if self._img_w > 0 and self._img_h > 0:
            return (self._img_ox + nx * self._img_w,
                    self._img_oy + ny * self._img_h)
        return nx * self._cw(), ny * self._ch()

    def _canvas_to_norm(self, cx: float, cy: float) -> tuple[float, float]:
        """Координаты canvas → нормализованные (0..1) относительно видео."""
        if self._img_w > 0 and self._img_h > 0:
            nx = (cx - self._img_ox) / self._img_w
            ny = (cy - self._img_oy) / self._img_h
            return max(0.0, min(1.0, nx)), max(0.0, min(1.0, ny))
        return cx / max(self._cw(), 1), cy / max(self._ch(), 1)

    def _draw_hint(self):
        self.delete("hint")
        self.create_text(
            10, 10, anchor="nw", tags="hint",
            text="Выберите видео — здесь появится его кадр.\n"
                 "Нарисуйте зоны (до 4) для инфографик.\n"
                 "Если зон нет — инфографика занимает весь экран (по умолчанию).",
            fill="#888888", font=("Helvetica", 11))

    # ── Фон: обновляется БЕЗ удаления canvas item ────────────────────────────

    def _update_background(self):
        """Обновляет только фоновое изображение через itemconfig — без delete."""
        if self._dragging:
            return
        try:
            from PIL import Image as _Img, ImageTk as _ImgTk
        except ImportError:
            return

        cw, ch = self._cw(), self._ch()

        if self._bg_pil is not None:
            self.delete("hint")
            img = self._bg_pil.copy().convert("RGB")
            img.thumbnail((cw, ch), _Img.LANCZOS)
            canvas_img = _Img.new("RGB", (cw, ch), (26, 26, 26))
            ox = (cw - img.width)  // 2
            oy = (ch - img.height) // 2
            canvas_img.paste(img, (ox, oy))
            # Сохраняем геометрию видео для правильного маппинга зон
            self._img_ox = ox
            self._img_oy = oy
            self._img_w  = img.width
            self._img_h  = img.height
        else:
            canvas_img = _Img.new("RGB", (cw, ch), (26, 26, 26))
            self._img_ox = 0
            self._img_oy = 0
            self._img_w  = cw
            self._img_h  = ch

        # Создаём PhotoImage перед обновлением canvas item (старый держим до swap)
        new_photo = _ImgTk.PhotoImage(canvas_img)

        if self._bg_item is None:
            # Первый раз — создаём item
            self._bg_photo = new_photo
            self._bg_item  = self.create_image(0, 0, anchor="nw", image=self._bg_photo)
        else:
            # Обновляем существующий item — без delete, без мигания
            self._bg_photo = new_photo
            self.itemconfig(self._bg_item, image=self._bg_photo)

        self.tag_lower(self._bg_item)   # всегда снизу

    # ── Зоны: прямоугольники поверх фона ─────────────────────────────────────

    def _update_zones(self):
        """Удаляет и заново рисует зоны. Не трогает фон."""
        if self._dragging:
            return
        self.delete("zone_rect")
        self.delete("zone_num")

        for i, zone in enumerate(self.zones):
            color = self.COLORS[i % len(self.COLORS)]
            cx0, cy0 = self._norm_to_canvas(zone[0], zone[1])
            cx1, cy1 = self._norm_to_canvas(zone[0] + zone[2], zone[1] + zone[3])

            # Полупрозрачная заливка через stipple (показывает фон насквозь)
            self.create_rectangle(cx0, cy0, cx1, cy1,
                                  fill=color, stipple="gray25",
                                  outline=color, width=3,
                                  tags="zone_rect")

            # Номер зоны с тенью
            mx, my = (cx0 + cx1) / 2, (cy0 + cy1) / 2
            self.create_text(mx + 2, my + 2, text=str(i + 1),
                             fill="#000000", font=("Helvetica", 40, "bold"),
                             tags="zone_num")
            self.create_text(mx, my, text=str(i + 1),
                             fill="white", font=("Helvetica", 40, "bold"),
                             tags="zone_num")

        if not self.zones and self._bg_pil is None:
            self._draw_hint()

    # ── Публичный API ─────────────────────────────────────────────────────────

    def set_background_image(self, pil_img):
        """Устанавливает кадр видео как фон. Повторяет через 400 и 900 мс на
        случай если вкладка ещё не отображена (winfo_width возвращает 1)."""
        self._bg_pil = pil_img
        self._update_background()
        self._update_zones()
        self.after(400, lambda: (self._update_background(), self._update_zones()))
        self.after(900, lambda: (self._update_background(), self._update_zones()))

    def _full_redraw(self):
        """Полная перерисовка: фон + зоны."""
        self._update_background()
        self._update_zones()

    def clear_zones(self):
        self.zones.clear()
        self._update_zones()
        if self._bg_pil is None:
            self._draw_hint()

    def load_zones(self, zones: list):
        self.zones = [list(z) for z in zones]
        self.after(100, self._update_zones)

    # ── Resize ────────────────────────────────────────────────────────────────

    def _on_resize(self, event=None):
        if not self._dragging:
            self._update_background()
            self._update_zones()

    # ── Drag & Drop ───────────────────────────────────────────────────────────

    def _on_press(self, event):
        if len(self.zones) >= self.MAX_ZONES:
            messagebox.showinfo("Зоны", f"Максимум {self.MAX_ZONES} зоны. Нажмите «Очистить».")
            return
        self._drag_start = (event.x, event.y)
        self._dragging   = True

    def _on_drag(self, event):
        if not self._drag_start:
            return
        x0, y0 = self._drag_start
        x1, y1 = event.x, event.y
        rx0, ry0 = min(x0, x1), min(y0, y1)
        rx1, ry1 = max(x0, x1), max(y0, y1)
        color = self.COLORS[len(self.zones) % len(self.COLORS)]

        if self._preview_id:
            # coords() — никакого delete/create, никакого мигания
            self.coords(self._preview_id, rx0, ry0, rx1, ry1)
            self.tag_raise(self._preview_id)
        else:
            self._preview_id = self.create_rectangle(
                rx0, ry0, rx1, ry1,
                outline=color, width=3, dash=(6, 3))

    def _on_release(self, event):
        if not self._drag_start:
            return
        x0, y0 = self._drag_start
        x1, y1 = event.x, event.y
        self._drag_start = None

        if self._preview_id:
            self.delete(self._preview_id)
            self._preview_id = None

        self._dragging = False

        # Игнорируем слишком маленькую зону (< 5%)
        if abs(x1 - x0) < self._cw() * 0.05 or abs(y1 - y0) < self._ch() * 0.05:
            return

        nx0, ny0 = self._canvas_to_norm(min(x0, x1), min(y0, y1))
        nx1, ny1 = self._canvas_to_norm(max(x0, x1), max(y0, y1))
        self.zones.append([nx0, ny0, nx1 - nx0, ny1 - ny0])
        self._update_zones()   # обновляем только зоны, фон не трогаем


# ─────────────────────────────────────────────────────────────────────────────
# Кастомный прогресс-бар: градиент + текст процентов
# ─────────────────────────────────────────────────────────────────────────────

class GradientProgressBar(tk.Canvas):
    """
    Прогресс-бар на PIL-canvas:
      • горизонтальный градиент от яркого зелёного к тёмно-зелёному
      • процент по центру белым текстом
      • скруглённые углы (pill-форма)
    """
    _C_BG     = "#1a1a1a"   # фон незаполненной части
    _C_START  = "#2ecc71"   # левый край (яркий зелёный)
    _C_END    = "#145a32"   # правый край (тёмно-зелёный)
    _C_BORDER = "#2d6a2d"   # обводка
    _C_TEXT   = "#ffffff"   # текст на заполненной части
    _C_TEXT0  = "#555555"   # текст на пустой части

    # Системные шрифты по порядку приоритета (macOS / Windows / Linux)
    _FONT_CANDIDATES = [
        "/System/Library/Fonts/Helvetica.ttc",
        "/System/Library/Fonts/SFNS.ttf",
        "C:/Windows/Fonts/arialbd.ttf",
        "C:/Windows/Fonts/arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]

    def __init__(self, master, height: int = 26, **kw):
        # Определяем цвет фона родителя чтобы Canvas не давал белую рамку
        try:
            parent_bg = master.cget("fg_color")
            if isinstance(parent_bg, (list, tuple)):
                parent_bg = parent_bg[1]          # тёмная тема
        except Exception:
            parent_bg = "#2b2b2b"

        super().__init__(master, height=height,
                         bg=parent_bg,
                         highlightthickness=0, bd=0, **kw)
        self._h      = height
        self._value  = 0.0
        self._photo  = None   # держим ссылку — иначе GC уберёт
        self._font   = None   # PIL ImageFont, загружается лениво
        self.bind("<Configure>", lambda _e: self._redraw())

    # ── Публичный API (совместим с CTkProgressBar) ───────────────────────────

    def set(self, value: float) -> None:
        self._value = max(0.0, min(1.0, float(value)))
        self._redraw()

    def get(self) -> float:
        return self._value

    # ── Внутренние методы ────────────────────────────────────────────────────

    @staticmethod
    def _hex_to_rgb(h: str) -> tuple[int, int, int]:
        h = h.lstrip("#")
        return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)

    @staticmethod
    def _lerp(a: int, b: int, t: float) -> int:
        return int(a + (b - a) * t)

    def _get_font(self, size: int = 12):
        """Загружает PIL-шрифт один раз, кэширует."""
        if self._font is not None:
            return self._font
        try:
            from PIL import ImageFont
            for path in self._FONT_CANDIDATES:
                if os.path.isfile(path):
                    self._font = ImageFont.truetype(path, size)
                    return self._font
        except Exception:
            pass
        try:
            from PIL import ImageFont
            self._font = ImageFont.load_default()
        except Exception:
            self._font = None
        return self._font

    def _redraw(self) -> None:
        try:
            self._redraw_impl()
        except Exception as exc:
            # Любая ошибка PIL — молча рисуем простой запасной бар через Canvas
            print(f"[GradientProgressBar] render error: {exc}")
            self._redraw_fallback()

    def _redraw_fallback(self) -> None:
        """Простой бар без PIL — на случай если PIL недоступен или устарел."""
        self.delete("all")
        w = self.winfo_width()
        h = self.winfo_height() or self._h
        if w < 2:
            return
        r = min(4, h // 2)
        # Фон
        self.create_rectangle(0, 0, w, h, fill="#1a1a1a", outline="#2d6a2d")
        # Заливка
        fill_w = int(w * self._value)
        if fill_w > 1:
            self.create_rectangle(0, 0, fill_w, h, fill="#2ecc71", outline="")
        # Текст
        pct = int(self._value * 100)
        tc  = "#ffffff" if self._value > 0.08 else "#555555"
        self.create_text(w // 2, h // 2, text=f"{pct}%", fill=tc,
                         font=("Helvetica", 11, "bold"))

    _RADIUS = 6   # скругление совпадает с corner_radius остальных CTk-элементов

    def _redraw_impl(self) -> None:
        try:
            from PIL import Image as _Img, ImageDraw as _Draw, ImageTk as _ITk
        except ImportError:
            self._redraw_fallback()
            return

        w = self.winfo_width()
        h = self.winfo_height() or self._h
        if w < 4 or h < 4:
            return

        # ── Рендерим в 2× для сглаживания краёв, потом уменьшаем LANCZOS ─────
        S  = 2                        # коэффициент суперсэмплинга
        W2 = w * S
        H2 = h * S
        R2 = self._RADIUS * S

        img2 = _Img.new("RGBA", (W2, H2), (0, 0, 0, 0))
        d2   = _Draw.Draw(img2)

        _rr = getattr(d2, "rounded_rectangle", None)

        def rr(xy, r, **kw):
            if _rr:
                _rr(xy, radius=r, **kw)
            else:
                d2.rectangle(xy, **kw)

        # Фон
        rr([0, 0, W2 - 1, H2 - 1], R2,
           fill=self._hex_to_rgb(self._C_BG) + (255,))

        # ── Градиентная заливка ───────────────────────────────────────────────
        fill_w2 = max(0, int(W2 * self._value))
        if fill_w2 > 1:
            c1 = self._hex_to_rgb(self._C_START)
            c2 = self._hex_to_rgb(self._C_END)

            # Строка градиента 1px высотой → растягиваем до H2
            gl  = _Img.new("RGB", (fill_w2, 1))
            px  = gl.load()
            for x in range(fill_w2):
                t = x / max(fill_w2 - 1, 1)
                px[x, 0] = (self._lerp(c1[0], c2[0], t),
                             self._lerp(c1[1], c2[1], t),
                             self._lerp(c1[2], c2[2], t))
            grad = gl.resize((fill_w2, H2), _Img.NEAREST)

            # Маска — размер совпадает с grad
            mk = _Img.new("L", (fill_w2, H2), 0)
            md = _Draw.Draw(mk)
            if _rr:
                md.rounded_rectangle([0, 0, fill_w2 - 1, H2 - 1], radius=R2, fill=255)
            else:
                md.rectangle([0, 0, fill_w2 - 1, H2 - 1], fill=255)
            img2.paste(grad.convert("RGBA"), (0, 0), mk)

        # Обводка
        rr([0, 0, W2 - 1, H2 - 1], R2,
           outline=self._hex_to_rgb(self._C_BORDER) + (140,), width=S)

        # Уменьшаем до итогового размера — LANCZOS сглаживает края
        img = img2.resize((w, h), _Img.LANCZOS)

        # ── Текст поверх итогового изображения ───────────────────────────────
        draw = _Draw.Draw(img)
        pct  = int(self._value * 100)
        txt  = f"{pct}%"
        font = self._get_font(size=max(10, h - 6))

        tc = (self._hex_to_rgb(self._C_TEXT)  + (230,)
              if self._value > 0.08
              else self._hex_to_rgb(self._C_TEXT0) + (200,))

        try:
            bbox = draw.textbbox((0, 0), txt, font=font)
            tw   = bbox[2] - bbox[0]
            th   = bbox[3] - bbox[1]
            ty   = (h - th) // 2 - bbox[1]
        except Exception:
            tw, th, ty = len(txt) * 7, h - 4, 2

        draw.text(((w - tw) // 2, ty), txt, fill=tc, font=font)

        # ── Отображаем ────────────────────────────────────────────────────────
        self._photo = _ITk.PhotoImage(img)
        self.delete("all")
        self.create_image(0, 0, anchor="nw", image=self._photo)


# ─────────────────────────────────────────────────────────────────────────────
# Главное приложение
# ─────────────────────────────────────────────────────────────────────────────

class GardenApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_TITLE}  v{APP_VERSION}")
        self.geometry(f"{WIN_W}x{WIN_H}")
        self.minsize(900, 600)

        self._log_q: queue.Queue = queue.Queue()
        self._worker: threading.Thread | None = None
        self._running = False
        self._output_path: str | None = None

        self._build_ui()
        self._load_settings_to_ui()
        self._poll_log()
        # Слушаем изменение пути к видео — обновляем превью в Zone Editor
        self._video_path_var.trace_add("write", self._on_video_path_changed)
        # Очистка кеша при старте (в фоне, не блокирует UI)
        threading.Thread(target=self._clear_cache_on_startup, daemon=True).start()
        # Проверка обновлений через 1 секунду после запуска (в фоне)
        self.after(1000, self._check_updates_bg)

    # ── Построение UI ────────────────────────────────────────────────────────

    def _build_ui(self):
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # Боковая панель настроек — скроллируемая
        self._sidebar = ctk.CTkScrollableFrame(self, width=240, corner_radius=0)
        self._sidebar.grid(row=0, column=0, sticky="nsew", rowspan=2)
        self._build_sidebar()

        # Правая часть: вкладки + кнопки + прогресс + лог
        right = ctk.CTkFrame(self, corner_radius=0, fg_color="transparent")
        right.grid(row=0, column=1, sticky="nsew", padx=0, pady=0)
        right.grid_rowconfigure(0, weight=2)   # вкладки — гибкие
        right.grid_rowconfigure(1, weight=0)   # кнопки — всегда видны
        right.grid_rowconfigure(2, weight=0)   # прогресс
        right.grid_rowconfigure(3, weight=1)   # лог — небольшой
        right.grid_columnconfigure(0, weight=1)

        # Вкладки
        self._tabs = ctk.CTkTabview(right, corner_radius=8)
        self._tabs.grid(row=0, column=0, sticky="nsew", padx=10, pady=(10, 0))
        self._tab_composer = self._tabs.add("🎬 Composer")
        self._tab_zones    = self._tabs.add("📐 Zone Editor")
        self._build_composer_tab()
        self._build_zone_tab()
        # Перерисовываем Zone Editor при переключении на эту вкладку
        self._tabs.configure(command=self._on_tab_change)

        # ── Кнопки — всегда видимы, вне вкладок ─────────────────────────────
        btns_bar = ctk.CTkFrame(right, corner_radius=6, fg_color="#1c1c1c")
        btns_bar.grid(row=1, column=0, sticky="ew", padx=10, pady=(6, 0))
        self._start_btn = ctk.CTkButton(
            btns_bar, text="▶  СТАРТ", width=160, height=44,
            font=ctk.CTkFont(size=15, weight="bold"),
            fg_color="#2d6a2d", hover_color="#1e4d1e",
            command=self._start_run)
        self._start_btn.pack(side="left", padx=(10, 10), pady=8)
        ctk.CTkButton(
            btns_bar, text="📁 Открыть директорию", width=170, height=44,
            font=ctk.CTkFont(size=13),
            fg_color="#2a2a3a", hover_color="#3a3a5a",
            command=self._open_output_dir
        ).pack(side="left", padx=(0, 10), pady=8)
        # Кнопка «Расширенные» — справа в той же панели, всегда видна
        self._adv_btn = ctk.CTkButton(
            btns_bar, text="⚙  Расширенные", width=150, height=44,
            font=ctk.CTkFont(size=13),
            fg_color="#2a2a2a", hover_color="#3a3a3a",
            command=self._toggle_advanced,
        )
        self._adv_btn.pack(side="right", padx=(0, 10), pady=8)

        # Прогресс-бар (градиент + проценты)
        prog_frame = ctk.CTkFrame(right, height=44, corner_radius=8)
        prog_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=(4, 0))
        prog_frame.grid_columnconfigure(0, weight=1)
        self._progress = GradientProgressBar(prog_frame, height=26)
        self._progress.set(0)
        self._progress.grid(row=0, column=0, sticky="ew", padx=10, pady=9)

        # Лог
        self._log_frame = ctk.CTkFrame(right, corner_radius=6)
        self._log_frame.grid(row=3, column=0, sticky="nsew", padx=10, pady=(4, 10))
        log_frame = self._log_frame
        log_frame.grid_rowconfigure(1, weight=1)
        log_frame.grid_columnconfigure(0, weight=1)

        log_header = ctk.CTkFrame(log_frame, fg_color="transparent")
        log_header.grid(row=0, column=0, sticky="ew", padx=6, pady=(4, 0))
        ctk.CTkLabel(log_header, text="📋 LOG", font=ctk.CTkFont(size=12, weight="bold")).pack(side="left")
        ctk.CTkButton(log_header, text="Очистить", width=72, height=24,
                      command=self._clear_log, fg_color="#444").pack(side="right")
        ctk.CTkButton(log_header, text="💾", width=34, height=24,
                      command=self._copy_log, fg_color="#333", hover_color="#555",
                      font=ctk.CTkFont(size=14)).pack(side="right", padx=(0, 4))

        self._log_text = ctk.CTkTextbox(log_frame, font=ctk.CTkFont(family="Menlo", size=11),
                                        wrap="word", state="disabled")
        self._log_text.grid(row=1, column=0, sticky="nsew", padx=6, pady=(2, 6))

    # ── Вспомогательные методы для полей ввода ──────────────────────────────

    def _make_key_row(self, parent, label: str, placeholder: str,
                      row: int, service: str | None = None
                      ) -> tuple[ctk.CTkEntry, ctk.CTkLabel]:
        """
        Строка: подпись + поле ввода + 👁 кнопка + ● индикатор валидности.
        Возвращает (entry, dot).
        service: "assemblyai" | "gemini" | "openai" | "fastgen" | None
        """
        # Подпись
        ctk.CTkLabel(parent, text=label, font=ctk.CTkFont(size=11)
                     ).grid(row=row, column=0, columnspan=3,
                            padx=14, pady=(6, 0), sticky="w")
        row += 1

        # Поле ввода — текст видим по умолчанию (без show="*")
        # чтобы вставка работала нативно на macOS
        entry = ctk.CTkEntry(parent, placeholder_text=placeholder, width=168)
        entry.grid(row=row, column=0, padx=(14, 2), pady=(0, 3), sticky="w")

        # Кнопка 👁 скрыть/показать
        eye_hidden = [False]

        def toggle_hide():
            eye_hidden[0] = not eye_hidden[0]
            entry.configure(show="*" if eye_hidden[0] else "")
            eye_btn.configure(text="🙈" if eye_hidden[0] else "👁")

        # Сохраняем ссылку на toggle прямо в объекте entry
        # чтобы _load_settings_to_ui мог скрыть поле после вставки значения
        entry._toggle_hide = toggle_hide

        eye_btn = ctk.CTkButton(parent, text="👁", width=28, height=28,
                                command=toggle_hide,
                                fg_color="#333", hover_color="#555")
        eye_btn.grid(row=row, column=1, padx=(0, 4), pady=(0, 3))

        # Индикатор валидности ●
        dot = ctk.CTkLabel(parent, text="●", width=18,
                           font=ctk.CTkFont(size=15),
                           text_color="#444")   # серый = не проверено
        dot.grid(row=row, column=2, padx=(0, 10), pady=(0, 3))

        # Привязка вставки
        self._bind_paste(entry)

        # Авто-валидация
        if service:
            self._setup_key_validation(entry, dot, service)

        return entry, dot

    def _bind_paste(self, entry: ctk.CTkEntry):
        """
        Привязка вставки (Cmd+V / Ctrl+V) и контекстного меню (ПКМ)
        непосредственно к внутреннему tk.Entry — самый надёжный способ на macOS.
        """
        inner = getattr(entry, "_entry", None)
        if inner is None:
            return  # fallback — виджет ещё не создан

        def do_paste(event=None):
            try:
                text = self.clipboard_get()
            except Exception:
                return "break"
            text = text.strip()
            try:
                if inner.selection_present():
                    inner.delete("sel.first", "sel.last")
            except Exception:
                pass
            try:
                pos = inner.index("insert")
                inner.insert(pos, text)
            except Exception:
                inner.insert("end", text)
            return "break"

        def do_cut(event=None):
            try:
                if inner.selection_present():
                    sel = inner.selection_get()
                    self.clipboard_clear()
                    self.clipboard_append(sel)
                    inner.delete("sel.first", "sel.last")
            except Exception:
                pass

        def do_copy(event=None):
            try:
                if inner.selection_present():
                    sel = inner.selection_get()
                    self.clipboard_clear()
                    self.clipboard_append(sel)
            except Exception:
                pass

        def do_select_all(event=None):
            inner.selection_range(0, "end")
            inner.icursor("end")
            return "break"

        def show_context_menu(event):
            menu = tk.Menu(inner, tearoff=0)
            menu.add_command(label="Вырезать",      command=do_cut)
            menu.add_command(label="Копировать",    command=do_copy)
            menu.add_command(label="Вставить",      command=do_paste)
            menu.add_separator()
            menu.add_command(label="Выделить всё",  command=do_select_all)
            try:
                menu.tk_popup(event.x_root, event.y_root)
            finally:
                menu.grab_release()

        # Клавиатурные привязки — Cmd+V/Ctrl+V и Cmd+A
        inner.bind("<Command-v>",   do_paste)
        inner.bind("<Control-v>",   do_paste)
        inner.bind("<Command-V>",   do_paste)
        inner.bind("<Control-V>",   do_paste)
        inner.bind("<Command-a>",   do_select_all)
        inner.bind("<Control-a>",   do_select_all)

        # ПКМ — Button-2 (macOS трекпад) и Button-3 (обычная мышь)
        inner.bind("<Button-2>",    show_context_menu)
        inner.bind("<Button-3>",    show_context_menu)

    # ── Валидация ключей ─────────────────────────────────────────────────────

    def _setup_key_validation(self, entry: ctk.CTkEntry,
                               dot: ctk.CTkLabel, service: str):
        """Вешает дебаунс-валидацию на поле: 1.5 с после последнего нажатия."""
        timer = [None]

        def schedule(event=None):
            if timer[0]:
                self.after_cancel(timer[0])
            timer[0] = self.after(1500, lambda: self._validate_async(entry, dot, service))

        def on_focus_out(event=None):
            if timer[0]:
                self.after_cancel(timer[0])
            self._validate_async(entry, dot, service)
            self._auto_save()

        inner = getattr(entry, "_entry", None)
        if inner:
            inner.bind("<KeyRelease>", schedule)
            inner.bind("<FocusOut>",   on_focus_out)
        try:
            entry.bind("<KeyRelease>", schedule)
        except Exception:
            pass

    def _validate_async(self, entry: ctk.CTkEntry,
                         dot: ctk.CTkLabel, service: str):
        """Запускает проверку ключа в фоновом потоке; обновляет dot из главного."""
        key = entry.get().strip()
        if not key:
            dot.configure(text="●", text_color="#444")   # серый — пусто
            return

        dot.configure(text="⟳", text_color="#aaa")       # крутится — проверяем

        def check():
            ok = self._check_key(key, service)
            color = "#2ecc71" if ok else "#e74c3c"        # зелёный / красный
            self.after(0, lambda: dot.configure(text="●", text_color=color))

        threading.Thread(target=check, daemon=True).start()

    def _check_key(self, key: str, service: str) -> bool:
        """Синхронная проверка ключа в фоновом потоке."""
        try:
            if service == "assemblyai":
                import requests as _req
                r = _req.get("https://api.assemblyai.com/v2/transcript",
                             headers={"Authorization": key}, timeout=8)
                # 401 = невалидный, всё остальное (200, 400, 404) = ключ принят
                return r.status_code != 401

            elif service == "fastgen":
                import requests as _req
                r = _req.get(
                    f"{config.FASTGEN_API_BASE}/api/v4/engines",
                    headers={"X-API-Key": key, "Content-Type": "application/json"},
                    timeout=8,
                )
                return r.status_code != 401

            elif service == "pexels":
                import requests as _req
                r = _req.get(
                    "https://api.pexels.com/v1/search?query=flower&per_page=1",
                    headers={"Authorization": key},
                    timeout=8,
                )
                return r.status_code == 200

            elif service == "gemini":
                import requests as _req
                r = _req.get(
                    f"https://generativelanguage.googleapis.com/v1beta/models?key={key}",
                    timeout=8,
                )
                return r.status_code == 200

            elif service == "openai":
                import requests as _req
                r = _req.get(
                    "https://api.openai.com/v1/models",
                    headers={"Authorization": f"Bearer {key}"},
                    timeout=8,
                )
                return r.status_code != 401

        except Exception:
            return False
        return False

    def _validate_all_keys(self):
        """Запускает проверку всех заполненных ключей (вызывается после загрузки настроек)."""
        for entry, dot, service in self._key_validators:
            if entry.get().strip():
                self._validate_async(entry, dot, service)
        # Обновляем баланс вместе с проверкой ключей
        self._fetch_balances()

    # ── OpenAI OAuth-like connect ────────────────────────────────────────────

    def _openai_auth_click(self):
        """Кнопка Войти / Отключить OpenAI (PKCE OAuth через Codex CLI)."""
        if self._openai_key.get().strip():
            # Уже подключён → отключаем
            self._openai_key.delete(0, "end")
            config.OPENAI_API_KEY = ""
            self._openai_set_connected(False, user_info=None)
            self._auto_save()
        else:
            # Запускаем OAuth — показываем спиннер
            self._openai_auth_btn.configure(
                text="⏳  Ожидаем авторизацию в браузере...",
                state="disabled", fg_color="#444",
            )
            self._openai_status_lbl.configure(
                text="Браузер открыт — войдите в аккаунт OpenAI", text_color="#aaa")
            self._start_oauth_flow()

    def _start_oauth_flow(self):
        """Запускает PKCE-поток openai_oauth.start_oauth() в фоне."""
        from openai_oauth import start_oauth, get_user_info
        import config as _cfg

        def _on_tokens(tokens: dict):
            access_token  = tokens.get("access_token", "")
            refresh_token = tokens.get("refresh_token", "")
            if not access_token:
                self.after(0, lambda: self._oauth_error("Нет access_token в ответе."))
                return
            # Сохраняем токены
            self._openai_key.delete(0, "end")
            self._openai_key.insert(0, access_token)
            # refresh_token в отдельном поле памяти
            self._openai_refresh = refresh_token
            _cfg.OPENAI_API_KEY = access_token
            # Получаем профиль
            info = get_user_info(access_token)
            self.after(0, lambda: self._oauth_success(info))

        def _on_error(msg: str):
            self.after(0, lambda: self._oauth_error(msg))

        start_oauth(on_tokens=_on_tokens, on_error=_on_error)

    def _oauth_success(self, user_info: dict):
        """Вызывается в главном потоке после успешной авторизации."""
        self._openai_set_connected(True, user_info=user_info)
        self._auto_save()
        self._fetch_balances()

    def _oauth_error(self, msg: str):
        """Вызывается в главном потоке при ошибке OAuth."""
        self._openai_auth_btn.configure(
            text="🔑  Войти через OpenAI (Codex)",
            state="normal", fg_color="#1a6b3a", hover_color="#1e8046",
        )
        self._openai_status_lbl.configure(
            text=f"✗ Ошибка: {msg[:60]}", text_color="#e74c3c")

    def _openai_set_connected(self, connected: bool, user_info: dict | None = None):
        """Обновляет кнопку и статус-метку по состоянию подключения."""
        if connected:
            name  = (user_info or {}).get("name") or (user_info or {}).get("email") or ""
            label = f"✓  {name} · Выйти" if name else "✓  Подключено · Выйти"
            self._openai_auth_btn.configure(
                text=label, state="normal",
                fg_color="#1a3a2a", hover_color="#1e4a34",
            )
            self._openai_status_lbl.configure(
                text="✓ Промпты генерирует GPT-4o", text_color="#2ecc71")
        else:
            self._openai_auth_btn.configure(
                text="🔑  Войти через OpenAI (Codex)",
                state="normal", fg_color="#1a6b3a", hover_color="#1e8046",
            )
            self._openai_status_lbl.configure(
                text="Не подключено  →  авто-режим", text_color="#666")

    # ── Claude OAuth connect ─────────────────────────────────────────────────

    def _claude_auth_click(self):
        """Кнопка Войти / Выйти Claude."""
        if self._claude_token_field.get().strip():
            self._claude_token_field.delete(0, "end")
            config.CLAUDE_ACCESS_TOKEN = ""
            self._claude_set_connected(False)
            self._auto_save()
        else:
            self._claude_auth_btn.configure(
                text="⏳  Ожидаем авторизацию в браузере...",
                state="disabled", fg_color="#333",
            )
            self._claude_status_lbl.configure(
                text="Браузер открыт — войдите в аккаунт Claude", text_color="#aaa")
            self._start_claude_oauth()

    def _start_claude_oauth(self):
        from claude_oauth import start_oauth, get_user_info
        import config as _cfg

        def _on_tokens(tokens: dict):
            access_token  = tokens.get("access_token", "")
            refresh_token = tokens.get("refresh_token", "")
            if not access_token:
                self.after(0, lambda: self._claude_oauth_error("Нет access_token"))
                return
            self._claude_token_field.delete(0, "end")
            self._claude_token_field.insert(0, access_token)
            self._claude_refresh = refresh_token
            _cfg.CLAUDE_ACCESS_TOKEN  = access_token
            _cfg.CLAUDE_REFRESH_TOKEN = refresh_token
            info = get_user_info(access_token)
            self.after(0, lambda: self._claude_oauth_success(info))

        def _on_error(msg: str):
            self.after(0, lambda: self._claude_oauth_error(msg))

        start_oauth(on_tokens=_on_tokens, on_error=_on_error)

    def _claude_oauth_success(self, user_info: dict):
        self._claude_set_connected(True, user_info=user_info)
        self._auto_save()
        self._fetch_balances()

    def _claude_oauth_error(self, msg: str):
        self._claude_auth_btn.configure(
            text="🤖  Войти через Claude",
            state="normal", fg_color="#1a3a6b", hover_color="#1e4a8a",
        )
        self._claude_status_lbl.configure(
            text=f"✗ Ошибка: {msg[:60]}", text_color="#e74c3c")

    def _claude_set_connected(self, connected: bool, user_info: dict | None = None):
        if connected:
            name  = (user_info or {}).get("name") or (user_info or {}).get("email") or ""
            label = f"🤖  {name} · Выйти" if name else "🤖  Подключено · Выйти"
            self._claude_auth_btn.configure(
                text=label, state="normal",
                fg_color="#0f2a4a", hover_color="#1a3a6b",
            )
            self._claude_status_lbl.configure(
                text="✓ Промпты генерирует Claude", text_color="#5dade2")
        else:
            self._claude_auth_btn.configure(
                text="🤖  Войти через Claude",
                state="normal", fg_color="#1a3a6b", hover_color="#1e4a8a",
            )
            self._claude_status_lbl.configure(text="Не подключено", text_color="#666")

    def _fetch_balances(self):
        """Запрашивает баланс/статус всех сервисов в фоновом потоке."""
        asm_key       = self._asm_key.get().strip()
        fg_key        = self._fastgen_key.get().strip()
        pexels_key    = self._pexels_key.get().strip()
        gemini_key    = self._gemini_key.get().strip()
        openai_key    = self._openai_key.get().strip()
        claude_key    = self._claude_token_field.get().strip()
        claude_ref    = getattr(self, "_claude_refresh", "")

        self.after(0, lambda: self._asm_bal_lbl.configure(text="AssemblyAI:  ⏳"))
        self.after(0, lambda: self._fg_bal_lbl.configure(text="FastGen:        ⏳"))
        self.after(0, lambda: self._pexels_bal_lbl.configure(text="Pexels:             ⏳"))
        self.after(0, lambda: self._gemini_bal_lbl.configure(text="Gemini:           ⏳"))
        self.after(0, lambda: self._openai_bal_lbl.configure(text="OpenAI:          ⏳"))
        self.after(0, lambda: self._claude_bal_lbl.configure(text="Claude:            ⏳"))

        def _do():
            import requests as _req

            # ── AssemblyAI ──────────────────────────────────────────────────
            asm_text = "ключ не задан"
            if asm_key:
                try:
                    # Проверяем валидность ключа через list-транскриптов
                    r = _req.get(
                        "https://api.assemblyai.com/v2/transcript",
                        headers={"Authorization": asm_key}, timeout=8)
                    if r.status_code == 401:
                        asm_text = "✗ неверный ключ"
                    else:
                        asm_text = "✓ ключ активен"
                except Exception:
                    asm_text = "нет сети"

            # ── FastGen ─────────────────────────────────────────────────────
            fg_text = "ключ не задан"
            if fg_key:
                try:
                    headers = {
                        "X-API-Key": fg_key,
                        "Content-Type": "application/json",
                    }
                    # Сначала пробуем endpoint с балансом
                    r = _req.get(
                        f"{config.FASTGEN_API_BASE}/api/v4/account",
                        headers=headers, timeout=8)
                    if r.status_code == 200:
                        data = r.json()
                        credits = (data.get("credits")
                                   or data.get("balance")
                                   or data.get("remaining_credits")
                                   or data.get("remaining"))
                        if credits is not None:
                            fg_text = f"✓ {credits} кредитов"
                        else:
                            fg_text = "✓ ключ активен"
                    elif r.status_code == 401:
                        fg_text = "✗ неверный ключ"
                    else:
                        # fallback: engines endpoint
                        r2 = _req.get(
                            f"{config.FASTGEN_API_BASE}/api/v4/engines",
                            headers=headers, timeout=8)
                        if r2.status_code == 200:
                            engines = r2.json()
                            count = len(engines) if isinstance(engines, list) else "?"
                            fg_text = f"✓ {count} движков доступно"
                        elif r2.status_code == 401:
                            fg_text = "✗ неверный ключ"
                        else:
                            fg_text = f"✓ ключ активен"
                except Exception:
                    fg_text = "нет сети"

            # ── Pexels ──────────────────────────────────────────────────────
            pexels_text = "ключ не задан"
            if pexels_key:
                try:
                    r = _req.get(
                        "https://api.pexels.com/v1/search?query=flower&per_page=1",
                        headers={"Authorization": pexels_key}, timeout=8)
                    if r.status_code == 200:
                        remaining = r.headers.get("X-Ratelimit-Requests-Remaining")
                        limit     = r.headers.get("X-Ratelimit-Requests-Limit")
                        if remaining is not None and limit is not None:
                            pexels_text = f"✓ {remaining}/{limit} запросов"
                        elif remaining is not None:
                            pexels_text = f"✓ {remaining} запросов осталось"
                        else:
                            pexels_text = "✓ ключ активен"
                    elif r.status_code == 401:
                        pexels_text = "✗ неверный ключ"
                    elif r.status_code == 429:
                        pexels_text = "⚠ лимит исчерпан"
                    else:
                        pexels_text = f"✗ HTTP {r.status_code}"
                except Exception:
                    pexels_text = "нет сети"

            # ── OpenAI ──────────────────────────────────────────────────────
            oai_text = "ключ не задан"
            if openai_key:
                try:
                    headers_oai = {"Authorization": f"Bearer {openai_key}"}
                    # Пробуем получить кредитный баланс (старые аккаунты)
                    r = _req.get(
                        "https://api.openai.com/v1/dashboard/billing/credit_grants",
                        headers=headers_oai, timeout=8)
                    if r.status_code == 200:
                        data = r.json()
                        remaining = data.get("total_available")
                        if remaining is not None:
                            oai_text = f"✓ ${remaining:.2f} кредитов"
                        else:
                            oai_text = "✓ ключ активен"
                    elif r.status_code == 401:
                        oai_text = "✗ неверный ключ"
                    else:
                        # Fallback: проверка через /v1/models
                        r2 = _req.get(
                            "https://api.openai.com/v1/models",
                            headers=headers_oai, timeout=8)
                        if r2.status_code == 200:
                            # Показываем список доступных GPT-моделей
                            models = r2.json().get("data", [])
                            gpt_ids = sorted(
                                {m["id"] for m in models
                                 if any(k in m["id"] for k in ("gpt-4o", "gpt-4", "gpt-3.5"))},
                                reverse=True)
                            short = ", ".join(gpt_ids[:3]) or "?"
                            oai_text = f"✓ {short}"
                        elif r2.status_code == 401:
                            oai_text = "✗ неверный ключ"
                        else:
                            oai_text = "✓ ключ активен"
                except Exception:
                    oai_text = "нет сети"

            # ── Claude ──────────────────────────────────────────────────────
            cl_text = "не подключён"
            if claude_key:
                def _check_claude(token: str):
                    r = _req.get(
                        "https://api.anthropic.com/v1/models",
                        headers={
                            "Authorization":    f"Bearer {token}",
                            "anthropic-version": "2023-06-01",
                            "anthropic-beta":   "oauth-2025-04-20",
                        },
                        timeout=8,
                    )
                    return r

                try:
                    r = _check_claude(claude_key)
                    if r.status_code == 401 and claude_ref:
                        # Токен истёк — пробуем обновить
                        try:
                            from claude_oauth import refresh_access_token
                            new_tokens = refresh_access_token(claude_ref)
                            new_access  = new_tokens.get("access_token", "")
                            new_refresh = new_tokens.get("refresh_token", claude_ref)
                            if new_access:
                                # Обновляем поле и сохраняем
                                self.after(0, lambda t=new_access: (
                                    self._claude_token_field.delete(0, "end"),
                                    self._claude_token_field.insert(0, t),
                                ))
                                self._claude_refresh = new_refresh
                                config.CLAUDE_REFRESH_TOKEN = new_refresh
                                self._auto_save()
                                r = _check_claude(new_access)
                        except Exception as re:
                            print(f"[claude] refresh failed: {re}")

                    if r.status_code == 200:
                        models = r.json().get("data", [])
                        names = [m.get("id","") for m in models
                                 if "claude" in m.get("id","").lower()][:2]
                        cl_text = f"✓ {', '.join(names)}" if names else "✓ подключён"
                    elif r.status_code == 401:
                        cl_text = "✗ токен истёк (нужен повторный вход)"
                    else:
                        cl_text = "✓ токен активен"
                except Exception:
                    cl_text = "нет сети"

            # ── Gemini ──────────────────────────────────────────────────────
            gem_text = "ключ не задан"
            if gemini_key:
                try:
                    r_gem = _req.get(
                        f"https://generativelanguage.googleapis.com/v1beta/models?key={gemini_key}",
                        timeout=8)
                    if r_gem.status_code == 200:
                        models_gem = r_gem.json().get("models", [])
                        gem_text = f"✓ {len(models_gem)} моделей"
                    elif r_gem.status_code == 400:
                        gem_text = "✗ неверный ключ"
                    elif r_gem.status_code == 403:
                        gem_text = "✗ доступ запрещён"
                    else:
                        gem_text = f"✗ HTTP {r_gem.status_code}"
                except Exception:
                    gem_text = "нет сети"

            _c = lambda t: "#2ecc71" if "✓" in t else "#e74c3c" if "✗" in t else "#888"
            _cb = lambda t: "#5dade2" if "✓" in t else "#e74c3c" if "✗" in t else "#888"
            self.after(0, lambda: self._asm_bal_lbl.configure(
                text=f"AssemblyAI:  {asm_text}", text_color=_c(asm_text)))
            self.after(0, lambda: self._fg_bal_lbl.configure(
                text=f"FastGen:        {fg_text}", text_color=_c(fg_text)))
            _px = pexels_text
            self.after(0, lambda: self._pexels_bal_lbl.configure(
                text=f"Pexels:             {_px}", text_color=_c(_px)))
            _gm = gem_text
            self.after(0, lambda: self._gemini_bal_lbl.configure(
                text=f"Gemini:           {_gm}", text_color=_c(_gm)))
            self.after(0, lambda: self._openai_bal_lbl.configure(
                text=f"OpenAI:          {oai_text}", text_color=_c(oai_text)))
            self.after(0, lambda: self._claude_bal_lbl.configure(
                text=f"Claude:            {cl_text}", text_color=_cb(cl_text)))

        threading.Thread(target=_do, daemon=True).start()

    def _build_sidebar(self):
        sb = self._sidebar
        sb.grid_columnconfigure(0, weight=1)
        sb.grid_columnconfigure(1, weight=0)
        sb.grid_columnconfigure(2, weight=0)
        row = 0

        # Список (entry, dot, service) для массовой перепроверки
        self._key_validators: list[tuple] = []

        ctk.CTkLabel(sb, text="⚙️ НАСТРОЙКИ", font=ctk.CTkFont(size=13, weight="bold")
                     ).grid(row=row, column=0, columnspan=3,
                            padx=14, pady=(14, 4), sticky="w"); row += 1

        # ── AssemblyAI ───────────────────────────────────────────────────────
        self._asm_key, _asm_dot = self._make_key_row(
            sb, "AssemblyAI Key:", "8af182ce...", row, service="assemblyai")
        row += 2
        self._key_validators.append((self._asm_key, _asm_dot, "assemblyai"))

        # ── Источник изображений (FastGen / Pexels) ──────────────────────────
        ctk.CTkLabel(sb, text="─── Источник изображений ───",
                     font=ctk.CTkFont(size=10), text_color="#666"
                     ).grid(row=row, column=0, columnspan=3,
                            padx=14, pady=(12, 2), sticky="w"); row += 1

        self._img_source_seg = ctk.CTkSegmentedButton(
            sb, values=["FastGen", "Pexels"], width=228,
            command=self._on_img_source_change)
        self._img_source_seg.set("FastGen")
        self._img_source_seg.grid(row=row, column=0, columnspan=3,
                                  padx=14, pady=(0, 6)); row += 1

        # ── FastGen-фрейм ────────────────────────────────────────────────────
        self._fastgen_frame = ctk.CTkFrame(sb, fg_color="transparent")
        self._fastgen_frame.grid(row=row, column=0, columnspan=3, sticky="ew"); row += 1
        self._fastgen_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(self._fastgen_frame,
                     text="Генерация изображений с помощью AI.\nfast-gen.ai — нужен платный API-ключ.",
                     font=ctk.CTkFont(size=9), text_color="#888", justify="left"
                     ).grid(row=0, column=0, columnspan=3, padx=14, pady=(0, 4), sticky="w")

        self._fastgen_key, _fastgen_dot = self._make_key_row(
            self._fastgen_frame, "FastGen Key:", "Ps8Siq8P...", 1, service="fastgen")
        self._key_validators.append((self._fastgen_key, _fastgen_dot, "fastgen"))

        ctk.CTkLabel(self._fastgen_frame, text="Движок:", font=ctk.CTkFont(size=11)
                     ).grid(row=3, column=0, columnspan=3, padx=14, pady=(6, 0), sticky="w")
        self._engine_var = ctk.CTkComboBox(
            self._fastgen_frame, width=228,
            values=["NARWHAL", "GEM_PIX_2", "GEMINI", "GROK", "GEM_PIX", "IMAGEN_3_5"],
            command=lambda _: self._auto_save())
        self._engine_var.set("NARWHAL")
        self._engine_var.grid(row=4, column=0, columnspan=3, padx=14, pady=(0, 4))

        # ── Pexels-фрейм ─────────────────────────────────────────────────────
        self._pexels_src_frame = ctk.CTkFrame(sb, fg_color="transparent")
        self._pexels_src_frame.grid(row=row, column=0, columnspan=3, sticky="ew"); row += 1
        self._pexels_src_frame.grid_columnconfigure(0, weight=1)
        self._pexels_src_frame.grid_remove()   # скрыт по умолчанию

        ctk.CTkLabel(self._pexels_src_frame,
                     text="Реальные фотографии из фотобанка Pexels.\nБесплатно: 200 запросов/час, без карты.\npexels.com/api — регистрация и ключ.",
                     font=ctk.CTkFont(size=9), text_color="#888", justify="left"
                     ).grid(row=0, column=0, columnspan=3, padx=14, pady=(0, 4), sticky="w")

        self._pexels_key, _pexels_dot = self._make_key_row(
            self._pexels_src_frame, "Pexels Key:", "xxxxxxxx...", 1, service=None)
        self._key_validators.append((self._pexels_key, _pexels_dot, "pexels"))

        # ── Кто пишет промпты ────────────────────────────────────────────────
        ctk.CTkLabel(sb, text="─── Кто пишет промпты ───",
                     font=ctk.CTkFont(size=10), text_color="#666"
                     ).grid(row=row, column=0, columnspan=3,
                            padx=14, pady=(12, 2), sticky="w"); row += 1

        self._ai_backend_combo = ctk.CTkComboBox(
            sb,
            values=["Авто (без AI)", "Gemini (Google)", "Claude (Anthropic)", "ChatGPT (OpenAI)"],
            command=self._on_ai_backend_change,
            width=228, state="readonly")
        self._ai_backend_combo.set("Авто (без AI)")
        self._ai_backend_combo.grid(row=row, column=0, columnspan=3,
                                    padx=14, pady=(0, 4)); row += 1

        # ── Контекстные фреймы (занимают один row, переключаются) ────────────
        _ai_row = row; row += 1

        # Gemini
        self._ai_gemini_frame = ctk.CTkFrame(sb, fg_color="transparent")
        self._ai_gemini_frame.grid(row=_ai_row, column=0, columnspan=3, sticky="ew")
        self._ai_gemini_frame.grid_columnconfigure(0, weight=1)
        self._ai_gemini_frame.grid_remove()

        ctk.CTkLabel(self._ai_gemini_frame,
                     text="Бесплатный AI для генерации промптов.\naistudio.google.com → Get API key",
                     font=ctk.CTkFont(size=9), text_color="#888", justify="left"
                     ).grid(row=0, column=0, columnspan=3, padx=14, pady=(4, 2), sticky="w")

        self._gemini_key, _gemini_dot = self._make_key_row(
            self._ai_gemini_frame, "Gemini Key:", "AIzaSy...", 1, service="gemini")
        self._key_validators.append((self._gemini_key, _gemini_dot, "gemini"))

        # Claude
        self._ai_claude_frame = ctk.CTkFrame(sb, fg_color="transparent")
        self._ai_claude_frame.grid(row=_ai_row, column=0, columnspan=3, sticky="ew")
        self._ai_claude_frame.grid_columnconfigure(0, weight=1)
        self._ai_claude_frame.grid_remove()

        # Скрытое поле для хранения токена (не в grid)
        self._claude_token_field = ctk.CTkEntry(self._ai_claude_frame)

        self._claude_auth_btn = ctk.CTkButton(
            self._ai_claude_frame, text="🤖  Войти через Claude",
            height=34, corner_radius=8,
            fg_color="#1a3a6b", hover_color="#1e4a8a",
            font=ctk.CTkFont(size=12, weight="bold"),
            command=self._claude_auth_click,
        )
        self._claude_auth_btn.grid(row=0, column=0, columnspan=3,
                                   padx=14, pady=(4, 2), sticky="ew")

        self._claude_status_lbl = ctk.CTkLabel(
            self._ai_claude_frame, text="Не подключено",
            font=ctk.CTkFont(size=9), text_color="#666", justify="left",
        )
        self._claude_status_lbl.grid(row=1, column=0, columnspan=3,
                                     padx=16, pady=(0, 4), sticky="w")

        # ChatGPT
        self._ai_chatgpt_frame = ctk.CTkFrame(sb, fg_color="transparent")
        self._ai_chatgpt_frame.grid(row=_ai_row, column=0, columnspan=3, sticky="ew")
        self._ai_chatgpt_frame.grid_columnconfigure(0, weight=1)
        self._ai_chatgpt_frame.grid_remove()

        # Скрытое поле — хранит токен в памяти (не в grid)
        self._openai_key = ctk.CTkEntry(self._ai_chatgpt_frame)

        self._openai_auth_btn = ctk.CTkButton(
            self._ai_chatgpt_frame, text="🔑  Войти через OpenAI (Codex)",
            height=34, corner_radius=8,
            fg_color="#1a6b3a", hover_color="#1e8046",
            font=ctk.CTkFont(size=12, weight="bold"),
            command=self._openai_auth_click,
        )
        self._openai_auth_btn.grid(row=0, column=0, columnspan=3,
                                   padx=14, pady=(4, 2), sticky="ew")

        self._openai_status_lbl = ctk.CTkLabel(
            self._ai_chatgpt_frame, text="Не подключено  →  авто-режим",
            font=ctk.CTkFont(size=9), text_color="#666", justify="left",
        )
        self._openai_status_lbl.grid(row=1, column=0, columnspan=3,
                                     padx=16, pady=(0, 4), sticky="w")

        # ── Состояние аккаунтов ──────────────────────────────────────────────
        ctk.CTkLabel(sb, text="─── Состояние аккаунтов ───",
                     font=ctk.CTkFont(size=10), text_color="#666"
                     ).grid(row=row, column=0, columnspan=3,
                            padx=14, pady=(10, 2), sticky="w"); row += 1

        bal_frame = ctk.CTkFrame(sb, fg_color="#1c1c1c", corner_radius=6)
        bal_frame.grid(row=row, column=0, columnspan=3,
                       padx=14, pady=(0, 4), sticky="ew"); row += 1
        bal_frame.grid_columnconfigure(0, weight=1)

        self._asm_bal_lbl = ctk.CTkLabel(
            bal_frame, text="AssemblyAI:  —",
            font=ctk.CTkFont(size=10), text_color="#888",
            justify="left", anchor="w")
        self._asm_bal_lbl.grid(row=0, column=0, padx=10, pady=(7, 1), sticky="w")

        self._fg_bal_lbl = ctk.CTkLabel(
            bal_frame, text="FastGen:        —",
            font=ctk.CTkFont(size=10), text_color="#888",
            justify="left", anchor="w")
        self._fg_bal_lbl.grid(row=1, column=0, padx=10, pady=(0, 1), sticky="w")

        self._openai_bal_lbl = ctk.CTkLabel(
            bal_frame, text="OpenAI:          —",
            font=ctk.CTkFont(size=10), text_color="#888",
            justify="left", anchor="w")
        self._openai_bal_lbl.grid(row=2, column=0, padx=10, pady=(0, 1), sticky="w")

        self._gemini_bal_lbl = ctk.CTkLabel(
            bal_frame, text="Gemini:           —",
            font=ctk.CTkFont(size=10), text_color="#888",
            justify="left", anchor="w")
        self._gemini_bal_lbl.grid(row=3, column=0, padx=10, pady=(0, 1), sticky="w")

        self._claude_bal_lbl = ctk.CTkLabel(
            bal_frame, text="Claude:            —",
            font=ctk.CTkFont(size=10), text_color="#888",
            justify="left", anchor="w")
        self._claude_bal_lbl.grid(row=4, column=0, padx=10, pady=(0, 1), sticky="w")

        self._pexels_bal_lbl = ctk.CTkLabel(
            bal_frame, text="Pexels:             —",
            font=ctk.CTkFont(size=10), text_color="#888",
            justify="left", anchor="w")
        self._pexels_bal_lbl.grid(row=5, column=0, padx=10, pady=(0, 7), sticky="w")

        ctk.CTkButton(
            sb, text="🔄 Обновить баланс", height=26,
            fg_color="#2a2a2a", hover_color="#3a3a3a",
            font=ctk.CTkFont(size=10),
            command=self._fetch_balances
        ).grid(row=row, column=0, columnspan=3, padx=14, pady=(0, 4), sticky="ew"); row += 1

        ctk.CTkLabel(
            sb, text="assemblyai.com  •  fast-gen.ai  •  openai.com",
            font=ctk.CTkFont(size=9), text_color="#555", justify="left"
        ).grid(row=row, column=0, columnspan=3, padx=14, pady=(4, 4), sticky="w"); row += 1

        # ── Кнопка быстрого перезапуска ──────────────────────────────────────
        ctk.CTkButton(
            sb, text="🔁  Перезапустить приложение",
            height=32, font=ctk.CTkFont(size=11),
            fg_color="#3a1a1a", hover_color="#6b1a1a",
            text_color="#ff8888",
            command=self._restart_app
        ).grid(row=row, column=0, columnspan=3, padx=14, pady=(6, 14), sticky="ew"); row += 1

    def _build_composer_tab(self):
        tab = self._tab_composer
        tab.grid_columnconfigure(0, weight=1)
        row = 0

        # Видео (компактный ряд: кнопка + метка + чекбокс референса)
        vf = ctk.CTkFrame(tab, fg_color="transparent")
        vf.grid(row=row, column=0, sticky="ew", padx=14, pady=(12, 0)); row += 1
        self._video_path_var = tk.StringVar(value="")
        self._video_browse_btn = ctk.CTkButton(
            vf, text="🎥 Выбрать видео", width=150, height=32,
            font=ctk.CTkFont(size=12),
            fg_color="#2a3a2a", hover_color="#3a5a3a",
            command=self._browse_video)
        self._video_browse_btn.pack(side="left")
        self._video_name_lbl = ctk.CTkLabel(
            vf, text="не выбрано", font=ctk.CTkFont(size=12),
            text_color="#666", anchor="w")
        self._video_name_lbl.pack(side="left", padx=(10, 0))
        # Чекбокс референса — в той же строке справа
        self._ref_enabled_var = tk.BooleanVar(value=False)
        self._ref_enabled_cb = ctk.CTkCheckBox(
            vf,
            text="📷 Референс",
            variable=self._ref_enabled_var,
            font=ctk.CTkFont(size=12),
            command=self._on_ref_toggle,
        )
        self._ref_enabled_cb.pack(side="left", padx=(16, 0))

        self._ref_frame = ctk.CTkFrame(tab, fg_color="transparent")
        # НЕ grid — покажем только при включении чекбокса
        self._ref_frame.grid_columnconfigure(0, weight=1)
        self._ref_path_var = tk.StringVar(value="")
        self._ref_entry = ctk.CTkEntry(self._ref_frame, textvariable=self._ref_path_var,
                                       placeholder_text="Не выбрано")
        self._ref_entry.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self._ref_browse_btn = ctk.CTkButton(self._ref_frame, text="Обзор...", width=90,
                                             command=self._browse_ref)
        self._ref_browse_btn.grid(row=0, column=1)
        self._ref_frame_row = row   # запоминаем строку для grid/grid_remove
        row += 1  # строка зарезервирована под ref_frame

        # Параметры в сетке
        params = ctk.CTkFrame(tab, fg_color="transparent")
        params.grid(row=row, column=0, sticky="ew", padx=14, pady=(12, 0)); row += 1
        params.grid_columnconfigure(1, weight=1)
        params.grid_columnconfigure(3, weight=1)

        # Кол-во инфографик
        ctk.CTkLabel(params, text="Инфографик:", font=ctk.CTkFont(size=12)
                     ).grid(row=0, column=0, sticky="w", padx=(0, 8), pady=4)
        _infog_frame = ctk.CTkFrame(params, fg_color="transparent")
        _infog_frame.grid(row=0, column=1, sticky="w", padx=(0, 20), pady=4)
        self._count_var = ctk.CTkEntry(_infog_frame, width=65, justify="center")
        self._count_var.insert(0, "15")
        self._count_var.pack(side="left")
        self._count_var.bind("<FocusIn>",  self._on_infog_focus_in)
        self._count_var.bind("<FocusOut>", self._on_infog_focus_out)
        self._count_var.bind("<KeyPress>", lambda e: self._filter_int_key(e))
        self._count_max_btn = ctk.CTkButton(
            _infog_frame, text="MAX", width=44, height=28,
            font=ctk.CTkFont(size=11, weight="bold"),
            fg_color="#1e3d1e", hover_color="#2d5a2d",
            command=self._set_infog_max,
        )
        self._count_max_btn.pack(side="left", padx=(5, 0))

        # Качество
        ctk.CTkLabel(params, text="Качество:", font=ctk.CTkFont(size=12)
                     ).grid(row=0, column=2, sticky="w", padx=(0, 8), pady=4)
        self._quality_var = ctk.CTkComboBox(params, width=210,
                                             values=["1080p Качество", "Максимальное качество", "720p Быстро"],
                                             state="readonly",
                                             command=lambda v: self._auto_save())
        self._quality_var.set("1080p Качество")
        self._quality_var.grid(row=0, column=3, sticky="w", pady=4)

        # Длительность (диапазон)
        ctk.CTkLabel(params, text="Показывать, сек:", font=ctk.CTkFont(size=12)
                     ).grid(row=1, column=0, sticky="w", padx=(0, 8), pady=4)
        dur_range = ctk.CTkFrame(params, fg_color="transparent")
        dur_range.grid(row=1, column=1, columnspan=3, sticky="w", pady=4)
        ctk.CTkLabel(dur_range, text="от", font=ctk.CTkFont(size=12)).pack(side="left")
        self._duration_min_var = ctk.CTkEntry(dur_range, width=60)
        self._duration_min_var.insert(0, "8")
        self._duration_min_var.pack(side="left", padx=(4, 0))
        self._duration_min_var.bind("<KeyPress>", lambda e: self._filter_float_key(e))
        self._duration_min_var.bind("<FocusOut>", self._on_dur_min_focus_out)
        ctk.CTkLabel(dur_range, text="до", font=ctk.CTkFont(size=12)).pack(side="left", padx=(8, 0))
        self._duration_max_var = ctk.CTkEntry(dur_range, width=60)
        self._duration_max_var.insert(0, "16")
        self._duration_max_var.pack(side="left", padx=(4, 0))
        self._duration_max_var.bind("<KeyPress>", lambda e: self._filter_float_key(e))
        self._duration_max_var.bind("<FocusOut>", self._on_dur_max_focus_out)
        ctk.CTkLabel(dur_range, text="сек  (рандом для каждой картинки)",
                     font=ctk.CTkFont(size=11), text_color="#888").pack(side="left", padx=(8, 0))

        # Опции
        opts = ctk.CTkFrame(tab, fg_color="transparent")
        opts.grid(row=row, column=0, sticky="ew", padx=14, pady=(8, 0)); row += 1
        self._rerender_var = tk.BooleanVar(value=False)
        self._rerender_var_cb = ctk.CTkCheckBox(
            opts, text="🔄 Rerender only (пропустить генерацию, только рендер)",
            variable=self._rerender_var, font=ctk.CTkFont(size=12))
        self._rerender_var_cb.pack(side="left")
        self._animate_var = tk.BooleanVar(value=True)
        self._animate_var_cb = ctk.CTkCheckBox(
            opts, text="✨ Анимация входа/выхода",
            variable=self._animate_var, font=ctk.CTkFont(size=12))
        self._animate_var_cb.pack(side="left", padx=(18, 0))

        # Плакатный режим
        self._poster_row = ctk.CTkFrame(tab, fg_color="transparent")
        poster_row = self._poster_row
        poster_row.grid(row=row, column=0, sticky="ew", padx=14, pady=(6, 0)); row += 1
        self._poster_var = tk.BooleanVar(value=False)
        self._poster_cb  = ctk.CTkCheckBox(
            poster_row,
            text="📸 Подмешивать фото природы (растения, огород, без текста)",
            variable=self._poster_var,
            font=ctk.CTkFont(size=12),
            command=self._on_poster_toggle,
        )
        self._poster_cb.pack(side="left")

        poster_pct_frame = ctk.CTkFrame(poster_row, fg_color="transparent")
        poster_pct_frame.pack(side="left", padx=(16, 0))
        ctk.CTkLabel(poster_pct_frame, text="Доля:", font=ctk.CTkFont(size=11),
                     text_color="#aaa").pack(side="left")
        self._poster_ratio_var = tk.DoubleVar(value=0.35)
        self._poster_slider    = ctk.CTkSlider(
            poster_pct_frame, from_=0.1, to=0.9,
            variable=self._poster_ratio_var,
            width=100, state="disabled",
            command=self._on_poster_slider_change,
        )
        self._poster_slider.pack(side="left", padx=(4, 0))
        self._poster_pct_lbl = ctk.CTkLabel(
            poster_pct_frame, text="35%", width=36, font=ctk.CTkFont(size=11))
        self._poster_pct_lbl.pack(side="left", padx=(2, 0))

        # Pexels-микс — подмешивать реальные фото с Pexels (2-й пункт)
        self._pexels_mix_row = ctk.CTkFrame(tab, fg_color="transparent")
        pexels_mix_row = self._pexels_mix_row
        pexels_mix_row.grid(row=row, column=0, sticky="ew", padx=14, pady=(4, 0)); row += 1
        self._pexels_mix_var = tk.BooleanVar(value=False)
        self._pexels_mix_cb  = ctk.CTkCheckBox(
            pexels_mix_row,
            text="🔍 Подмешивать фото с Pexels",
            variable=self._pexels_mix_var,
            font=ctk.CTkFont(size=12),
            command=self._on_pexels_mix_toggle,
        )
        self._pexels_mix_cb.pack(side="left")
        pexels_pct_frame = ctk.CTkFrame(pexels_mix_row, fg_color="transparent")
        pexels_pct_frame.pack(side="left", padx=(16, 0))
        ctk.CTkLabel(pexels_pct_frame, text="Доля:", font=ctk.CTkFont(size=11),
                     text_color="#aaa").pack(side="left")
        self._pexels_mix_ratio_var = tk.DoubleVar(value=0.30)
        self._pexels_mix_slider    = ctk.CTkSlider(
            pexels_pct_frame, from_=0.1, to=0.9,
            variable=self._pexels_mix_ratio_var,
            width=100, state="disabled",
            command=self._on_pexels_mix_slider_change,
        )
        self._pexels_mix_slider.pack(side="left", padx=(4, 0))
        self._pexels_mix_pct_lbl = ctk.CTkLabel(
            pexels_pct_frame, text="30%", width=36, font=ctk.CTkFont(size=11))
        self._pexels_mix_pct_lbl.pack(side="left", padx=(2, 0))

        # Видеомикс — подмешивать клипы из папки (3-й пункт)
        vmix_row = ctk.CTkFrame(tab, fg_color="transparent")
        vmix_row.grid(row=row, column=0, sticky="ew", padx=14, pady=(4, 0)); row += 1
        self._vmix_var = tk.BooleanVar(value=False)
        self._vmix_cb  = ctk.CTkCheckBox(
            vmix_row,
            text="🎬 Подмешивать видео из папки",
            variable=self._vmix_var,
            font=ctk.CTkFont(size=12),
            command=self._on_vmix_toggle,
        )
        self._vmix_cb.pack(side="left")
        vmix_pct_frame = ctk.CTkFrame(vmix_row, fg_color="transparent")
        vmix_pct_frame.pack(side="left", padx=(16, 0))
        ctk.CTkLabel(vmix_pct_frame, text="Доля:", font=ctk.CTkFont(size=11),
                     text_color="#aaa").pack(side="left")
        self._vmix_ratio_var = tk.DoubleVar(value=0.25)
        self._vmix_slider    = ctk.CTkSlider(
            vmix_pct_frame, from_=0.1, to=0.9,
            variable=self._vmix_ratio_var,
            width=100, state="disabled",
            command=self._on_vmix_slider_change,
        )
        self._vmix_slider.pack(side="left", padx=(4, 0))
        self._vmix_pct_lbl = ctk.CTkLabel(
            vmix_pct_frame, text="25%", width=36, font=ctk.CTkFont(size=11))
        self._vmix_pct_lbl.pack(side="left", padx=(2, 0))

        self._vmix_dir_row = ctk.CTkFrame(tab, fg_color="transparent")
        self._vmix_dir_row.grid(row=row, column=0, sticky="ew", padx=14, pady=(2, 0))
        self._vmix_dir_row.grid_remove()   # скрыта по умолчанию
        row += 1
        self._vmix_dir_var = tk.StringVar(value="")
        self._vmix_browse_btn = ctk.CTkButton(
            self._vmix_dir_row, text="📂 Выбрать папку с клипами", width=210, height=28,
            font=ctk.CTkFont(size=12), fg_color="#2a2a2a", hover_color="#3a3a3a",
            command=self._browse_vmix_dir,
        )
        self._vmix_browse_btn.pack(side="left")
        self._vmix_dir_lbl = ctk.CTkLabel(
            self._vmix_dir_row, text="не выбрана", font=ctk.CTkFont(size=11),
            text_color="#888")
        self._vmix_dir_lbl.pack(side="left", padx=(8, 0))

        # Итоговое распределение типов контента
        mix_totals_row = ctk.CTkFrame(tab, fg_color="transparent")
        mix_totals_row.grid(row=row, column=0, sticky="ew", padx=14, pady=(4, 2)); row += 1
        self._mix_totals_lbl = ctk.CTkLabel(
            mix_totals_row,
            text="🖼 Инфографика: 100%  |  📸 Фото: откл.  |  🎬 Видео: откл.",
            font=ctk.CTkFont(size=11), text_color="#888",
        )
        self._mix_totals_lbl.pack(side="left")

        # По умолчанию источник FastGen:
        # показываем poster-микс (AI фото природы), скрываем Pexels-микс
        self._pexels_mix_row.grid_remove()

        self._advanced_expanded = False

        # Логотип канала (скрыт по умолчанию)
        self._logo_row = ctk.CTkFrame(tab, fg_color="transparent")
        self._logo_row.grid(row=row, column=0, sticky="ew", padx=14, pady=(6, 0))
        self._logo_row.grid_remove()
        logo_row = self._logo_row
        row += 1
        self._logo_var = tk.BooleanVar(value=False)
        self._logo_var_cb = ctk.CTkCheckBox(
            logo_row,
            text="🔵 Логотип канала (правый нижний угол)",
            variable=self._logo_var,
            font=ctk.CTkFont(size=12),
            command=self._on_logo_toggle,
        )
        self._logo_var_cb.pack(side="left")

        logo_size_frame = ctk.CTkFrame(logo_row, fg_color="transparent")
        logo_size_frame.pack(side="left", padx=(16, 0))
        ctk.CTkLabel(logo_size_frame, text="Размер:", font=ctk.CTkFont(size=11),
                     text_color="#aaa").pack(side="left")
        self._logo_size_var = tk.IntVar(value=80)
        self._logo_size_slider = ctk.CTkSlider(
            logo_size_frame, from_=40, to=200,
            variable=self._logo_size_var,
            width=100, state="disabled",
            command=self._on_logo_size_change,
        )
        self._logo_size_slider.pack(side="left", padx=(4, 0))
        self._logo_size_lbl = ctk.CTkLabel(
            logo_size_frame, text="80px", width=44, font=ctk.CTkFont(size=11))
        self._logo_size_lbl.pack(side="left", padx=(2, 0))
        # Превью логотипа (кружок, обновляется при выборе файла и изменении слайдера)
        self._logo_preview_img = None   # держим ссылку чтобы PIL не собрал GC
        self._logo_preview_lbl = ctk.CTkLabel(
            logo_size_frame, text="", width=64, height=64,
            fg_color="#2a2a2a", corner_radius=32)
        self._logo_preview_lbl.pack(side="left", padx=(10, 0))

        self._logo_file_row = ctk.CTkFrame(tab, fg_color="transparent")
        self._logo_file_row.grid(row=row, column=0, sticky="ew", padx=14, pady=(2, 0))
        self._logo_file_row.grid_remove()
        logo_file_row = self._logo_file_row
        row += 1
        self._logo_path_var = tk.StringVar(value="")
        self._logo_browse_btn = ctk.CTkButton(
            logo_file_row, text="📁 Выбрать файл логотипа", width=200, height=28,
            font=ctk.CTkFont(size=12), fg_color="#2a2a2a", hover_color="#3a3a3a",
            state="disabled", command=self._browse_logo,
        )
        self._logo_browse_btn.pack(side="left")
        self._logo_name_lbl = ctk.CTkLabel(
            logo_file_row, text="не выбран", font=ctk.CTkFont(size=11),
            text_color="#888")
        self._logo_name_lbl.pack(side="left", padx=(8, 0))

        # (кнопки вынесены в _build_ui — всегда видимы под вкладками)

    def _build_zone_tab(self):
        tab = self._tab_zones
        tab.grid_rowconfigure(1, weight=1)
        tab.grid_columnconfigure(0, weight=1)

        header = ctk.CTkFrame(tab, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", padx=10, pady=(8, 0))
        ctk.CTkLabel(header, text="Нарисуйте зоны, где будут появляться инфографики (до 4 штук)",
                     font=ctk.CTkFont(size=12)).pack(side="left")
        ctk.CTkButton(header, text="🗑 Очистить зоны", width=140, height=28,
                      fg_color="#8b4513", command=self._clear_zones).pack(side="right")

        self._zone_canvas = ZoneCanvas(tab, bg="#1a1a1a")
        self._zone_canvas.grid(row=1, column=0, sticky="nsew", padx=10, pady=(6, 10))

    # ── Навигация и действия ─────────────────────────────────────────────────

    def _browse_video(self):
        path = filedialog.askopenfilename(
            title="Выберите видео", filetypes=[("MP4 files", "*.mp4"), ("All files", "*.*")])
        if path:
            self._video_path_var.set(path)
            self._video_name_lbl.configure(
                text=os.path.basename(path), text_color="#dddddd")
            # trace_add сработает автоматически

    def _on_tab_change(self):
        """Перерисовывает Zone Editor когда пользователь переключается на эту вкладку."""
        try:
            if self._tabs.get() == "📐 Zone Editor":
                # Даём время на layout и перерисовываем
                self.after(50, self._zone_canvas._full_redraw)
        except Exception:
            pass

    def _on_video_path_changed(self, *_):
        path = self._video_path_var.get().strip()
        if path and os.path.isfile(path):
            threading.Thread(target=self._extract_video_frame,
                             args=(path,), daemon=True).start()

    def _extract_video_frame(self, video_path: str):
        """Извлекает кадр из видео (фоновый поток) и обновляет Zone Editor."""
        try:
            from PIL import Image as _Img
            ensure_dirs(config.CACHE_DIR)
            frame_path = os.path.join(config.CACHE_DIR, "zone_preview.jpg")
            # Берём кадр на 5-й секунде; если видео короче — на 0-й
            for seek in ("5", "0"):
                result = subprocess.run(
                    ["ffmpeg", "-y", "-ss", seek, "-i", video_path,
                     "-vframes", "1", "-q:v", "3", frame_path],
                    capture_output=True, timeout=15
                )
                if os.path.isfile(frame_path) and os.path.getsize(frame_path) > 0:
                    break
            if not os.path.isfile(frame_path) or os.path.getsize(frame_path) == 0:
                return
            img = _Img.open(frame_path).convert("RGB")
            # Обновляем canvas из главного потока
            self.after(0, lambda: self._zone_canvas.set_background_image(img))
        except Exception as exc:
            self._log_q.put(f"[zone] Не удалось загрузить кадр: {exc}")

    def _on_ref_toggle(self):
        if self._ref_enabled_var.get():
            self._ref_frame.grid(row=self._ref_frame_row, column=0,
                                 sticky="ew", padx=14, pady=(2, 0))
        else:
            self._ref_frame.grid_remove()

    def _browse_ref(self):
        path = filedialog.askopenfilename(
            title="Выберите референсный JPG",
            filetypes=[("Image files", "*.jpg *.jpeg *.png"), ("All files", "*.*")])
        if path:
            self._ref_path_var.set(path)

    def _clear_zones(self):
        self._zone_canvas.clear_zones()

    def _clear_log(self):
        self._log_text.configure(state="normal")
        self._log_text.delete("1.0", "end")
        self._log_text.configure(state="disabled")

    def _copy_log(self):
        """Копирует весь текст лога в буфер обмена."""
        text = self._log_text.get("1.0", "end").strip()
        if text:
            self.clipboard_clear()
            self.clipboard_append(text)
            self._log("✓ Лог скопирован в буфер обмена.")

    def _open_output_dir(self):
        """Открывает папку output в Finder / Explorer."""
        folder = config.OUTPUT_DIR
        ensure_dirs(folder)
        if sys.platform == "darwin":
            subprocess.run(["open", folder])
        elif sys.platform == "win32":
            subprocess.run(["explorer", folder])
        else:
            subprocess.run(["xdg-open", folder])

    def _open_output(self):
        if self._output_path and os.path.isfile(self._output_path):
            if sys.platform == "darwin":
                subprocess.run(["open", self._output_path])
            elif sys.platform == "win32":
                os.startfile(self._output_path)
            else:
                subprocess.run(["xdg-open", self._output_path])

    # ── Настройки ────────────────────────────────────────────────────────────

    def _load_settings_to_ui(self):
        self._loading = True
        try:
            self._load_settings_to_ui_inner()
        finally:
            self._loading = False

    def _load_settings_to_ui_inner(self):
        s = config.load_settings()

        def _fill(entry: ctk.CTkEntry, value: str):
            """Вставляет значение и скрывает поле, если оно непустое."""
            entry.delete(0, "end")
            entry.insert(0, value)
            if value:
                toggle = getattr(entry, "_toggle_hide", None)
                if toggle and not getattr(entry, "_is_hidden", False):
                    toggle()
                    entry._is_hidden = True   # флаг чтобы не скрывать дважды

        _fill(self._asm_key,     s.get("ASSEMBLYAI_API_KEY", ""))
        _fill(self._fastgen_key, s.get("FASTGEN_API_KEY", ""))
        _fill(self._pexels_key,  s.get("PEXELS_API_KEY", ""))
        _fill(self._gemini_key,  s.get("GEMINI_API_KEY", ""))
        config.GEMINI_API_KEY = s.get("GEMINI_API_KEY", "")
        # OpenAI — скрытое поле: восстанавливаем сохранённый access_token
        oai = s.get("OPENAI_ACCESS_TOKEN", "")
        self._openai_refresh = s.get("OPENAI_REFRESH_TOKEN", "")
        if oai:
            self._openai_key.delete(0, "end")
            self._openai_key.insert(0, oai)
            config.OPENAI_API_KEY = oai
            self._openai_set_connected(True, user_info=None)

        # Claude — восстанавливаем токен
        cl = s.get("CLAUDE_ACCESS_TOKEN", "")
        self._claude_refresh = s.get("CLAUDE_REFRESH_TOKEN", "")
        if cl:
            self._claude_token_field.delete(0, "end")
            self._claude_token_field.insert(0, cl)
            config.CLAUDE_ACCESS_TOKEN = cl
            self._claude_set_connected(True, user_info=None)

        # Восстанавливаем выбор "Кто пишет промпты"
        saved_be = s.get("ai_backend_ui", "")
        _be_choices = ["Авто (без AI)", "Gemini (Google)", "Claude (Anthropic)", "ChatGPT (OpenAI)"]
        if saved_be in _be_choices:
            self._ai_backend_combo.set(saved_be)
        elif cl:
            self._ai_backend_combo.set("Claude (Anthropic)")
        elif s.get("GEMINI_API_KEY", ""):
            self._ai_backend_combo.set("Gemini (Google)")
        elif oai:
            self._ai_backend_combo.set("ChatGPT (OpenAI)")
        else:
            self._ai_backend_combo.set("Авто (без AI)")
        self._on_ai_backend_change()

        saved_engine = s.get("engine", "NARWHAL")
        # Миграция старых настроек: если engine был PEXELS в старом dropdown → Pexels-источник
        if saved_engine == "PEXELS":
            saved_source = s.get("img_source", "Pexels")
            # Сбрасываем на дефолтный FastGen движок
            self._engine_var.set(config.FASTGEN_DEFAULT_ENGINE)
        else:
            saved_source = s.get("img_source", "FastGen")
            if saved_engine:
                self._engine_var.set(saved_engine)
        self._img_source_seg.set(saved_source)
        self._on_img_source_change(saved_source)
        self._animate_var.set(bool(s.get("animate", True)))
        # Диапазон длительности показа
        self._duration_min_var.delete(0, "end")
        self._duration_min_var.insert(0, str(s.get("duration_min", 8)))
        self._duration_max_var.delete(0, "end")
        self._duration_max_var.insert(0, str(s.get("duration_max", 16)))
        # Качество рендера
        saved_quality = s.get("quality", "1080p Качество")
        self._quality_var.set(saved_quality)
        self._poster_var.set(bool(s.get("poster_mix", False)))
        self._poster_ratio_var.set(float(s.get("poster_ratio", 0.35)))
        self._poster_pct_lbl.configure(text=f"{int(float(s.get('poster_ratio', 0.35))*100)}%")
        self._poster_slider.configure(state="normal" if self._poster_var.get() else "disabled")
        # Логотип
        self._logo_var.set(bool(s.get("logo_enabled", False)))
        logo_size = int(s.get("logo_size", 80))
        self._logo_size_var.set(logo_size)
        self._logo_size_lbl.configure(text=f"{logo_size}px")
        logo_path = str(s.get("logo_path", ""))
        self._logo_path_var.set(logo_path)
        if logo_path:
            self._logo_name_lbl.configure(text=os.path.basename(logo_path), text_color="#cccccc")
            self._update_logo_preview()
        logo_state = "normal" if self._logo_var.get() else "disabled"
        self._logo_size_slider.configure(state=logo_state)
        self._logo_browse_btn.configure(state=logo_state)
        # Видеомикс
        vmix_enabled = bool(s.get("video_mix_enabled", False))
        self._vmix_var.set(vmix_enabled)
        vmix_ratio = float(s.get("video_mix_ratio", 0.25))
        self._vmix_ratio_var.set(vmix_ratio)
        self._vmix_pct_lbl.configure(text=f"{int(vmix_ratio*100)}%")
        vmix_dir = str(s.get("video_mix_dir", ""))
        self._vmix_dir_var.set(vmix_dir)
        if vmix_dir:
            self._vmix_dir_lbl.configure(text=os.path.basename(vmix_dir), text_color="#dddddd")
        self._vmix_slider.configure(state="normal" if vmix_enabled else "disabled")
        if vmix_enabled:
            self._vmix_dir_row.grid()
        else:
            self._vmix_dir_row.grid_remove()
        # Pexels-микс
        pexels_mix_enabled = bool(s.get("pexels_mix_enabled", False))
        self._pexels_mix_var.set(pexels_mix_enabled)
        pexels_mix_ratio = float(s.get("pexels_mix_ratio", 0.30))
        self._pexels_mix_ratio_var.set(pexels_mix_ratio)
        self._pexels_mix_pct_lbl.configure(text=f"{int(pexels_mix_ratio*100)}%")
        self._pexels_mix_slider.configure(state="normal" if pexels_mix_enabled else "disabled")
        self._update_mix_totals()
        # Зоны намеренно НЕ восстанавливаются — всегда начинаем с чистого листа (полный экран)
        self._log(f"Настройки загружены. Папка приложения: {config._app_dir()}")
        # Запускаем проверку ключей через 2 секунды (UI уже построен)
        self.after(2000, self._validate_all_keys)

    def _auto_save(self):
        """Тихое авто-сохранение без диалога — вызывается при любом изменении поля."""
        if getattr(self, "_loading", False):
            return  # не сохраняем пока идёт начальная загрузка настроек
        self._save_settings(silent=True)

    def _save_settings(self, silent: bool = False):
        data = {
            "ASSEMBLYAI_API_KEY": self._asm_key.get().strip(),
            "FASTGEN_API_KEY":    self._fastgen_key.get().strip(),
            "PEXELS_API_KEY":     self._pexels_key.get().strip(),
            "GEMINI_API_KEY":     self._gemini_key.get().strip(),
            "OPENAI_ACCESS_TOKEN":   self._openai_key.get().strip(),
            "OPENAI_REFRESH_TOKEN":  getattr(self, "_openai_refresh", ""),
            "CLAUDE_ACCESS_TOKEN":   self._claude_token_field.get().strip(),
            "CLAUDE_REFRESH_TOKEN":  getattr(self, "_claude_refresh", ""),
            "ai_backend_ui":      self._ai_backend_combo.get(),
            "engine":             self._engine_var.get().strip(),
            "img_source":         self._img_source_seg.get(),
            "animate":            self._animate_var.get(),
            "poster_mix":         self._poster_var.get(),
            "poster_ratio":       round(self._poster_ratio_var.get(), 2),
            "logo_enabled":       self._logo_var.get(),
            "logo_size":          int(self._logo_size_var.get()),
            "logo_path":          self._logo_path_var.get(),
            "duration_min":       self._get_duration()[0],
            "duration_max":       self._get_duration()[1],
            "video_mix_enabled":  self._vmix_var.get(),
            "video_mix_dir":      self._vmix_dir_var.get(),
            "video_mix_ratio":    round(self._vmix_ratio_var.get(), 2),
            "pexels_mix_enabled": self._pexels_mix_var.get(),
            "pexels_mix_ratio":   round(self._pexels_mix_ratio_var.get(), 2),
            "quality":            self._quality_var.get(),
            # manual_zones не сохраняем — при старте всегда полный экран
        }
        config.save_settings(data)
        config.apply_settings(data)
        if not silent:
            self._log("✓ Настройки сохранены.")

    # ── Запуск пайплайна ─────────────────────────────────────────────────────

    def _get_duration(self) -> tuple[float, float]:
        """Возвращает (min_sec, max_sec) для рандомной длительности показа картинки."""
        try:
            mn = float(self._duration_min_var.get())
        except Exception:
            mn = 8.0
        try:
            mx = float(self._duration_max_var.get())
        except Exception:
            mx = 16.0
        mn = max(1.0, mn)
        mx = max(mn, mx)
        return mn, mx

    # ── Ввод только цифр / цифр+точки ───────────────────────────────────────

    @staticmethod
    def _filter_int_key(event):
        """Блокирует любые печатаемые символы кроме цифр."""
        if event.char and event.char.isprintable() and not event.char.isdigit():
            return "break"

    @staticmethod
    def _filter_float_key(event):
        """Блокирует любые печатаемые символы кроме цифр и точки."""
        if event.char and event.char.isprintable() and event.char not in "0123456789.":
            return "break"

    # ── Поле «Инфографик» ────────────────────────────────────────────────────

    @staticmethod
    def _fmt_sec(v: float) -> str:
        """Форматирует секунды: целые без .0, дробные как есть."""
        return str(int(v)) if v == int(v) else str(v)

    def _on_dur_min_focus_out(self, _event=None):
        """«от»: минимум 1. Если «до» стало меньше «от» — подтягивает «до» вверх."""
        try:
            mn = float(self._duration_min_var.get())
        except ValueError:
            mn = 8.0
        mn = max(1.0, mn)
        self._duration_min_var.delete(0, "end")
        self._duration_min_var.insert(0, self._fmt_sec(mn))
        # Если «до» < «от» — исправляем «до»
        try:
            mx = float(self._duration_max_var.get())
        except ValueError:
            mx = mn
        if mx < mn:
            self._duration_max_var.delete(0, "end")
            self._duration_max_var.insert(0, self._fmt_sec(min(mn, 20.0)))

    def _on_dur_max_focus_out(self, _event=None):
        """«до»: максимум 20 сек, не меньше «от»."""
        try:
            mx = float(self._duration_max_var.get())
        except ValueError:
            mx = 16.0
        mx = max(1.0, min(mx, 20.0))
        try:
            mn = float(self._duration_min_var.get())
        except ValueError:
            mn = 1.0
        mn = max(1.0, mn)
        if mx < mn:
            mx = mn
        self._duration_max_var.delete(0, "end")
        self._duration_max_var.insert(0, self._fmt_sec(mx))

    def _calc_infog_max(self) -> int:
        """Возвращает максимальное кол-во инфографик исходя из длины клипа и значения «до»."""
        vid_dur = self._get_video_duration()
        if vid_dur <= 0:
            return 99  # видео не выбрано — без ограничения
        _, dur_max = self._get_duration()
        return max(1, int(vid_dur / max(1.0, dur_max)))

    def _set_infog_max(self):
        """Кнопка MAX — подставляет максимально допустимое число."""
        mx = self._calc_infog_max()
        self._count_var.delete(0, "end")
        self._count_var.insert(0, str(mx))

    def _on_infog_focus_in(self, _event=None):
        """Очищаем поле при входе фокуса — удобно для ввода нового значения."""
        self._count_var.delete(0, "end")

    def _on_infog_focus_out(self, _event=None):
        """При потере фокуса: пусто → 15; > MAX → зажать до MAX; < 1 → 1."""
        val = self._count_var.get().strip()
        if not val:
            n = 15
        else:
            try:
                n = int(val)
            except ValueError:
                n = 15
        n = max(1, n)
        mx = self._calc_infog_max()
        if n > mx:
            n = mx
        self._count_var.delete(0, "end")
        self._count_var.insert(0, str(n))

    def _get_video_duration(self) -> float:
        """Возвращает длительность выбранного видео в секундах через ffprobe (0 при ошибке)."""
        path = self._video_path_var.get().strip()
        if not path or not os.path.isfile(path):
            return 0.0
        try:
            r = subprocess.run(
                ["ffprobe", "-v", "quiet", "-print_format", "json", "-show_streams", path],
                capture_output=True, timeout=15,
            )
            info = json.loads(r.stdout)
            for st in info.get("streams", []):
                if st.get("codec_type") == "video":
                    return float(st.get("duration", 0))
        except Exception:
            pass
        return 0.0

    def _get_max_n(self) -> int:
        val = self._count_var.get().strip()
        try:
            return max(1, int(val))
        except Exception:
            return 15

    def _get_quality(self) -> str:
        val = self._quality_var.get()
        if "Макс" in val or "High" in val or "highq" in val:
            return "highq"
        if "1080" in val:
            return "1080"
        return "720fast"

    def _start_run(self):
        # Закрываем «Расширенные» если открыты
        if self._advanced_expanded:
            self._toggle_advanced()

        video_path = self._video_path_var.get().strip()
        if not video_path:
            messagebox.showerror("Ошибка", "Выберите видеофайл MP4!")
            return
        if not os.path.isfile(video_path):
            messagebox.showerror("Ошибка", f"Файл не найден:\n{video_path}")
            return
        if not video_path.lower().endswith(".mp4"):
            messagebox.showerror("Ошибка", "Нужен файл в формате .mp4")
            return

        # ── Зажать кол-во инфографик до максимума для данного ролика ─────────
        max_possible = self._calc_infog_max()
        max_n = min(self._get_max_n(), max_possible)
        self._count_var.delete(0, "end")
        self._count_var.insert(0, str(max_n))

        # ── Проверка обязательных ключей ─────────────────────────────────────
        missing = []
        if not self._asm_key.get().strip():
            missing.append("• AssemblyAI API Key (транскрипция)")
        if self._img_source_seg.get() == "Pexels":
            if not self._pexels_key.get().strip():
                missing.append("• Pexels API Key (поиск фотографий)")
        else:
            if not self._fastgen_key.get().strip():
                missing.append("• FastGen API Key (генерация изображений)")
        if missing:
            messagebox.showerror(
                "Не заполнены ключи",
                "Для запуска нужны все API-ключи. Отсутствуют:\n\n" + "\n".join(missing)
            )
            return

        # Применяем актуальные ключи из UI перед запуском
        config.apply_settings({
            "ASSEMBLYAI_API_KEY":  self._asm_key.get().strip(),
            "FASTGEN_API_KEY":     self._fastgen_key.get().strip(),
            "PEXELS_API_KEY":      self._pexels_key.get().strip(),
            "GEMINI_API_KEY":      self._gemini_key.get().strip(),
            "OPENAI_ACCESS_TOKEN": self._openai_key.get().strip(),
            "CLAUDE_ACCESS_TOKEN": self._claude_token_field.get().strip(),
        })

        # Зона по умолчанию — весь экран. Если список пустой, используем full-screen,
        # а не None (None переключал в side-panel режим, что не то что нужно).
        _zones = self._zone_canvas.zones
        if not _zones:
            _zones = [[0.0, 0.0, 1.0, 1.0]]

        params = {
            "video_path":    video_path,
            "max_n":         self._get_max_n(),
            "quality":       self._get_quality(),
            "display_sec_min": self._get_duration()[0],
            "display_sec_max": self._get_duration()[1],
            "rerender_only": self._rerender_var.get(),
            "engine":        self._engine_var.get().strip(),
            "img_source":    self._img_source_seg.get(),
            "ai_backend":    {
                "Gemini (Google)":    "gemini",
                "Claude (Anthropic)": "claude",
                "ChatGPT (OpenAI)":   "chatgpt",
            }.get(self._ai_backend_combo.get(), "auto"),
            "animate":       self._animate_var.get(),
            "manual_zones":  _zones,
            "poster_mix":    self._poster_var.get(),
            "poster_ratio":  round(self._poster_ratio_var.get(), 2),
            "logo_enabled":  self._logo_var.get(),
            "logo_size":     int(self._logo_size_var.get()),
            "logo_path":     self._logo_path_var.get(),
            "video_mix_enabled":  self._vmix_var.get(),
            "video_mix_dir":      self._vmix_dir_var.get(),
            "video_mix_ratio":    round(self._vmix_ratio_var.get(), 2),
            "pexels_mix_enabled": self._pexels_mix_var.get(),
            "pexels_mix_ratio":   round(self._pexels_mix_ratio_var.get(), 2),
        }

        import datetime as _dt
        base = sanitize_filename(os.path.splitext(os.path.basename(video_path))[0])
        ts   = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        run_dir = os.path.join(config.OUTPUT_DIR, f"{base}_{ts}")
        ensure_dirs(run_dir)
        params["output_path"] = os.path.join(run_dir, f"{base}_garden.mp4")

        self._running = True
        self._run_start_time = time.time()   # фиксируем старт для таймера
        self._set_controls_locked(True)
        self._start_btn.configure(
            text="⏹  СТОП",
            fg_color="#8b0000", hover_color="#5c0000",
            command=self._stop_run,
        )
        self._progress.set(0)

        self._log("=" * 50)
        self._log(f"СТАРТ  |  Видео: {os.path.basename(video_path)}")
        self._log(f"Инфографик: {params['max_n']}  |  AI: {params['ai_backend'].upper()}")
        self._log(f"Качество: {params['quality']}  |  Длительность: {params['display_sec_min']}–{params['display_sec_max']}с")
        self._log("=" * 50)

        self._worker = threading.Thread(
            target=self._run_pipeline, args=(params,), daemon=True)
        self._worker.start()

    def _set_controls_locked(self, locked: bool):
        """Блокирует/разблокирует все настройки во время рендера."""
        s_all   = "disabled" if locked else "normal"
        # Учитываем зависимые состояния при разблокировке
        s_poster = "disabled" if locked else ("normal" if self._poster_var.get() else "disabled")
        s_logo   = "disabled" if locked else ("normal" if self._logo_var.get() else "disabled")

        # Видеофайл и референс
        self._video_browse_btn.configure(state=s_all)
        # ref_frame может быть скрыт — блокируем виджеты внутри только если видимы
        self._ref_entry.configure(state=s_all)
        self._ref_browse_btn.configure(state=s_all)
        self._ref_enabled_cb.configure(state=s_all)

        # Параметры
        self._count_var.configure(state=s_all)
        self._count_max_btn.configure(state=s_all)
        self._quality_var.configure(state=s_all)
        self._duration_min_var.configure(state=s_all)
        self._duration_max_var.configure(state=s_all)

        # Чекбоксы опций
        self._rerender_var_cb.configure(state=s_all)
        self._animate_var_cb.configure(state=s_all)

        # Плакаты
        self._poster_cb.configure(state=s_all)
        self._poster_slider.configure(state=s_poster)

        # Видеомикс
        s_vmix = "disabled" if locked else ("normal" if self._vmix_var.get() else "disabled")
        self._vmix_cb.configure(state=s_all)
        self._vmix_slider.configure(state=s_vmix)

        # Pexels-микс
        s_pexels = "disabled" if locked else ("normal" if self._pexels_mix_var.get() else "disabled")
        self._pexels_mix_cb.configure(state=s_all)
        self._pexels_mix_slider.configure(state=s_pexels)

        # Логотип
        self._logo_var_cb.configure(state=s_all)
        self._logo_size_slider.configure(state=s_logo)
        self._logo_browse_btn.configure(state=s_logo)

    def _on_pexels_mix_toggle(self):
        enabled = self._pexels_mix_var.get()
        self._pexels_mix_slider.configure(state="normal" if enabled else "disabled")
        self._update_mix_totals()
        self._auto_save()

    def _on_pexels_mix_slider_change(self, v):
        self._pexels_mix_pct_lbl.configure(text=f"{int(float(v)*100)}%")
        self._update_mix_totals()
        self._auto_save()

    def _on_img_source_change(self, value: str):
        """Переключает видимость блоков FastGen / Pexels и соответствующих опций микса."""
        is_pexels = (value == "Pexels")

        # Настройки источника в sidebar
        if is_pexels:
            self._fastgen_frame.grid_remove()
            self._pexels_src_frame.grid()
        else:
            self._pexels_src_frame.grid_remove()
            self._fastgen_frame.grid()

        # Опции микса в основной вкладке:
        # FastGen → показываем "Подмешивать фото природы" (AI FastGen), скрываем Pexels-микс
        # Pexels  → показываем "Подмешивать фото с Pexels", скрываем poster-микс
        if hasattr(self, "_poster_row") and hasattr(self, "_pexels_mix_row"):
            if is_pexels:
                self._poster_row.grid_remove()
                self._pexels_mix_row.grid()
            else:
                self._pexels_mix_row.grid_remove()
                self._poster_row.grid()

        self._update_mix_totals()
        self._auto_save()

    def _get_engine(self) -> str:
        """Возвращает движок с учётом выбранного источника."""
        if hasattr(self, "_img_source_seg") and self._img_source_seg.get() == "Pexels":
            return "PEXELS"
        return self._engine_var.get()

    def _on_engine_change(self, value: str):
        pass   # оставлен для совместимости, логика перенесена в _on_img_source_change

    def _on_poster_toggle(self):
        enabled = self._poster_var.get()
        self._poster_slider.configure(state="normal" if enabled else "disabled")
        self._update_mix_totals()
        self._auto_save()

    def _on_vmix_toggle(self):
        enabled = self._vmix_var.get()
        self._vmix_slider.configure(state="normal" if enabled else "disabled")
        if enabled:
            self._vmix_dir_row.grid()
        else:
            self._vmix_dir_row.grid_remove()
        self._update_mix_totals()
        self._auto_save()

    def _on_poster_slider_change(self, v):
        self._poster_pct_lbl.configure(text=f"{int(float(v)*100)}%")
        self._update_mix_totals()
        self._auto_save()

    def _on_vmix_slider_change(self, v):
        self._vmix_pct_lbl.configure(text=f"{int(float(v)*100)}%")
        self._update_mix_totals()
        self._auto_save()

    def _update_mix_totals(self):
        """Enforce poster+video+pexels ≤ 90% and update summary label."""
        MAX_TOTAL = 0.90
        MIN_EACH  = 0.10
        p_on = self._poster_var.get()
        v_on = self._vmix_var.get()
        x_on = self._pexels_mix_var.get()   # pexels mix
        p = round(self._poster_ratio_var.get(),    2)
        v = round(self._vmix_ratio_var.get(),      2)
        x = round(self._pexels_mix_ratio_var.get(),2)

        active = [(p_on, "p"), (v_on, "v"), (x_on, "x")]
        n_on   = sum(1 for on, _ in active if on)

        if n_on >= 2:
            # Clamp each active slider so the sum of all active ≤ MAX_TOTAL
            others_p = (v if v_on else 0) + (x if x_on else 0)
            others_v = (p if p_on else 0) + (x if x_on else 0)
            others_x = (p if p_on else 0) + (v if v_on else 0)

            if p_on:
                p_max = max(MIN_EACH, round(MAX_TOTAL - others_p, 2))
                self._poster_slider.configure(to=p_max)
                if p > p_max:
                    p = p_max; self._poster_ratio_var.set(p)
                    self._poster_pct_lbl.configure(text=f"{int(p*100)}%")
            if v_on:
                v_max = max(MIN_EACH, round(MAX_TOTAL - others_v, 2))
                self._vmix_slider.configure(to=v_max)
                if v > v_max:
                    v = v_max; self._vmix_ratio_var.set(v)
                    self._vmix_pct_lbl.configure(text=f"{int(v*100)}%")
            if x_on:
                x_max = max(MIN_EACH, round(MAX_TOTAL - others_x, 2))
                self._pexels_mix_slider.configure(to=x_max)
                if x > x_max:
                    x = x_max; self._pexels_mix_ratio_var.set(x)
                    self._pexels_mix_pct_lbl.configure(text=f"{int(x*100)}%")
        else:
            if p_on: self._poster_slider.configure(to=0.9)
            if v_on: self._vmix_slider.configure(to=0.9)
            if x_on: self._pexels_mix_slider.configure(to=0.9)

        total_used = (p if p_on else 0) + (v if v_on else 0) + (x if x_on else 0)
        infog_pct  = max(0, int(round((1.0 - total_used) * 100)))
        color      = "#4CAF50" if infog_pct >= 10 else "#f44336"

        is_pexels_src = hasattr(self, "_img_source_seg") and self._img_source_seg.get() == "Pexels"
        parts = [f"🖼 Инфографика: {infog_pct}%"]
        if is_pexels_src:
            # Pexels — основной источник, подмешиваются Pexels-фото
            parts.append(f"🔍 Pexels: {int(x*100)}%" if x_on else "🔍 Pexels: откл.")
        else:
            # FastGen — основной источник, подмешиваются AI-фото природы
            parts.append(f"📸 Фото: {int(p*100)}%" if p_on else "📸 Фото: откл.")
        parts.append(f"🎬 Видео: {int(v*100)}%" if v_on else "🎬 Видео: откл.")
        self._mix_totals_lbl.configure(text="  |  ".join(parts), text_color=color)

    def _browse_vmix_dir(self):
        path = filedialog.askdirectory(title="Выберите папку с видеоклипами")
        if path:
            self._vmix_dir_var.set(path)
            self._vmix_dir_lbl.configure(text=os.path.basename(path), text_color="#dddddd")
            self._auto_save()

    def _toggle_advanced(self):
        self._advanced_expanded = not self._advanced_expanded
        if self._advanced_expanded:
            self._adv_btn.configure(text="▼  Расширенные")
            self._logo_row.grid()
            self._logo_file_row.grid()
            self._log_frame.grid_remove()
        else:
            self._adv_btn.configure(text="▶  Расширенные")
            self._logo_row.grid_remove()
            self._logo_file_row.grid_remove()
            self._log_frame.grid()

    def _on_logo_toggle(self):
        enabled = self._logo_var.get()
        state = "normal" if enabled else "disabled"
        self._logo_size_slider.configure(state=state)
        self._logo_browse_btn.configure(state=state)
        if not enabled:
            self._logo_path_var.set("")
            self._logo_name_lbl.configure(text="не выбран", text_color="#555")
            self._logo_preview_lbl.configure(image=None, text="?", text_color="#555")
            self._logo_preview_img = None
        self._auto_save()

    def _on_ai_backend_change(self, value=None):
        """Показывает нужный фрейм настроек AI и скрывает остальные."""
        v = self._ai_backend_combo.get()
        self._ai_gemini_frame.grid_remove()
        self._ai_claude_frame.grid_remove()
        self._ai_chatgpt_frame.grid_remove()
        if v == "Gemini (Google)":
            self._ai_gemini_frame.grid()
        elif v == "Claude (Anthropic)":
            self._ai_claude_frame.grid()
        elif v == "ChatGPT (OpenAI)":
            self._ai_chatgpt_frame.grid()
        self._auto_save()

    def _on_logo_size_change(self, v):
        self._logo_size_lbl.configure(text=f"{int(v)}px")
        self._update_logo_preview()
        self._auto_save()

    def _update_logo_preview(self):
        """Перерисовывает круглый превью логотипа в UI."""
        path = self._logo_path_var.get()
        if not path or not os.path.isfile(path):
            self._logo_preview_lbl.configure(image=None, text="?", text_color="#555")
            self._logo_preview_img = None
            return
        try:
            from PIL import Image as _PILImage, ImageDraw as _PILDraw
            PREVIEW_SIZE = 60
            img = _PILImage.open(path).convert("RGBA")
            # Кроп до квадрата по центру
            ms = min(img.width, img.height)
            l = (img.width - ms) // 2
            t = (img.height - ms) // 2
            img = img.crop((l, t, l + ms, t + ms))
            img = img.resize((PREVIEW_SIZE, PREVIEW_SIZE), _PILImage.LANCZOS)
            # Круглая маска
            mask = _PILImage.new("L", (PREVIEW_SIZE, PREVIEW_SIZE), 0)
            _PILDraw.Draw(mask).ellipse((0, 0, PREVIEW_SIZE - 1, PREVIEW_SIZE - 1), fill=255)
            img.putalpha(mask)
            ctk_img = ctk.CTkImage(light_image=img, dark_image=img,
                                   size=(PREVIEW_SIZE, PREVIEW_SIZE))
            self._logo_preview_img = ctk_img  # protect from GC
            self._logo_preview_lbl.configure(image=ctk_img, text="")
        except Exception as exc:
            print(f"[app] Logo preview error: {exc}")
            self._logo_preview_lbl.configure(image=None, text="Err", text_color="#f55")

    def _browse_logo(self):
        path = filedialog.askopenfilename(
            title="Выберите логотип канала",
            filetypes=[("Изображения", "*.png *.jpg *.jpeg *.webp *.bmp"), ("Все файлы", "*.*")],
        )
        if path:
            self._logo_path_var.set(path)
            name = os.path.basename(path)
            self._logo_name_lbl.configure(text=name, text_color="#cccccc")
            self._update_logo_preview()
            self._auto_save()

    def _stop_run(self):
        self._running = False
        self._log("⏹ Остановка запрошена...")

    # ── Очистка кеша при старте ──────────────────────────────────────────────

    def _clear_cache_on_startup(self):
        """Удаляет содержимое cache/ и generated/ при каждом запуске программы."""
        import shutil
        dirs_to_clear = [
            config.IMAGE_CACHE_DIR,   # generated/
            config.CACHE_DIR,         # cache/ (транскрипции, storyboard и т.п.)
            config.PANELS_CACHE_DIR,  # cache/panels/
        ]
        total = 0
        for d in dirs_to_clear:
            p = Path(d)
            if not p.exists():
                continue
            for item in p.iterdir():
                try:
                    if item.is_file():
                        item.unlink()
                        total += 1
                    elif item.is_dir():
                        shutil.rmtree(item)
                        total += 1
                except Exception:
                    pass
        print(f"[startup] Кеш очищен: удалено {total} объектов")

    # ── Система обновлений ───────────────────────────────────────────────────

    def _check_updates_bg(self):
        """Запускает проверку обновлений в фоновом потоке."""
        def _worker():
            try:
                import updater as _upd
                from pathlib import Path as _Path
                root   = _Path(__file__).parent
                result = _upd.check_updates(root, local_version=APP_VERSION)
                if result.get("available"):
                    self.after(0, lambda: self._show_update_dialog(result))
            except Exception as exc:
                print(f"[updater] check failed: {exc}")

        t = threading.Thread(target=_worker, daemon=True)
        t.start()

    def _show_update_dialog(self, status: dict):
        """CTk-диалог с changelog и кнопками Установить / Пропустить."""
        dlg = ctk.CTkToplevel(self)
        dlg.title("Доступно обновление")
        dlg.resizable(False, False)
        dlg.transient(self)

        # Центрируем по главному окну
        DW, DH = 520, 420
        self.update_idletasks()
        rx = self.winfo_rootx() + (self.winfo_width()  - DW) // 2
        ry = self.winfo_rooty() + (self.winfo_height() - DH) // 2
        dlg.geometry(f"{DW}x{DH}+{rx}+{ry}")

        dlg.after(120, dlg.lift)
        dlg.after(200, dlg.focus_force)

        # Заголовок
        ctk.CTkLabel(
            dlg,
            text=f"🌱  Доступно обновление v{status['version']}",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color="#2ecc71",
        ).pack(padx=24, pady=(20, 4), anchor="w")

        ctk.CTkLabel(
            dlg,
            text=f"Ваша версия: v{APP_VERSION}  →  новая: v{status['version']}",
            font=ctk.CTkFont(size=11), text_color="#888",
        ).pack(padx=24, anchor="w")

        # Changelog
        ctk.CTkLabel(
            dlg, text="Что нового:",
            font=ctk.CTkFont(size=12, weight="bold"),
        ).pack(padx=24, pady=(14, 4), anchor="w")

        cl_box = ctk.CTkTextbox(dlg, height=140, font=ctk.CTkFont(family="Menlo", size=12))
        cl_box.pack(padx=24, fill="x")
        for line in status.get("changelog", []):
            cl_box.insert("end", f"  • {line}\n")
        cl_box.configure(state="disabled")

        # Число файлов
        n = len(status.get("changed_files", []))
        ctk.CTkLabel(
            dlg,
            text=f"Будет обновлено файлов: {n}",
            font=ctk.CTkFont(size=11), text_color="#888",
        ).pack(padx=24, pady=(10, 0), anchor="w")

        if status.get("requires_restart"):
            ctk.CTkLabel(
                dlg,
                text="⚠  После установки потребуется перезапуск",
                font=ctk.CTkFont(size=11), text_color="#e67e22",
            ).pack(padx=24, anchor="w")

        # Статус прогресса
        status_lbl = ctk.CTkLabel(
            dlg, text="", font=ctk.CTkFont(size=11), text_color="#aaa"
        )
        status_lbl.pack(padx=24, pady=(6, 0), anchor="w")

        # Кнопки
        btn_frame = ctk.CTkFrame(dlg, fg_color="transparent")
        btn_frame.pack(padx=24, pady=(12, 20), fill="x")

        install_btn = ctk.CTkButton(
            btn_frame,
            text="⬇  Установить обновление",
            height=40, font=ctk.CTkFont(size=13, weight="bold"),
            fg_color="#1a6b2a", hover_color="#145a22",
        )
        install_btn.pack(side="left", fill="x", expand=True, padx=(0, 8))

        skip_btn = ctk.CTkButton(
            btn_frame,
            text="Пропустить",
            height=40, font=ctk.CTkFont(size=12),
            fg_color="#333", hover_color="#444",
            command=dlg.destroy,
        )
        skip_btn.pack(side="left", width=110)

        def _do_install():
            print("[updater] Нажата кнопка установки")
            install_btn.configure(state="disabled")
            skip_btn.configure(state="disabled")
            status_lbl.configure(text="Подготовка…", text_color="#aaa")

            def _progress(msg: str):
                print(f"[updater] {msg}")
                self.after(0, lambda m=msg: status_lbl.configure(text=m))

            def _worker():
                try:
                    import updater as _upd
                    from pathlib import Path as _Path
                    result = _upd.install_update(_Path(__file__).parent,
                                                 progress_cb=_progress)
                    print(f"[updater] install result: {result}")
                except Exception as exc:
                    import traceback
                    traceback.print_exc()
                    result = {"ok": False, "installed": [],
                              "requires_restart": False, "error": str(exc)}
                self.after(0, lambda: _on_done(result))

            threading.Thread(target=_worker, daemon=True).start()

        def _on_done(result: dict):
            if result["ok"]:
                n_inst = len(result["installed"])
                if result.get("requires_restart"):
                    # Автоматический перезапуск через 3 секунды
                    for i in range(3, 0, -1):
                        dlg.after(
                            (3 - i) * 1000,
                            lambda sec=i: status_lbl.configure(
                                text=f"✅ Установлено {n_inst} файлов  •  перезапуск через {sec}…",
                                text_color="#2ecc71",
                            ),
                        )
                    dlg.after(3000, lambda: [dlg.destroy(), self._restart_app()])
                    install_btn.pack_forget()
                    skip_btn.configure(state="disabled")
                else:
                    status_lbl.configure(
                        text=f"✅ Установлено {n_inst} файлов",
                        text_color="#2ecc71")
                    install_btn.pack_forget()
                    skip_btn.configure(state="normal", text="Закрыть")
            else:
                status_lbl.configure(
                    text=f"❌ Ошибка: {result['error']}", text_color="#e74c3c")
                install_btn.configure(state="normal")
                skip_btn.configure(state="normal")

        install_btn.configure(command=_do_install)

    def _restart_app(self):
        """Убивает все дочерние процессы и перезапускает приложение."""
        self._running = False

        # 1. Убиваем активный FFmpeg-процесс (если есть)
        try:
            import compositor as _comp
            _comp.kill_active()
        except Exception:
            pass

        # 2. Убиваем все дочерние процессы через psutil (если доступен)
        try:
            import psutil
            parent = psutil.Process(os.getpid())
            for child in parent.children(recursive=True):
                try:
                    child.kill()
                except Exception:
                    pass
        except ImportError:
            # psutil не установлен — убиваем только ffmpeg по имени
            try:
                if sys.platform == "darwin" or sys.platform.startswith("linux"):
                    subprocess.run(["pkill", "-9", "-f", "ffmpeg"],
                                   capture_output=True)
                elif sys.platform == "win32":
                    subprocess.run(["taskkill", "/F", "/IM", "ffmpeg.exe"],
                                   capture_output=True)
            except Exception:
                pass
        except Exception:
            pass

        # 3. Перезапускаем текущий Python-процесс
        try:
            os.execv(sys.executable, [sys.executable] + sys.argv)
        except Exception:
            # Fallback: запускаем новый процесс и выходим
            subprocess.Popen([sys.executable] + sys.argv)
            sys.exit(0)

    def _run_pipeline(self, p: dict):
        """Пайплайн в фоновом потоке."""
        import datetime
        q = self._log_q
        log_lines: list[str] = []   # буфер для сохранения в файл

        def log(msg: str):
            log_lines.append(msg)
            q.put(msg)

        # Перехватываем print() через замену stdout
        class _LogRedirect:
            def write(self_, s):
                if s.strip():
                    log(s.rstrip())
            def flush(self_): pass

        old_stdout = sys.stdout
        old_stderr = sys.stderr
        sys.stdout = _LogRedirect()
        sys.stderr = _LogRedirect()

        def progress(pct: float):
            """Обновляет прогресс-бар (0.0 – 1.0) из фонового потока."""
            q.put(("PROGRESS", max(0.0, min(1.0, pct))))

        def _save_log(success: bool):
            """Сохраняет накопленный лог в logs/ с уникальным именем."""
            try:
                ensure_dirs(config.LOG_DIR)
                ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                base = sanitize_filename(
                    os.path.splitext(os.path.basename(p.get("video_path", "run")))[0]
                )
                status = "ok" if success else "fail"
                fname = f"{ts}_{base}_{status}.txt"
                fpath = os.path.join(config.LOG_DIR, fname)
                with open(fpath, "w", encoding="utf-8") as f:
                    f.write("\n".join(log_lines))
                q.put(f"📄 Лог сохранён: {fpath}")
            except Exception as exc:
                q.put(f"[!] Не удалось сохранить лог: {exc}")

        try:
            ensure_dirs(config.INPUT_DIR, config.OUTPUT_DIR,
                        config.CACHE_DIR, config.IMAGE_CACHE_DIR,
                        config.PANELS_CACHE_DIR, config.LOG_DIR)

            import random as _random
            import glob as _glob
            video_path  = p["video_path"]
            output_path = p["output_path"]
            max_n       = p["max_n"]
            quality     = p["quality"]
            display_sec_min = float(p.get("display_sec_min", 8.0))
            display_sec_max = float(p.get("display_sec_max", 16.0))
            engine      = p["engine"]
            ai_backend  = p["ai_backend"]
            manual_zones = p.get("manual_zones")

            # ── Очистка кеша сгенерированных изображений перед стартом ──────
            if not p.get("rerender_only"):
                gen_dir = config.IMAGE_CACHE_DIR
                removed = 0
                for ext in ("*.png", "*.jpg", "*.jpeg", "*.webp"):
                    for f in _glob.glob(os.path.join(gen_dir, ext)):
                        try:
                            os.remove(f)
                            removed += 1
                        except Exception:
                            pass
                if removed:
                    log(f"🗑 Кеш изображений очищен ({removed} файлов)")

            # ── 1. Транскрипция ──────────────────────────────────────────────
            if not self._running:
                return
            progress(0.05)
            log("\n[1/4] Транскрипция...")
            try:
                segments = transcribe(video_path, no_cache=False)
            except Exception as exc:
                log(f"⚠ Транскрипция не удалась: {exc}")
                log("  Продолжаем с пустым транскриптом.")
                segments = []

            if not segments:
                try:
                    import subprocess as _sp
                    r = _sp.run(["ffprobe", "-v", "quiet", "-print_format", "json",
                                 "-show_format", video_path],
                                capture_output=True, text=True, encoding="utf-8")
                    dur = float(json.loads(r.stdout)["format"]["duration"])
                except Exception:
                    dur = 600.0
                segments = [{"start": 0.0, "end": dur, "text": "", "language": "ru"}]

            progress(0.20)
            log(f"  Сегментов: {len(segments)}")

            # ── 2. Storyboard (AI) ───────────────────────────────────────────
            if not self._running:
                return
            if p["rerender_only"]:
                log("\n[2/4] Загружаем сохранённый storyboard...")
                saved = _load_storyboard(video_path)
                if saved:
                    sb_map = {s["index"]: s for s in saved}
                    for i, seg in enumerate(segments):
                        if i in sb_map:
                            seg["show_image"] = sb_map[i]["show_image"]
                            seg["prompt"]     = sb_map[i]["prompt"]
                            seg["image_path"] = sb_map[i].get("image_path")
                        else:
                            seg.setdefault("show_image", False)
                            seg.setdefault("prompt", "")
                            seg.setdefault("image_path", None)
                    log(f"  Загружено {len(saved)} записей.")
                else:
                    log("  Storyboard не найден — запускаем AI...")
                    p["rerender_only"] = False

            if not p["rerender_only"]:
                # Сбрасываем старые image_path — кеш уже очищен, не хотим пропустить генерацию
                for seg in segments:
                    seg["image_path"] = None
                detected_lang = "Russian"  # всегда Russian, без автодетекции
                progress(0.25)
                log(f"\n[2/4] Авто-промпты ({max_n} инфографик, язык={detected_lang})...")
                # Передаём настройки плакатов в config до вызова extract_keywords
                config.POSTER_MIX   = bool(p.get("poster_mix", False))
                config.POSTER_RATIO = float(p.get("poster_ratio", 0.35))
                if config.POSTER_MIX:
                    log(f"  🌿 Плакаты: {int(config.POSTER_RATIO*100)}% инфографик")
                try:
                    segments = extract_keywords(segments, n_infographics=max_n,
                                                language=detected_lang, ai_backend=ai_backend)
                except Exception as exc:
                    log(f"⚠ AI-режиссёр не ответил: {exc}")
                    for s in segments:
                        s.setdefault("show_image", False)
                        s.setdefault("prompt", "")
                progress(0.45)

            # ── Видеомикс: равномерное чередование инфографик / плакатов / клипов ──
            if p.get("video_mix_enabled") and p.get("video_mix_dir"):
                vmix_dir   = p["video_mix_dir"]
                vmix_ratio = float(p.get("video_mix_ratio", 0.25))
                _vid_exts = (".mp4", ".mov", ".avi", ".mkv", ".m4v", ".wmv")
                clip_files = [
                    os.path.join(vmix_dir, fn)
                    for fn in sorted(os.listdir(vmix_dir))
                    if os.path.splitext(fn.lower())[1] in _vid_exts
                       and os.path.isfile(os.path.join(vmix_dir, fn))
                ]
                if not clip_files:
                    log(f"  ⚠ В папке видеомикса нет видеофайлов: {vmix_dir}")
                else:
                    import subprocess as _sp2

                    # ── Шаг 1: все позиции с контентом (хронол. порядок) ────────
                    all_show_idx = [i for i, s in enumerate(segments) if s.get("show_image")]
                    N_show = len(all_show_idx)

                    n_poster_kw = sum(1 for i in all_show_idx if segments[i].get("_is_poster"))
                    n_clips     = min(max(1, round(N_show * vmix_ratio)), N_show - 1)
                    n_noninfog  = min(n_poster_kw + n_clips, N_show - 1)
                    n_clips     = max(0, n_noninfog - n_poster_kw)

                    # ── Шаг 2: единое zone-center для ВСЕХ не-инфографик ────────
                    # Размещаем все (плакаты + клипы) вместе, чтобы они равномерно
                    # чередовались с инфографиками. Никакого двойного прохода.
                    noninfog_pos: list[int] = []   # индексы в all_show_idx
                    for _zone in range(n_noninfog):
                        _c = int((_zone + 0.5) * N_show / n_noninfog)
                        _c = min(_c, N_show - 1)
                        if _c not in noninfog_pos:
                            noninfog_pos.append(_c)
                    # Добиваем до n_noninfog если из-за коллизий меньше позиций
                    _extra = [_p for _p in range(N_show) if _p not in noninfog_pos]
                    while len(noninfog_pos) < n_noninfog and _extra:
                        noninfog_pos.append(_extra.pop(0))

                    # ── Шаг 3: внутри не-инфографик: клипы тоже через zone-center
                    n_clips_actual = min(n_clips, len(noninfog_pos))
                    clip_in_pos: set[int] = set()  # позиции в all_show_idx
                    for _zone in range(n_clips_actual):
                        _c = int((_zone + 0.5) * len(noninfog_pos) / n_clips_actual)
                        _c = min(_c, len(noninfog_pos) - 1)
                        clip_in_pos.add(noninfog_pos[_c])

                    # ── Шаг 4: применяем назначения ─────────────────────────────
                    # Очищаем старые клип-флаги; _is_poster и prompt не трогаем.
                    for _si in all_show_idx:
                        segments[_si].pop("_is_video_clip", None)
                        segments[_si].pop("clip_path",      None)
                        segments[_si].pop("clip_start",     None)

                    noninfog_pos_set = set(noninfog_pos)
                    _random.shuffle(clip_files)
                    _clip_counter = 0
                    for _pos, _seg_i in enumerate(all_show_idx):
                        if _pos in clip_in_pos:
                            # Назначаем клип
                            _cp = clip_files[_clip_counter % len(clip_files)]
                            _clip_counter += 1
                            segments[_seg_i]["_is_video_clip"] = True
                            segments[_seg_i]["clip_path"]      = _cp
                            if segments[_seg_i].get("_is_poster"):
                                segments[_seg_i]["_is_poster"] = False
                            try:
                                _r = _sp2.run(
                                    ["ffprobe", "-v", "quiet", "-print_format", "json",
                                     "-show_format", _cp],
                                    capture_output=True, text=True, encoding="utf-8")
                                _cdur = float(json.loads(_r.stdout)["format"]["duration"])
                                _ms   = max(0.0, _cdur * 0.67 - 5.0)
                            except Exception:
                                _ms = 0.0
                            segments[_seg_i]["clip_start"] = _random.uniform(0.0, max(0.0, _ms))

                    # ── Лог: итоговое чередование ───────────────────────────────
                    def _stype(si):
                        s = segments[si]
                        if s.get("_is_video_clip"): return "C"
                        if s.get("_is_poster"):     return "P"
                        return "I"

                    final_seq  = "".join(_stype(all_show_idx[_p]) for _p in range(N_show))
                    n_clip_f   = final_seq.count("C")
                    n_poster_f = final_seq.count("P")
                    n_infog_f  = final_seq.count("I")
                    # Проверяем максимальную серию
                    _mrun = 1; _cr = 1
                    for _j in range(1, len(final_seq)):
                        _cr = (_cr + 1) if final_seq[_j] == final_seq[_j-1] else 1
                        _mrun = max(_mrun, _cr)
                    log(f"  🎬 Клипов: {n_clip_f}  📸 Плакатов: {n_poster_f}"
                        f"  🖼 Инфографик: {n_infog_f}  |  макс. серия: {_mrun}")
                    log(f"  Чередование: {final_seq}")
                    if _mrun > 2:
                        log(f"  ℹ️  Для идеального чередования увеличьте % плакатов + % клипов до ≥33%")

            # ── Проверка: есть ли инфографики для вставки ───────────────────────
            n_planned = sum(1 for s in segments if s.get("show_image"))
            if n_planned == 0:
                log("\n✗ AI не назначил ни одной инфографики.")
                log("  Возможные причины:")
                log("  • Неверный или пустой API-ключ AI-бэкенда")
                log("  • Видео без речи / транскрипт пустой")
                log("  • Ошибка парсинга ответа AI")
                log("  Рендер отменён.")
                _save_log(False)
                self._log_q.put(("DONE", False, ""))
                return
            log(f"  Запланировано инфографик: {n_planned}")

            # ── Конвертируем часть инфографик в Pexels-фото ─────────────────
            img_source = p.get("img_source", "FastGen")
            pexels_mix_enabled = p.get("pexels_mix_enabled", False)
            if config.PEXELS_API_KEY and (img_source == "Pexels" or pexels_mix_enabled):
                pexels_ratio  = float(p.get("pexels_mix_ratio", 0.3))
                n_pexels_want = max(1, round(n_planned * pexels_ratio)) if pexels_ratio > 0 else 0
                if n_pexels_want > 0:
                    # Индексы всех show_image слотов в хронологическом порядке
                    all_show_idx = [i for i, s in enumerate(segments) if s.get("show_image")]
                    # Выбираем равномерно распределённые позиции для Pexels
                    n_convert = min(n_pexels_want, len(all_show_idx) - 1)  # хотя бы 1 инфографика остаётся
                    step = len(all_show_idx) / n_convert
                    pexels_positions: list[int] = []
                    seen: set[int] = set()
                    for k in range(n_convert):
                        pos = min(int(k * step + step * 0.5), len(all_show_idx) - 1)
                        if pos not in seen:
                            seen.add(pos)
                            pexels_positions.append(pos)
                    # Конвертируем: меняем prompt на текст сегмента, ставим флаг
                    converted = 0
                    for pos in pexels_positions:
                        idx = all_show_idx[pos]
                        seg = segments[idx]
                        txt = seg.get("text", "").strip()
                        seg["_pexels_photo"] = True
                        seg["prompt"]        = txt or seg.get("prompt", "")
                        seg["queries"]       = [seg["prompt"]]
                        converted += 1
                    # Лог: I=инфографика P=Pexels-фото
                    seq_str = "".join(
                        "P" if segments[i].get("_pexels_photo") else "I"
                        for i in all_show_idx
                    )
                    n_infog_left = len(all_show_idx) - converted
                    log(f"  Разбивка: {n_infog_left} инфографик (FastGen) + {converted} фото (Pexels)")
                    log(f"  Чередование: {seq_str}")

            # ── 3. Изображения ───────────────────────────────────────────────
            if not self._running:
                return
            log(f"\n[3/4] Генерация изображений (engine={engine}, source={img_source})...")
            log(f"  Инфографики → FastGen:{engine} | Фото природы → {img_source}")
            try:
                segments = _fetch_all_images(
                    segments, "generate", engine, self._log_q,
                    progress_cb=progress, progress_start=0.45, progress_end=0.80,
                    pexels_mix_enabled=p.get("pexels_mix_enabled", False),
                    pexels_mix_ratio=float(p.get("pexels_mix_ratio", 0.0)),
                    img_source=img_source,
                )
            except Exception as exc:
                log(f"⚠ Ошибка генерации изображений: {exc}")
                for s in segments:
                    s.setdefault("image_path", None)

            _save_storyboard(segments, video_path)

            # Растягиваем показ каждой инфографики: рандомная длительность из диапазона
            for seg in segments:
                if seg.get("show_image"):
                    seg["end"] = seg["start"] + _random.uniform(display_sec_min, display_sec_max)

            # ── 4. Рендер ────────────────────────────────────────────────────
            if not self._running:
                return
            progress(0.82)
            log("\n[4/4] Рендеринг (FFmpeg)...")

            # Диагностика перед рендером
            _n_img_set = sum(1 for s in segments if s.get("show_image") and s.get("image_path"))
            _n_img_ok  = sum(1 for s in segments
                            if s.get("show_image") and s.get("image_path")
                            and os.path.isfile(str(s.get("image_path", ""))))
            log(f"  Инфографик к вставке: {_n_img_ok}/{_n_img_set} файлов найдено на диске")
            if _n_img_ok == 0 and _n_img_set > 0:
                log("  ⚠ Файлы сгенерированы но не найдены — проверь папку generated/")
            log(f"  Зоны: {manual_zones}")

            # Тайм-коды — где именно смотреть инфографики в готовом видео
            _ts_segs = [s for s in segments
                        if s.get("show_image") and s.get("image_path")
                        and os.path.isfile(str(s.get("image_path", "")))]
            if _ts_segs:
                def _fmt(sec: float) -> str:
                    m, s_ = divmod(int(sec), 60)
                    return f"{m:02d}:{s_:02d}"
                log("  Инфографики будут видны в:")
                for i, s in enumerate(_ts_segs, 1):
                    log(f"    #{i}  {_fmt(s['start'])} – {_fmt(s['end'])}")

            try:
                compose(video_path, segments, output_path, layout="side",
                        quality=quality, zones=manual_zones,
                        fade_sec=0.5 if p.get("animate", False) else 0.0,
                        logo_enabled=bool(p.get("logo_enabled", False)),
                        logo_path=str(p.get("logo_path", "") or ""),
                        logo_size=int(p.get("logo_size", 120)),
                        logo_padding=config.LOGO_PADDING)
            except Exception as exc:
                log(f"✗ Ошибка рендера: {exc}")
                self._log_q.put(("DONE", False, output_path))
                return
            progress(0.98)

            added = sum(1 for s in segments if s.get("show_image") and s.get("image_path")
                        and os.path.isfile(str(s.get("image_path", ""))))
            log(f"\n✓ Готово: {output_path}")
            log(f"  Инфографик вставлено: {added}")

            # ── Удаляем сгенерированные изображения после рендера ────────────
            try:
                import glob as _glob
                gen_dir = config.IMAGE_CACHE_DIR
                removed = 0
                for ext in ("*.png", "*.jpg", "*.jpeg", "*.webp"):
                    for f in _glob.glob(os.path.join(gen_dir, ext)):
                        try:
                            os.remove(f)
                            removed += 1
                        except Exception:
                            pass
                if removed:
                    log(f"🗑 Удалено {removed} временных изображений из generated/")
            except Exception as exc:
                log(f"[!] Очистка generated/ не удалась: {exc}")

            _save_log(True)
            self._log_q.put(("DONE", True, output_path))

        except Exception as exc:
            log(f"\n✗ Непредвиденная ошибка: {exc}")
            _save_log(False)
            self._log_q.put(("DONE", False, ""))
        finally:
            sys.stdout = old_stdout
            sys.stderr = old_stderr

    # ── Опрос очереди логов ──────────────────────────────────────────────────

    def _poll_log(self):
        try:
            while True:
                msg = self._log_q.get_nowait()
                try:
                    if isinstance(msg, tuple) and msg[0] == "DONE":
                        _, success, out_path = msg
                        self._on_run_done(success, out_path)
                    elif isinstance(msg, tuple) and msg[0] == "PROGRESS":
                        self._progress.set(msg[1])
                    else:
                        self._log(str(msg))
                except Exception as _dispatch_err:
                    print(f"[poll_log] dispatch error: {_dispatch_err}")
        except queue.Empty:
            pass
        except Exception as _poll_err:
            print(f"[poll_log] unexpected error: {_poll_err}")
        self.after(80, self._poll_log)

    def _log(self, msg: str):
        self._log_text.configure(state="normal")
        self._log_text.insert("end", msg + "\n")
        self._log_text.see("end")
        self._log_text.configure(state="disabled")

    def _on_run_done(self, success: bool, out_path: str):
        self._running = False
        elapsed = time.time() - getattr(self, "_run_start_time", time.time())
        self._progress.set(1.0 if success else 0.0)
        self._set_controls_locked(False)
        self._start_btn.configure(
            text="▶  СТАРТ",
            fg_color="#2d6a2d", hover_color="#1e4d1e",
            command=self._start_run,
        )
        if success:
            self._output_path = out_path
            self._log(f"\n🎉 Обработка завершена!\n   Файл: {out_path}")
        else:
            self._log("\n⚠ Произошла ошибка. Проверьте LOG выше.")
        # Звук + всплывающее окно с результатом
        self._play_sound(success)
        self.after(200, lambda: self._show_done_popup(success, out_path, elapsed))

    def _play_sound(self, success: bool):
        """Воспроизводит системный звук по завершении."""
        try:
            if sys.platform == "darwin":
                sound = "Glass" if success else "Funk"
                subprocess.Popen(
                    ["afplay", f"/System/Library/Sounds/{sound}.aiff"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            elif sys.platform == "win32":
                import winsound as _ws
                _ws.MessageBeep(_ws.MB_ICONASTERISK if success else _ws.MB_ICONHAND)
            else:
                # Linux: пробуем paplay, потом aplay
                sounds = (
                    ["/usr/share/sounds/freedesktop/stereo/complete.oga"]
                    if success else
                    ["/usr/share/sounds/freedesktop/stereo/dialog-error.oga"]
                )
                for s in sounds:
                    if os.path.isfile(s):
                        subprocess.Popen(["paplay", s],
                                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                        break
        except Exception:
            pass

    def _show_done_popup(self, success: bool, out_path: str, elapsed_sec: float):
        """Всплывающее окно с результатом, временем и кнопками."""
        mins = int(elapsed_sec) // 60
        secs = int(elapsed_sec) % 60
        time_str = f"{mins} мин {secs} сек" if mins else f"{secs} сек"

        popup = ctk.CTkToplevel(self)
        popup.title("Результат обработки")
        popup.geometry("420x230")
        popup.resizable(False, False)
        popup.grab_set()        # модальное — блокирует главное окно
        popup.lift()
        popup.attributes("-topmost", True)
        popup.focus_force()

        # Центрируем по главному окну
        self.update_idletasks()
        px = self.winfo_x() + (self.winfo_width()  - 420) // 2
        py = self.winfo_y() + (self.winfo_height() - 230) // 2
        popup.geometry(f"420x230+{px}+{py}")

        if success:
            icon, title_text, title_color = "🎉", "Обработка завершена!", "#2ecc71"
        else:
            icon, title_text, title_color = "⚠️", "Обработка прервана", "#e74c3c"

        ctk.CTkLabel(
            popup, text=f"{icon}  {title_text}",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=title_color,
        ).pack(pady=(28, 6))

        ctk.CTkLabel(
            popup, text=f"⏱  Время: {time_str}",
            font=ctk.CTkFont(size=13), text_color="#aaa",
        ).pack(pady=(0, 4))

        if success and out_path:
            ctk.CTkLabel(
                popup, text=os.path.basename(out_path),
                font=ctk.CTkFont(size=11), text_color="#666",
            ).pack(pady=(0, 18))
        else:
            ctk.CTkLabel(
                popup, text="Подробности в логе",
                font=ctk.CTkFont(size=11), text_color="#666",
            ).pack(pady=(0, 18))

        btn_frame = ctk.CTkFrame(popup, fg_color="transparent")
        btn_frame.pack()

        ctk.CTkButton(
            btn_frame, text="Закрыть", width=130, height=40,
            fg_color="#2a2a2a", hover_color="#3a3a3a",
            command=popup.destroy,
        ).pack(side="left", padx=(0, 12))

        if success and out_path:
            ctk.CTkButton(
                btn_frame, text="✅ Открыть результат", width=170, height=40,
                fg_color="#1a4a1a", hover_color="#256325",
                command=lambda: (popup.destroy(), self._open_output()),
            ).pack(side="left")


# ─────────────────────────────────────────────────────────────────────────────
# Точка входа
# ─────────────────────────────────────────────────────────────────────────────

def main():
    app = GardenApp()
    app.mainloop()


if __name__ == "__main__":
    main()
