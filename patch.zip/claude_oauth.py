"""
claude_oauth.py — PKCE OAuth для Claude (Anthropic).

Использует официальный OAuth-эндпоинт claude.ai — тот же механизм
что применяется в MCP-интеграциях Claude Desktop.

Поток:
  1. Генерируем code_verifier + code_challenge (SHA-256 base64url)
  2. Открываем браузер на claude.ai/oauth/authorize
  3. Слушаем localhost:1456/auth/callback
  4. Меняем code на access_token + refresh_token
  5. Возвращаем токены вызывающему коду
"""

import base64
import hashlib
import secrets
import threading
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Callable

# ── Константы Claude OAuth ───────────────────────────────────────────────────
CLIENT_ID    = "9d1c250a-e61b-44d9-88ed-5944d1962f5e"   # Claude Code CLI client
REDIRECT_URI = "http://localhost:1456/callback"
SCOPES       = "org:create_api_key user:profile user:inference user:sessions:claude_code"
AUTH_URL     = "https://platform.claude.com/oauth/authorize"
TOKEN_URL    = "https://console.anthropic.com/v1/oauth/token"   # fallback list ниже
PORT         = 1456


# ── PKCE-утилиты ─────────────────────────────────────────────────────────────

def _gen_verifier() -> str:
    return secrets.token_urlsafe(96)


def _challenge(verifier: str) -> str:
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")


def build_auth_url(verifier: str, state: str) -> str:
    params = {
        "response_type":         "code",
        "client_id":             CLIENT_ID,
        "redirect_uri":          REDIRECT_URI,
        "code_challenge":        _challenge(verifier),
        "code_challenge_method": "S256",
        "state":                 state,
    }
    # scope добавляем только если задан
    if SCOPES:
        params["scope"] = SCOPES
    return AUTH_URL + "?" + urllib.parse.urlencode(params)


# ── Локальный callback-сервер ─────────────────────────────────────────────────

class _CallbackHandler(BaseHTTPRequestHandler):
    on_success: Callable | None = None
    on_error:   Callable | None = None

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path != "/callback":
            self._html(404, "Not found"); return

        qs    = urllib.parse.parse_qs(parsed.query)
        code  = (qs.get("code")  or [""])[0]
        state = (qs.get("state") or [""])[0]
        error = (qs.get("error") or [""])[0]

        if error:
            self._html(400, f"Ошибка: {error}")
            if self.on_error: self.on_error(error)
        elif code:
            self._html(200, "✓ Авторизация успешна! Можно закрыть это окно.")
            if self.on_success: self.on_success(code, state)
        else:
            self._html(400, "Нет кода авторизации.")
            if self.on_error: self.on_error("no_code")

    def _html(self, status: int, body: str):
        ok  = status == 200
        clr = "#2ecc71" if ok else "#e74c3c"
        page = (f'<!DOCTYPE html><html><head><meta charset="utf-8">'
                f'<style>body{{font-family:sans-serif;display:flex;align-items:center;'
                f'justify-content:center;height:100vh;background:#0a0a0a;color:#eee;margin:0}}'
                f'h2{{color:{clr};font-size:1.5rem}}'
                f'.logo{{font-size:3rem;margin-bottom:1rem}}</style></head>'
                f'<body><div style="text-align:center">'
                f'<div class="logo">🤖</div><h2>{body}</h2>'
                f'</div></body></html>').encode()
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(page)))
        self.end_headers()
        self.wfile.write(page)

    def log_message(self, *_): pass


# ── Обмен code → tokens ──────────────────────────────────────────────────────

def exchange_code(code: str, verifier: str, state: str = "") -> dict:
    """
    Обменивает authorization code на токены.
    Правильный формат: JSON body + state параметр.
    Endpoint: api.anthropic.com/v1/oauth/token
    """
    import requests as _req

    payload = {
        "grant_type":    "authorization_code",
        "client_id":     CLIENT_ID,
        "code":          code,
        "redirect_uri":  REDIRECT_URI,
        "code_verifier": verifier,
        "state":         state,
    }
    candidates = [
        "https://api.anthropic.com/v1/oauth/token",
        "https://console.anthropic.com/v1/oauth/token",
    ]
    last_err = "no candidates"
    for url in candidates:
        try:
            r = _req.post(
                url,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=15,
            )
            print(f"[oauth] token endpoint {url} → {r.status_code}: {r.text[:120]}")
            if r.status_code == 200:
                return r.json()
            last_err = f"{url} {r.status_code}: {r.text[:200]}"
        except Exception as e:
            last_err = str(e)

    raise RuntimeError(f"Token exchange failed: {last_err}")


def refresh_access_token(refresh_token: str) -> dict:
    import requests as _req
    payload = {
        "grant_type":    "refresh_token",
        "client_id":     CLIENT_ID,
        "refresh_token": refresh_token,
    }
    for url in ["https://api.anthropic.com/v1/oauth/token",
                "https://console.anthropic.com/v1/oauth/token"]:
        r = _req.post(url, json=payload,
                      headers={"Content-Type": "application/json"}, timeout=15)
        if r.status_code == 200:
            return r.json()
    raise RuntimeError("Token refresh failed")


def get_user_info(access_token: str) -> dict:
    """Получает профиль (email, name) через Anthropic API. Никогда не бросает исключений."""
    import requests as _req
    for url in [
        "https://claude.ai/api/auth/session",
        "https://api.anthropic.com/v1/oauth/userinfo",
    ]:
        try:
            r = _req.get(url,
                         headers={"Authorization": f"Bearer {access_token}"},
                         timeout=6)
            if r.status_code == 200:
                try:
                    d = r.json()
                    return {
                        "name":  d.get("name") or d.get("display_name") or "",
                        "email": d.get("email") or "",
                    }
                except Exception:
                    pass
        except Exception:
            continue
    return {}


# ── Главная функция ──────────────────────────────────────────────────────────

def start_oauth(
    on_tokens: Callable[[dict], None],
    on_error:  Callable[[str], None],
):
    """
    PKCE-поток для Claude. Открывает браузер, ждёт callback на порту 1456,
    обменивает code на токены и вызывает on_tokens(token_dict).
    """
    verifier = _gen_verifier()
    state    = secrets.token_urlsafe(32)
    url      = build_auth_url(verifier, state)
    done     = threading.Event()

    class _H(_CallbackHandler): pass

    def _ok(code: str, ret_state: str):
        if ret_state != state:
            on_error("state_mismatch"); done.set(); return
        try:
            tokens = exchange_code(code, verifier, ret_state)
            on_tokens(tokens)
        except Exception as exc:
            on_error(str(exc))
        finally:
            done.set()

    def _err(msg: str):
        on_error(msg); done.set()

    _H.on_success = staticmethod(_ok)
    _H.on_error   = staticmethod(_err)

    def _serve():
        try:
            srv = HTTPServer(("127.0.0.1", PORT), _H)
            srv.timeout = 1.0
            for _ in range(180):          # ждём 3 минуты
                if done.is_set(): break
                srv.handle_request()
            srv.server_close()
        except OSError as exc:
            on_error(f"Порт {PORT} занят: {exc}")

    threading.Thread(target=_serve, daemon=True).start()
    webbrowser.open(url)
