"""
compositor.py — рендеринг видео через FFmpeg subprocess.

Динамический side-layout:
  • Нет инфографики → оригинальное видео на весь экран.
  • Есть инфографика → видео в левых 60%, правые 40% — инфографика + blur-фон.
  • Zone overlay → видео полный экран, инфографика в указанной зоне.

Профили качества:
  720fast — scale 720p, ultrafast, CRF 26
  1080    — оригинал, fast,      CRF 23
"""

import json
import os
import subprocess
from typing import Any

from PIL import Image, ImageDraw, ImageFilter

# ── Глобальный трекер FFmpeg-процесса (для принудительной остановки) ──────────
_active_process: subprocess.Popen | None = None


def kill_active():
    """Убивает текущий FFmpeg-процесс, если он запущен."""
    global _active_process
    p = _active_process
    if p is not None:
        try:
            p.kill()
        except Exception:
            pass
        _active_process = None

from config import (
    AUDIO_CODEC,
    OVERLAY_PADDING,
    PANELS_CACHE_DIR,
    QUALITY_PROFILES,
    SIDE_VIDEO_RATIO,
    VIDEO_CODEC,
)
from utils import ensure_dirs, sanitize_filename, setup_logger

logger = setup_logger(__name__)


# ---------------------------------------------------------------------------
# Утилиты
# ---------------------------------------------------------------------------

def _probe_video(video_path: str) -> dict[str, Any]:
    cmd = [
        "ffprobe", "-v", "quiet",
        "-print_format", "json",
        "-show_streams", "-show_format",
        video_path,
    ]
    result = subprocess.run(cmd, capture_output=True, text=True,
                            encoding="utf-8", errors="replace")
    stdout = result.stdout or ""
    if not stdout.strip():
        raise RuntimeError(
            f"ffprobe returned no output for {video_path!r}. "
            f"stderr: {(result.stderr or '')[:200]}")
    data = json.loads(stdout)
    vs = next(s for s in data["streams"] if s["codec_type"] == "video")
    w = int(vs["width"])
    h = int(vs["height"])
    duration = float(data["format"]["duration"])
    num, den = vs.get("r_frame_rate", "25/1").split("/")
    fps = float(num) / float(den)
    # Битрейт видеодорожки (бит/с)
    vbitrate = int(vs.get("bit_rate") or data["format"].get("bit_rate") or 0)
    return {"w": w, "h": h, "duration": duration, "fps": fps, "vbitrate": vbitrate}


def _is_valid_image(path: str) -> bool:
    """Проверяет что файл существует и декодируется PIL.
    Используем load() вместо verify() — verify() слишком строгая
    и отклоняет валидные PNG/JPEG из FastGen (например без IEND-чанка)."""
    if not os.path.isfile(path):
        return False
    if os.path.getsize(path) < 64:
        return False
    try:
        with Image.open(path) as img:
            img.load()          # реально декодирует пиксели — не строже чем нужно
        return True
    except Exception as exc:
        print(f"[compositor] _is_valid_image failed for {os.path.basename(path)}: {exc}")
        return False


def _build_zone_panel(image_path: str, zone_w: int, zone_h: int) -> str | None:
    """
    Масштабирует инфографику под размер зоны методом scale-to-fit (вписать без обрезки).
    Изображение полностью помещается в зону, прозрачные поля заполняют остаток.
    Кэширует в PANELS_CACHE_DIR.
    """
    if not _is_valid_image(image_path):
        print(f"[compositor] Не удалось прочитать: {os.path.basename(image_path)} — пропускаем")
        return None
    ensure_dirs(PANELS_CACHE_DIR)
    key      = sanitize_filename(os.path.basename(image_path))
    out_path = os.path.join(PANELS_CACHE_DIR, f"zone_{key}_{zone_w}x{zone_h}_fit.png")
    if os.path.isfile(out_path) and os.path.getsize(out_path) > 100:
        return out_path
    try:
        src = Image.open(image_path).convert("RGBA")
        img_ratio  = src.width  / src.height
        zone_ratio = zone_w / zone_h

        # Scale-to-fit: вписываем целиком без обрезки
        if img_ratio > zone_ratio:
            # Картинка шире зоны — масштабируем по ширине
            new_w = zone_w
            new_h = int(src.height * zone_w / src.width)
        else:
            # Картинка уже зоны — масштабируем по высоте
            new_h = zone_h
            new_w = int(src.width * zone_h / src.height)

        src = src.resize((new_w, new_h), Image.LANCZOS)

        # Прозрачный фон зоны, картинка по центру
        out = Image.new("RGBA", (zone_w, zone_h), (0, 0, 0, 0))
        x = (zone_w - new_w) // 2
        y = (zone_h - new_h) // 2
        out.paste(src, (x, y))

        out.save(out_path, "PNG")
        print(f"[compositor] Zone panel (fit): {new_w}x{new_h} → {zone_w}x{zone_h} @ ({x},{y})")
        return out_path
    except Exception as exc:
        print(f"[compositor] Zone panel build error: {exc}")
        return None


def _build_right_panel(image_path: str, panel_w: int, panel_h: int) -> str | None:
    """
    Создаёт PNG правой панели: размытый фон + инфографика по центру.
    Кэширует в PANELS_CACHE_DIR. Возвращает None если изображение не читается PIL.
    """
    if not _is_valid_image(image_path):
        print(f"[compositor] Не удалось прочитать: {os.path.basename(image_path)} — пропускаем")
        return None

    ensure_dirs(PANELS_CACHE_DIR)
    key = sanitize_filename(os.path.basename(image_path))
    out_path = os.path.join(PANELS_CACHE_DIR, f"{key}_{panel_w}x{panel_h}.png")
    if os.path.isfile(out_path) and os.path.getsize(out_path) > 100:
        return out_path
    try:
        src = Image.open(image_path).convert("RGB")
        bg = src.resize((panel_w, panel_h), Image.LANCZOS)
        bg = bg.filter(ImageFilter.GaussianBlur(radius=25))
        pad = OVERLAY_PADDING
        fg = src.copy()
        fg.thumbnail((panel_w - pad * 2, panel_h - pad * 2), Image.LANCZOS)
        canvas = bg.copy()
        canvas.paste(fg, ((panel_w - fg.width) // 2, (panel_h - fg.height) // 2))
        canvas.save(out_path, "PNG")
        return out_path
    except Exception as exc:
        print(f"[compositor] Panel build error: {exc}")
        return None


def _prepare_logo(path: str, size: int) -> str | None:
    """
    Открывает логотип канала, кропает до квадрата, применяет круглую маску
    и сохраняет RGBA PNG в кэш. Возвращает путь к кэш-файлу или None при ошибке.
    """
    if not os.path.isfile(path):
        print(f"[compositor] Logo file not found: {path}")
        return None
    try:
        ensure_dirs(PANELS_CACHE_DIR)
        key      = sanitize_filename(os.path.basename(path))
        out_path = os.path.join(PANELS_CACHE_DIR, f"logo_{key}_{size}x{size}.png")

        img = Image.open(path).convert("RGBA")

        # Кроп до квадрата (по центру)
        min_side = min(img.width, img.height)
        left = (img.width  - min_side) // 2
        top  = (img.height - min_side) // 2
        img  = img.crop((left, top, left + min_side, top + min_side))

        # Масштаб до нужного размера
        img = img.resize((size, size), Image.LANCZOS)

        # Круглая маска
        mask = Image.new("L", (size, size), 0)
        draw = ImageDraw.Draw(mask)
        draw.ellipse((0, 0, size - 1, size - 1), fill=255)
        img.putalpha(mask)

        img.save(out_path, "PNG")
        print(f"[compositor] Logo prepared: {size}×{size} → {os.path.basename(out_path)}")
        return out_path
    except Exception as exc:
        print(f"[compositor] Logo prepare error: {exc}")
        return None


def _encode_flags(crf: str, preset: str, audio_copy: bool = False,
                  fps: float = 0.0, src_bitrate: int = 0) -> list[str]:
    audio = ["-c:a", "copy"] if audio_copy else ["-c:a", AUDIO_CODEC]
    flags = [
        "-c:v", VIDEO_CODEC, "-crf", crf, "-preset", preset,
        "-tune", "film",
        "-threads", "0",
        *audio, "-pix_fmt", "yuv420p",
        "-movflags", "+faststart",
    ]
    # Явно фиксируем FPS источника чтобы не было его изменения
    if fps > 0:
        flags += ["-r", f"{fps:.6f}"]
    # Ограничиваем максимальный битрейт: не больше удвоенного источника
    # чтобы избежать раздувания файла, но и не меньше оригинала
    if src_bitrate > 0:
        maxrate = src_bitrate  # не превышаем оригинал
        bufsize = src_bitrate * 2
        flags += ["-maxrate", str(maxrate), "-bufsize", str(bufsize)]
    return flags


# ---------------------------------------------------------------------------
# FFmpeg команды
# ---------------------------------------------------------------------------

def _build_ffmpeg_cmd(
    video_path: str,
    segments: list[dict[str, Any]],
    output_path: str,
    info: dict[str, Any],
    quality: str = "720fast",
    fade_sec: float = 0.0,
    logo_png: str | None = None,
    logo_padding: int = 20,
) -> list[str]:
    """Side-panel layout: видео слева 60%, инфографика справа 40%."""
    profile     = QUALITY_PROFILES.get(quality, QUALITY_PROFILES["720fast"])
    crf         = profile["crf"]
    preset      = profile["preset"]
    scale       = profile.get("scale")
    audio_copy  = profile.get("audio_copy", False)
    duration    = info["duration"]

    if scale:
        out_w, out_h = map(int, scale.split(":"))
    else:
        out_w, out_h = info["w"], info["h"]

    left_w  = int(out_w * SIDE_VIDEO_RATIO)
    right_w = out_w - left_w

    enc = _encode_flags(crf, preset, audio_copy,
                        fps=info.get("fps", 0.0),
                        src_bitrate=info.get("vbitrate", 0))

    # Validate and build panels
    active: list[dict[str, Any]] = []
    for s in segments:
        if not s.get("show_image"):
            continue
        ip = s.get("image_path", "")
        if not ip:
            continue
        panel = _build_right_panel(str(ip), right_w, out_h)
        if panel:
            s["_panel"] = panel
            active.append(s)

    if not active and not logo_png:
        if not scale:
            # Нет оверлеев и нет масштабирования — копируем без перекодирования
            return ["ffmpeg", "-y", "-i", video_path,
                    "-c:v", "copy", "-c:a", "copy",
                    "-t", f"{duration:.3f}", output_path]
        return ["ffmpeg", "-y", "-i", video_path,
                "-vf", f"scale={out_w}:{out_h}:flags=lanczos,format=yuv420p"
                ] + enc + ["-t", f"{duration:.3f}", output_path]

    # Build inputs: use -itsoffset + -t per image so only active images are decoded
    inputs: list[str] = ["-i", video_path]
    for seg in active:
        s = max(0.0, seg["start"])
        d = max(0.1, min(duration, seg["end"]) - s)
        inputs += ["-itsoffset", f"{s:.3f}", "-loop", "1", "-t", f"{d:.3f}", "-i", seg["_panel"]]

    filters: list[str] = []
    if scale:
        filters.append(f"[0:v]scale={out_w}:{out_h}:flags=lanczos[base]")
        current = "base"
    else:
        current = "0:v"

    for idx, seg in enumerate(active):
        s = max(0.0, seg["start"])
        e = min(duration, seg["end"])
        img_i = idx + 1
        # Panel fade: используем абсолютный PTS для st= (FFmpeg fade использует
        # глобальный PTS потока; с -itsoffset поток стартует с PTS=s, а не с 0)
        if fade_sec > 0:
            display_dur = max(0.1, e - s)
            fade_out_st = s + max(0.05, display_dur - fade_sec)
            filters.append(
                f"[{img_i}:v]format=rgba,"
                f"fade=in:st={s:.3f}:d={fade_sec:.2f}:alpha=1,"
                f"fade=out:st={fade_out_st:.3f}:d={fade_sec:.2f}:alpha=1,"
                f"format=yuva420p[rp{idx}]"
            )
        else:
            filters.append(f"[{img_i}:v]format=yuv420p[rp{idx}]")
        out_lbl = f"vout{idx}"
        filters.append(
            f"[{current}][rp{idx}]"
            f"overlay=x={left_w}:y=0:"
            f"enable='between(t,{s:.3f},{e:.3f})'"
            f"[{out_lbl}]"
        )
        current = out_lbl

    # Логотип канала — поверх всего, весь ролик
    if logo_png:
        logo_i = len(active) + 1
        inputs += ["-loop", "1", "-t", f"{duration:.3f}", "-i", logo_png]
        logo_lbl = "logo_final"
        filters.append(
            f"[{current}][{logo_i}:v]"
            f"overlay=x=W-w-{logo_padding}:y=H-h-{logo_padding}:format=auto"
            f"[{logo_lbl}]"
        )
        current = logo_lbl

    if not filters:
        if not scale:
            return ["ffmpeg", "-y", "-i", video_path,
                    "-c:v", "copy", "-c:a", "copy",
                    "-t", f"{duration:.3f}", output_path]
        return ["ffmpeg", "-y", "-i", video_path,
                "-vf", f"scale={out_w}:{out_h}:flags=lanczos,format=yuv420p"
                ] + enc + ["-t", f"{duration:.3f}", output_path]

    return (
        ["ffmpeg", "-y"]
        + inputs
        + ["-filter_complex", ";".join(filters)]
        + ["-map", f"[{current}]", "-map", "0:a"]
        + ["-t", f"{duration:.3f}"]
        + enc
        + [output_path]
    )


def _build_zone_overlay_cmd(
    video_path: str,
    segments: list[dict[str, Any]],
    output_path: str,
    info: dict[str, Any],
    quality: str,
    zones: list[list[float]],
    fade_sec: float = 0.0,
    logo_png: str | None = None,
    logo_padding: int = 20,
) -> list[str]:
    """Zone overlay: видео полный экран, инфографика в указанной зоне."""
    profile     = QUALITY_PROFILES.get(quality, QUALITY_PROFILES["720fast"])
    crf         = profile["crf"]
    preset      = profile["preset"]
    scale       = profile.get("scale")
    audio_copy  = profile.get("audio_copy", False)
    duration    = info["duration"]

    if scale:
        out_w, out_h = map(int, scale.split(":"))
    else:
        out_w, out_h = info["w"], info["h"]

    enc = _encode_flags(crf, preset, audio_copy,
                        fps=info.get("fps", 0.0),
                        src_bitrate=info.get("vbitrate", 0))

    # Assign zones round-robin + pre-build PIL panels at exact pixel size
    n_zones = len(zones)
    active: list[dict[str, Any]] = []
    for i, seg in enumerate(segments):
        if not seg.get("show_image"):
            continue

        clip_path = seg.get("clip_path", "") or ""
        ip        = seg.get("image_path", "") or ""

        if clip_path and os.path.isfile(clip_path):
            # Видеоклип — полноэкранный оверлей
            seg["_is_clip"]   = True
            seg["_clip_path"] = clip_path
            seg["_clip_start"] = float(seg.get("clip_start", 0.0))
            active.append(seg)
        elif ip:
            # Инфографика / плакат — вписываем в зону
            zone = zones[i % n_zones]
            zx = int(zone[0] * out_w)
            zy = int(zone[1] * out_h)
            zw = max(4, int(zone[2] * out_w))
            zh = max(4, int(zone[3] * out_h))
            zw = zw - (zw % 2)
            zh = zh - (zh % 2)
            panel = _build_zone_panel(str(ip), zw, zh)
            if panel is None:
                continue
            seg["_is_clip"]    = False
            seg["_zone_panel"] = panel
            seg["_zx"]         = zx
            seg["_zy"]         = zy
            active.append(seg)

    if not active and not logo_png:
        if not scale:
            return ["ffmpeg", "-y", "-i", video_path,
                    "-c:v", "copy", "-c:a", "copy",
                    "-t", f"{duration:.3f}", output_path]
        return ["ffmpeg", "-y", "-i", video_path,
                "-vf", f"scale={out_w}:{out_h}:flags=lanczos,format=yuv420p"
                ] + enc + ["-t", f"{duration:.3f}", output_path]

    # Build inputs
    inputs: list[str] = ["-i", video_path]
    for seg in active:
        s = max(0.0, seg["start"])
        d = max(0.1, min(duration, seg["end"]) - s)
        if seg["_is_clip"]:
            # Видеоклип: -ss задаёт смещение внутри клипа, -stream_loop зацикливает
            # если клип короче нужного окна
            inputs += [
                "-ss", f"{seg['_clip_start']:.3f}",
                "-stream_loop", "-1",
                "-t", f"{d:.3f}",
                "-itsoffset", f"{s:.3f}",
                "-i", seg["_clip_path"],
            ]
        else:
            inputs += ["-itsoffset", f"{s:.3f}", "-loop", "1", "-t", f"{d:.3f}",
                       "-i", seg["_zone_panel"]]

    filters: list[str] = []
    if scale:
        filters.append(f"[0:v]scale={out_w}:{out_h}:flags=lanczos[base]")
        current = "base"
    else:
        current = "0:v"

    for idx, seg in enumerate(active):
        s     = max(0.0, seg["start"])
        e     = min(duration, seg["end"])
        inp_i = idx + 1
        lbl   = f"zo{idx}"
        out_lbl = f"vout{idx}"

        if seg["_is_clip"]:
            # Масштабируем клип под полный выходной размер
            filters.append(
                f"[{inp_i}:v]scale={out_w}:{out_h}:flags=lanczos,"
                f"format=yuv420p[{lbl}]"
            )
            filters.append(
                f"[{current}][{lbl}]"
                f"overlay=x=0:y=0:enable='between(t,{s:.3f},{e:.3f})'"
                f"[{out_lbl}]"
            )
        else:
            # Инфографика / плакат с опциональным fade
            if fade_sec > 0:
                display_dur = max(0.1, e - s)
                fade_out_st = s + max(0.05, display_dur - fade_sec)
                filters.append(
                    f"[{inp_i}:v]format=rgba,"
                    f"fade=in:st={s:.3f}:d={fade_sec:.2f}:alpha=1,"
                    f"fade=out:st={fade_out_st:.3f}:d={fade_sec:.2f}:alpha=1,"
                    f"format=yuva420p[{lbl}]"
                )
            else:
                filters.append(f"[{inp_i}:v]format=yuv420p[{lbl}]")
            filters.append(
                f"[{current}][{lbl}]"
                f"overlay=x={seg['_zx']}:y={seg['_zy']}:"
                f"enable='between(t,{s:.3f},{e:.3f})'"
                f"[{out_lbl}]"
            )
        current = out_lbl

    # Логотип канала — поверх всего, весь ролик
    if logo_png:
        logo_i = len(active) + 1
        inputs += ["-loop", "1", "-t", f"{duration:.3f}", "-i", logo_png]
        logo_lbl = "logo_final"
        filters.append(
            f"[{current}][{logo_i}:v]"
            f"overlay=x=W-w-{logo_padding}:y=H-h-{logo_padding}:format=auto"
            f"[{logo_lbl}]"
        )
        current = logo_lbl

    if not filters:
        if not scale:
            return ["ffmpeg", "-y", "-i", video_path,
                    "-c:v", "copy", "-c:a", "copy",
                    "-t", f"{duration:.3f}", output_path]
        return ["ffmpeg", "-y", "-i", video_path,
                "-vf", f"scale={out_w}:{out_h}:flags=lanczos,format=yuv420p"
                ] + enc + ["-t", f"{duration:.3f}", output_path]

    return (
        ["ffmpeg", "-y"]
        + inputs
        + ["-filter_complex", ";".join(filters)]
        + ["-map", f"[{current}]", "-map", "0:a"]
        + ["-t", f"{duration:.3f}"]
        + enc
        + [output_path]
    )


# ---------------------------------------------------------------------------
# Публичный API
# ---------------------------------------------------------------------------

def compose(
    video_path: str,
    segments_with_images: list[dict[str, Any]],
    output_path: str,
    layout: str = "side",
    quality: str = "720fast",
    zones: list | None = None,
    fade_sec: float = 0.0,
    logo_path: str = "",
    logo_size: int = 120,
    logo_padding: int = 20,
    logo_enabled: bool = False,
) -> str:
    if not os.path.isfile(video_path):
        raise FileNotFoundError(f"Видеофайл не найден: {video_path}")

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    profile = QUALITY_PROFILES.get(quality, QUALITY_PROFILES["720fast"])
    print(f"[compositor] Профиль: {profile['label']}")

    info = _probe_video(video_path)
    src_mbps = info["vbitrate"] / 1_000_000 if info["vbitrate"] else 0
    print(f"[compositor] Источник: {info['w']}x{info['h']}, {info['duration']:.0f}с, {info['fps']:.2f}fps"
          + (f", {src_mbps:.1f} Мбит/с" if src_mbps else ""))

    total_show   = sum(1 for s in segments_with_images if s.get("show_image"))
    total_path   = sum(1 for s in segments_with_images if s.get("show_image") and s.get("image_path"))
    total_clips  = sum(1 for s in segments_with_images if s.get("show_image") and s.get("clip_path"))
    active_segs  = [
        s for s in segments_with_images
        if s.get("show_image") and (
            (s.get("image_path") and os.path.isfile(str(s.get("image_path", "")))) or
            (s.get("clip_path")  and os.path.isfile(str(s.get("clip_path",  ""))))
        )
    ]
    active_count = len(active_segs)
    print(f"[compositor] show_image={total_show}  image_path_set={total_path}  clips={total_clips}  ready={active_count}")
    if active_count == 0 and total_show > 0:
        if total_path == 0:
            print("[compositor] ⚠ image_path не задан ни у одного сегмента — FastGen не вернул результат?")
        else:
            print("[compositor] ⚠ Файлы изображений не найдены на диске:")
            for s in segments_with_images:
                if s.get("show_image") and s.get("image_path"):
                    p = str(s["image_path"])
                    print(f"  {'✓' if os.path.isfile(p) else '✗'} {p}")

    seg_end_times = sorted(
        min(s.get("end", info["duration"]), info["duration"])
        for s in active_segs
    )

    if fade_sec > 0:
        print(f"[compositor] Анимация: fade in/out {fade_sec:.1f}s")

    # Подготовка логотипа
    logo_png: str | None = None
    if logo_enabled and logo_path:
        logo_png = _prepare_logo(logo_path, logo_size)
        if logo_png:
            print(f"[compositor] Логотип: {logo_size}px, отступ {logo_padding}px")
        else:
            print("[compositor] ⚠ Логотип не удалось подготовить — пропускаем")

    # Пустой список зон = весь экран (не side-panel)
    if not zones:
        zones = [[0.0, 0.0, 1.0, 1.0]]
        print("[compositor] Зоны не заданы → весь экран")

    print(f"[compositor] Режим: zone overlay ({len(zones)} зон)")
    cmd = _build_zone_overlay_cmd(
        video_path, segments_with_images, output_path, info, quality, zones,
        fade_sec=fade_sec, logo_png=logo_png, logo_padding=logo_padding,
    )

    print(f"[compositor] FFmpeg → {output_path}")

    global _active_process
    process = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace",
    )
    _active_process = process
    assert process.stdout is not None

    rendered_count = 0
    last_print_sec = -15.0

    def _parse_sec(t_str: str) -> float:
        try:
            parts = t_str.split(":")
            if len(parts) == 3:
                return int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
            return float(t_str)
        except Exception:
            return 0.0

    for line in process.stdout:
        line = line.rstrip()
        if "time=" in line:
            try:
                t_part      = line.split("time=")[1].split()[0]
                speed_part  = line.split("speed=")[1].split()[0] if "speed=" in line else "?"
                current_sec = _parse_sec(t_part)

                if current_sec - last_print_sec >= 15.0:
                    pct = min(100, int(current_sec / info["duration"] * 100))
                    print(f"[render] {t_part}/{info['duration']:.0f}s  {pct}%  speed={speed_part}")
                    last_print_sec = current_sec

                if active_count > 0:
                    new_rendered = sum(1 for et in seg_end_times if et <= current_sec)
                    if new_rendered > rendered_count:
                        rendered_count = new_rendered
                        print(f"[rendered {rendered_count}/{active_count}]")
            except Exception:
                pass
        elif "Error" in line or "Invalid" in line or "No such" in line:
            print(f"[ffmpeg ERR] {line}")

    process.wait()
    _active_process = None
    print()

    if process.returncode != 0:
        raise RuntimeError(f"FFmpeg завершился с кодом {process.returncode}")

    size_mb = os.path.getsize(output_path) / (1024 * 1024)
    print(f"[compositor] Готово: {output_path} ({size_mb:.1f} MB)")
    return output_path
