"""
config.py — централизованные настройки Garden Infographic Composer (macOS).
Читает настройки из settings.json рядом с приложением.
"""
import json
import os
import sys


def _app_dir() -> str:
    """Возвращает папку, где лежит приложение."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def settings_path() -> str:
    return os.path.join(_app_dir(), "settings.json")


def load_settings() -> dict:
    """Загружает settings.json. Возвращает пустой dict если файл не найден."""
    p = settings_path()
    if os.path.isfile(p):
        try:
            with open(p, encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"[config] Ошибка чтения settings.json: {e}")
    return {}


def save_settings(data: dict) -> None:
    """Сохраняет dict в settings.json."""
    p = settings_path()
    with open(p, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


# ── Значения по умолчанию ────────────────────────────────────────────────────
ASSEMBLYAI_API_KEY: str   = ""
GEMINI_API_KEY: str       = ""
OPENAI_API_KEY: str       = ""
FASTGEN_API_KEY: str      = ""
FASTGEN_API_BASE: str     = "https://googler.fast-gen.ai"
AI_BACKEND: str           = "auto"   # "gemini" | "chatgpt" | "claude" | "auto"
OPENAI_MODEL: str         = "gpt-4o-mini"
CLAUDE_ACCESS_TOKEN: str  = ""       # OAuth access_token от claude.ai
CLAUDE_REFRESH_TOKEN: str = ""
CLAUDE_MODEL: str         = "claude-sonnet-4-5"
POSTER_MIX: bool          = False   # подмешивать плакатный стиль
POSTER_RATIO: float       = 0.35    # доля плакатов (0.0–1.0)
VIDEO_MIX_ENABLED: bool   = False   # подмешивать видеоклипы из папки
VIDEO_MIX_DIR: str        = ""      # папка с видеоклипами
VIDEO_MIX_RATIO: float    = 0.25    # доля видеоклипов (0.0–1.0)
LOGO_PATH: str            = ""      # путь к файлу логотипа канала
LOGO_ENABLED: bool        = False   # показывать логотип на видео
LOGO_SIZE: int            = 80      # размер логотипа (пиксели, квадрат)
LOGO_PADDING: int         = 20      # отступ от края кадра


def apply_settings(data: dict) -> None:
    """Применяет dict настроек к глобальным переменным модуля.
    Обновляет только те ключи, которые явно присутствуют в data —
    отсутствующие ключи не затирают уже установленные значения.
    """
    global ASSEMBLYAI_API_KEY, GEMINI_API_KEY, OPENAI_API_KEY, FASTGEN_API_KEY
    global FASTGEN_API_BASE, AI_BACKEND, OPENAI_MODEL
    global CLAUDE_ACCESS_TOKEN, CLAUDE_REFRESH_TOKEN, CLAUDE_MODEL
    global POSTER_MIX, POSTER_RATIO
    global VIDEO_MIX_ENABLED, VIDEO_MIX_DIR, VIDEO_MIX_RATIO
    global LOGO_PATH, LOGO_ENABLED, LOGO_SIZE, LOGO_PADDING
    global PEXELS_API_KEY

    def _get(key, fallback=None):
        return data[key] if key in data else fallback

    if "ASSEMBLYAI_API_KEY"  in data: ASSEMBLYAI_API_KEY  = str(data["ASSEMBLYAI_API_KEY"]  or "")
    if "GEMINI_API_KEY"      in data: GEMINI_API_KEY      = str(data["GEMINI_API_KEY"]      or "")
    if "FASTGEN_API_KEY"     in data: FASTGEN_API_KEY     = str(data["FASTGEN_API_KEY"]     or "")
    if "FASTGEN_API_BASE"    in data: FASTGEN_API_BASE    = str(data["FASTGEN_API_BASE"]    or "https://googler.fast-gen.ai")
    if "AI_BACKEND"          in data: AI_BACKEND          = str(data["AI_BACKEND"]          or "auto").lower()
    if "OPENAI_MODEL"        in data: OPENAI_MODEL        = str(data["OPENAI_MODEL"]        or "gpt-4o-mini")
    if "CLAUDE_MODEL"        in data: CLAUDE_MODEL        = str(data["CLAUDE_MODEL"]        or "claude-sonnet-4-5")
    if "POSTER_MIX"          in data: POSTER_MIX          = bool(data["POSTER_MIX"])
    if "POSTER_RATIO"        in data: POSTER_RATIO        = float(data["POSTER_RATIO"])
    if "video_mix_enabled"   in data: VIDEO_MIX_ENABLED   = bool(data["video_mix_enabled"])
    if "video_mix_dir"       in data: VIDEO_MIX_DIR       = str(data["video_mix_dir"]       or "")
    if "video_mix_ratio"     in data: VIDEO_MIX_RATIO     = float(data["video_mix_ratio"])
    if "LOGO_PATH"           in data: LOGO_PATH           = str(data["LOGO_PATH"]           or "")
    if "LOGO_ENABLED"        in data: LOGO_ENABLED        = bool(data["LOGO_ENABLED"])
    if "LOGO_SIZE"           in data: LOGO_SIZE           = int(data["LOGO_SIZE"])
    if "LOGO_PADDING"        in data: LOGO_PADDING        = int(data["LOGO_PADDING"])
    if "PEXELS_API_KEY"      in data: PEXELS_API_KEY      = str(data["PEXELS_API_KEY"]      or "")

    # OPENAI: поддерживаем оба имени ключа — OPENAI_API_KEY и OPENAI_ACCESS_TOKEN
    # (OAuth-токен сохраняется под именем OPENAI_ACCESS_TOKEN)
    if "OPENAI_API_KEY"      in data: OPENAI_API_KEY      = str(data["OPENAI_API_KEY"]      or "")
    if "OPENAI_ACCESS_TOKEN" in data: OPENAI_API_KEY      = str(data["OPENAI_ACCESS_TOKEN"] or "")

    # CLAUDE: аналогично — CLAUDE_ACCESS_TOKEN → CLAUDE_ACCESS_TOKEN
    if "CLAUDE_ACCESS_TOKEN"  in data: CLAUDE_ACCESS_TOKEN  = str(data["CLAUDE_ACCESS_TOKEN"]  or "")
    if "CLAUDE_REFRESH_TOKEN" in data: CLAUDE_REFRESH_TOKEN = str(data["CLAUDE_REFRESH_TOKEN"] or "")


# Автозагрузка при импорте
apply_settings(load_settings())

# ── Пути ─────────────────────────────────────────────────────────────────────
_BASE = _app_dir()
CACHE_DIR:        str = os.path.join(_BASE, "cache")
GENERATED_DIR:    str = os.path.join(_BASE, "generated")
PANELS_CACHE_DIR: str = os.path.join(_BASE, "cache", "panels")
LOG_DIR:          str = os.path.join(_BASE, "logs")
INPUT_DIR:        str = os.path.join(_BASE, "input")
OUTPUT_DIR:       str = os.path.join(_BASE, "output")
IMAGE_CACHE_DIR:  str = GENERATED_DIR

# ── Параметры видео ───────────────────────────────────────────────────────────
FADE_DURATION: float           = 0.5
MIN_SEGMENT_DURATION: float    = 2.0
INFOGRAPHIC_DISPLAY_SEC: float = 12.0

# ── Gemini ────────────────────────────────────────────────────────────────────
GEMINI_MODEL: str    = "gemini-2.5-flash"
GPT_MAX_RETRIES: int = 2

# ── Инфографики ───────────────────────────────────────────────────────────────
DEFAULT_MAX_INFOGRAPHICS: int = 15

PEXELS_API_KEY: str = ""         # API-ключ от pexels.com/api

# ── FastGen движки ────────────────────────────────────────────────────────────
FASTGEN_ENGINES: dict[str, str] = {
    "1": "GEM_PIX_2",
    "2": "NARWHAL",
    "3": "GEMINI",
    "4": "GROK",
    "5": "GEM_PIX",
    "6": "IMAGEN_3_5",
}
FASTGEN_DEFAULT_ENGINE: str = "NARWHAL"

# ── Загрузка изображений ──────────────────────────────────────────────────────
IMAGE_FETCH_WORKERS: int = 1   # FastGen не переносит параллельных запросов → строго последовательно
IMAGE_TIMEOUT: int       = 30
IMAGE_GEN_TIMEOUT: int   = 120

# ── Layout ────────────────────────────────────────────────────────────────────
SIDE_VIDEO_RATIO: float = 0.60
OVERLAY_PADDING: int    = 20

# ── FFmpeg ────────────────────────────────────────────────────────────────────
VIDEO_CODEC: str = "libx264"
AUDIO_CODEC: str = "aac"

QUALITY_PROFILES: dict[str, dict] = {
    "720fast": {
        "scale":       "1280:720",
        "crf":         "23",
        "preset":      "fast",
        "audio_copy":  True,   # аудио 1:1
        "label":       "720p Быстро (fast, CRF 23) — ~3-5 мин рендер",
    },
    "1080": {
        "scale":       None,
        "crf":         "18",
        "preset":      "fast",
        "audio_copy":  True,   # аудио 1:1
        "label":       "1080p Качество (fast, CRF 18) — ~5-10 мин рендер",
    },
    "highq": {
        "scale":       None,
        "crf":         "14",
        "preset":      "slow",
        "audio_copy":  True,   # аудио 1:1
        "label":       "Максимальное качество (slow, CRF 14) — ~20-30 мин рендер",
    },
}
