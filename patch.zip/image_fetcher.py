"""
image_fetcher.py — генерация огородных/садоводческих инфографик через FastGen API.
"""

import base64
import os
import threading
import time
from typing import Any

import requests

import config as _cfg                  # динамическая ссылка — ключ читается в момент вызова
from config import GENERATED_DIR, IMAGE_GEN_TIMEOUT
from utils import ensure_dirs, log_exception, sanitize_filename, setup_logger

logger = setup_logger(__name__)

_FLOW_MODELS   = {"NARWHAL", "GEM_PIX", "GEM_PIX_2", "IMAGEN_3_5"}
_POLL_INTERVAL = 3
_POLL_MAX      = 50

# ── Rate limiter — не менее 2 сек между любыми запросами к FastGen ───────────
_RL_LOCK      = threading.Lock()
_RL_LAST_TIME = 0.0
_RL_GAP_SEC   = 2.0   # минимальная пауза между запросами

def _rate_limit():
    global _RL_LAST_TIME
    with _RL_LOCK:
        elapsed = time.time() - _RL_LAST_TIME
        if _RL_LAST_TIME > 0 and elapsed < _RL_GAP_SEC:
            time.sleep(_RL_GAP_SEC - elapsed)
        _RL_LAST_TIME = time.time()


_BLOCK_KEYWORDS = (
    "block", "blocked", "safety", "policy", "violat", "content filter",
    "not allowed", "inappropriate", "rejected", "refused", "filtered",
    "generation failed", "cannot generate",
)


def _headers() -> dict[str, str]:
    # Читаем из config в момент вызова, чтобы подхватить apply_settings()
    return {
        "X-API-Key": _cfg.FASTGEN_API_KEY or "",
        "Content-Type": "application/json",
    }


def _is_censored(error_text: str) -> bool:
    low = (error_text or "").lower()
    return any(kw in low for kw in _BLOCK_KEYWORDS)


def _poll_operation(operation_id: str, session: requests.Session) -> tuple[list[str] | None, str | None]:
    url = f"{_cfg.FASTGEN_API_BASE}/api/v4/operations/{operation_id}"
    for attempt in range(_POLL_MAX):
        try:
            r = session.get(url, headers=_headers(), timeout=30)
            r.raise_for_status()
            data: dict[str, Any] = r.json()
            status = data.get("status", "")
            if status == "success":
                raw_result = data.get("result") or data.get("images") or data.get("url") or []
                # Normalise to list[str]
                if isinstance(raw_result, str):
                    result: list[str] = [raw_result]
                elif isinstance(raw_result, dict):
                    u = raw_result.get("url") or raw_result.get("image") or ""
                    result = [u] if u else []
                elif isinstance(raw_result, list):
                    extracted: list[str] = []
                    for item in raw_result:
                        if isinstance(item, str):
                            extracted.append(item)
                        elif isinstance(item, dict):
                            u = item.get("url") or item.get("image") or item.get("src") or ""
                            if u:
                                extracted.append(u)
                    result = extracted
                else:
                    result = []
                if not result:
                    print(f"  [Poll] Success but empty result. Full data keys: {list(data.keys())}")
                    print(f"  [Poll] data sample: {str(data)[:300]}")
                return result, None
            if status == "error":
                err = data.get("error") or str(data.get("translations", ""))
                return None, err
            time.sleep(_POLL_INTERVAL)
        except Exception as exc:
            logger.warning(f"Poll attempt {attempt+1}: {exc}")
            time.sleep(_POLL_INTERVAL)
    return None, "timeout"


_RETRY_DELAYS = [10, 20, 40, 60]   # секунды ожидания между попытками при 429/таймауте


def _is_retryable(exc: Exception) -> bool:
    """Возвращает True если ошибка стоит повторить (сетевой таймаут / 429)."""
    s = str(exc).lower()
    return any(k in s for k in ("429", "timeout", "timed out", "read timeout",
                                "connection", "handshake", "ssl"))


def _post_with_retry(
    tag: str,
    url: str,
    payload: dict,
    session: requests.Session,
) -> "requests.Response | None":
    """POST с автоматическим повтором при 429 Rate Limit или сетевом таймауте."""
    for attempt, delay in enumerate([0] + _RETRY_DELAYS):
        if delay:
            print(f"  [FastGen:{tag}] повтор через {delay}с (попытка {attempt + 1}/{len(_RETRY_DELAYS) + 1})...")
            time.sleep(delay)
        _rate_limit()   # гарантируем минимальный интервал между запросами
        try:
            resp = session.post(url, headers=_headers(), json=payload, timeout=IMAGE_GEN_TIMEOUT)
            if resp.status_code == 429:
                if attempt < len(_RETRY_DELAYS):
                    print(f"  [FastGen:{tag}] 429 Rate Limit...")
                    continue
                print(f"  [FastGen:{tag}] 429 — все попытки исчерпаны")
                return None
            if not resp.ok:
                if resp.status_code == 401:
                    print(f"  [FastGen:{tag}] 401 Unauthorized — проверь FASTGEN_API_KEY!")
                else:
                    print(f"  [FastGen:{tag}] HTTP {resp.status_code}: {resp.text[:200]}")
                resp.raise_for_status()
            return resp
        except Exception as exc:
            if _is_retryable(exc) and attempt < len(_RETRY_DELAYS):
                print(f"  [FastGen:{tag}] сетевая ошибка: {type(exc).__name__}")
                continue
            log_exception(logger, f"FastGen {tag}: {exc}")
            return None
    return None


def _start_flow(prompt: str, model: str, session: requests.Session) -> str | None:
    url = f"{_cfg.FASTGEN_API_BASE}/api/v4/flow/image/generate"
    payload: dict[str, Any] = {
        "prompt": prompt,
        "model": model,
        "aspect_ratio": "IMAGE_ASPECT_RATIO_LANDSCAPE",
    }
    resp = _post_with_retry(model, url, payload, session)
    if resp is None:
        return None
    try:
        data = resp.json()
        op_id = data.get("operation_id")
        if not op_id:
            print(f"  [FastGen:{model}] Нет operation_id: {str(data)[:150]}")
        return op_id
    except Exception as exc:
        log_exception(logger, f"FastGen start flow ({model}) parse: {exc}")
        return None


def _start_grok(prompt: str, session: requests.Session) -> str | None:
    url = f"{_cfg.FASTGEN_API_BASE}/api/v4/grok/image/generate"
    payload: dict[str, Any] = {"prompt": prompt, "aspect_ratio": "16:9"}
    resp = _post_with_retry("GROK", url, payload, session)
    if resp is None:
        return None
    try:
        return resp.json().get("operation_id")
    except Exception as exc:
        log_exception(logger, f"FastGen start GROK parse: {exc}")
        return None


def _start_gemini(prompt: str, session: requests.Session) -> str | None:
    url = f"{_cfg.FASTGEN_API_BASE}/api/v4/gemini/image/generate"
    payload: dict[str, Any] = {"prompt": prompt}
    resp = _post_with_retry("GEMINI", url, payload, session)
    if resp is None:
        return None
    try:
        data = resp.json()
        return data.get("operation_id")
    except Exception as exc:
        log_exception(logger, f"FastGen start GEMINI: {exc}")
        return None


def _save_image_result(data_uri: str, dest: str, session: requests.Session) -> bool:
    """Save image from either a base64 data-URI or a remote URL."""
    try:
        if data_uri.startswith("http://") or data_uri.startswith("https://"):
            r = session.get(data_uri, timeout=60)
            r.raise_for_status()
            raw = r.content
        else:
            # base64 / data URI
            b64 = data_uri.split(",", 1)[1] if "," in data_uri else data_uri
            raw = base64.b64decode(b64)
        # Always write dest path (caller decides extension)
        with open(dest, "wb") as f:
            f.write(raw)
        return True
    except Exception as exc:
        log_exception(logger, f"Save image: {exc}")
        return False


def _pexels_search_query(prompt: str) -> str:
    """
    Извлекает поисковый запрос для Pexels из промпта.

    Приоритеты:
    1. Совпадение русского ключевого слова из _KEYWORD_MAP → английское описание
    2. Промпт уже на английском (AI сгенерировал) → берём первое предложение
    3. Fallback из _POSTER_FALLBACKS по хешу промпта
    """
    import re
    import hashlib

    # ── Убираем стандартные префиксы ────────────────────────────────────────
    text = prompt
    for prefix in (
        "Professional garden photography, ",
        "White background gardening infographic illustrating: ",
        "White background gardening infographic. ",
        "Educational labeled diagram",
    ):
        if text.lower().startswith(prefix.lower()):
            text = text[len(prefix):]
            break

    text_lower = text.lower()

    # ── 1. Ищем огородное ключевое слово (русское или английское) ────────────
    try:
        from keyword_extractor import _KEYWORD_MAP
        for kw, english_desc in _KEYWORD_MAP:
            if kw in text_lower:
                # Берём первое предложение из английского описания
                q = re.split(r"[.,]", english_desc)[0].strip()
                return q[:100]
    except Exception:
        pass

    # ── 2. Текст уже на английском (AI сгенерировал нормальный промпт) ──────
    latin_ratio = sum(1 for c in text if c.isascii() and c.isalpha()) / max(len(text), 1)
    if latin_ratio > 0.5:
        q = re.split(r"[.,\n]", text)[0].strip()[:100]
        if q:
            return q

    # ── 3. Fallback: случайный огородный запрос по хешу промпта ─────────────
    try:
        from keyword_extractor import _POSTER_FALLBACKS
        idx = int(hashlib.md5(prompt.encode()).hexdigest(), 16) % len(_POSTER_FALLBACKS)
        return _POSTER_FALLBACKS[idx]
    except Exception:
        pass

    return "vegetable garden plants"


def _fetch_pexels_image(
    prompt: str,
    dest: str,
    session: requests.Session,
) -> bool:
    """Скачивает изображение с Pexels по поисковому запросу из промпта."""
    api_key = _cfg.PEXELS_API_KEY
    if not api_key:
        print("  [Pexels] PEXELS_API_KEY не задан — проверьте настройки!")
        return False

    query = _pexels_search_query(prompt)
    print(f"  [Pexels] Поиск: «{query}»")

    url = "https://api.pexels.com/v1/search"
    params = {
        "query":       query,
        "per_page":    5,
        "orientation": "landscape",
    }
    headers = {"Authorization": api_key}

    try:
        resp = session.get(url, headers=headers, params=params, timeout=20)
        if resp.status_code == 401:
            print("  [Pexels] 401 Unauthorized — неверный ключ!")
            return False
        if resp.status_code == 429:
            print("  [Pexels] 429 Rate Limit — превышен лимит запросов")
            return False
        resp.raise_for_status()
        # Показываем остаток запросов из заголовков
        remaining = resp.headers.get("X-Ratelimit-Requests-Remaining")
        limit     = resp.headers.get("X-Ratelimit-Requests-Limit")
        if remaining is not None and limit is not None:
            print(f"  [Pexels] Запросов осталось: {remaining}/{limit}")
        data = resp.json()
        photos = data.get("photos", [])
        if not photos:
            print(f"  [Pexels] Нет результатов для: «{query}»")
            return False
        # Берём первое фото, предпочитаем large2x → large → original
        src = photos[0].get("src", {})
        img_url = src.get("large2x") or src.get("large") or src.get("original")
        if not img_url:
            print("  [Pexels] Нет URL изображения в ответе")
            return False
        # Скачиваем изображение
        img_resp = session.get(img_url, timeout=30)
        img_resp.raise_for_status()
        with open(dest, "wb") as f:
            f.write(img_resp.content)
        photographer = photos[0].get("photographer", "?")
        print(f"  [Pexels] OK — фото: {photographer} → {dest}")
        return True
    except Exception as exc:
        log_exception(logger, f"Pexels fetch: {exc}")
        return False


def _generate_with_engine(prompt: str, engine: str, session: requests.Session) -> tuple[list[str] | None, str | None]:
    if engine in _FLOW_MODELS:
        op_id = _start_flow(prompt, engine, session)
    elif engine == "GROK":
        op_id = _start_grok(prompt, session)
    elif engine == "GEMINI":
        op_id = _start_gemini(prompt, session)
    else:
        logger.warning(f"Unknown engine '{engine}', using NARWHAL")
        op_id = _start_flow(prompt, "NARWHAL", session)
    if not op_id:
        return None, "failed to start"
    print(f"  [FastGen:{engine}] operation_id={op_id[:8]}... waiting...")
    return _poll_operation(op_id, session)


def fetch_image(
    prompt: str,
    mode: str = "generate",
    engine: str = "NARWHAL",
    cache_key: str | None = None,
) -> str | None:
    ensure_dirs(GENERATED_DIR)
    key  = sanitize_filename(cache_key or prompt)[:100]
    dest = os.path.join(GENERATED_DIR, f"{key}.jpg" if engine == "PEXELS" else f"{key}.png")

    # ── Pexels (поиск реальных фото) ─────────────────────────────────────────
    if engine == "PEXELS":
        with requests.Session() as session:
            session.headers["User-Agent"] = "GardenInfographicComposer/1.0"
            if _fetch_pexels_image(prompt, dest, session):
                return dest
        return None

    if not _cfg.FASTGEN_API_KEY:
        print(f"  [FastGen] FASTGEN_API_KEY is empty — check Settings!")
        logger.warning("FASTGEN_API_KEY not set")
        return None

    print(f"  [FastGen:{engine}] key={_cfg.FASTGEN_API_KEY[:6]}... Starting generation...")

    with requests.Session() as session:
        session.headers["User-Agent"] = "GardenInfographicComposer/1.0"
        results, error = _generate_with_engine(prompt, engine, session)

        if results:
            r0 = results[0]
            print(f"  [FastGen:{engine}] result type: {'URL' if r0.startswith('http') else 'base64'}, len={len(r0)}")
            if _save_image_result(r0, dest, session):
                print(f"  [FastGen:{engine}] OK → {dest}")
                return dest
            else:
                print(f"  [FastGen:{engine}] Save failed for result: {r0[:80]}")

        if error and _is_censored(error):
            print(f"  [FastGen:{engine}] Censored: {error[:80]}")
            print(f"  [FastGen:GROK] Fallback to GROK...")
            results_grok, error_grok = _generate_with_engine(prompt, "GROK", session)
            if results_grok:
                if _save_image_result(results_grok[0], dest, session):
                    print(f"  [FastGen:GROK] OK → {dest}")
                    return dest
            else:
                print(f"  [FastGen:GROK] Failed: {str(error_grok)[:80]}")
        elif error:
            print(f"  [FastGen:{engine}] Error: {error[:120]}")
        elif not results:
            print(f"  [FastGen:{engine}] No results returned (empty result set)")

    logger.warning(f"Image not obtained: {prompt[:60]}")
    return None
