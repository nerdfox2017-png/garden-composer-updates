#!/bin/bash
# ============================================================
#  Garden Infographic Composer — Установщик для macOS
# ============================================================
set -e

BOLD="\033[1m"
GREEN="\033[0;32m"
YELLOW="\033[1;33m"
RED="\033[0;31m"
RESET="\033[0m"

echo ""
echo -e "${GREEN}${BOLD}🌱 Garden Infographic Composer — Установка${RESET}"
echo "=============================================="
echo ""

# Добавляем Homebrew в PATH заранее (Apple Silicon и Intel)
if [ -f "/opt/homebrew/bin/brew" ]; then
    eval "$(/opt/homebrew/bin/brew shellenv)"
elif [ -f "/usr/local/bin/brew" ]; then
    eval "$(/usr/local/bin/brew shellenv)"
fi

# ── 1. Ищем Python 3.10–3.13 с рабочим tkinter ───────────────────────────
echo -e "${BOLD}[1/4] Проверяем Python...${RESET}"

# Функция: проверить что python-бинарник имеет tkinter и версию 3.10–3.13
find_good_python() {
    for PY in python3.13 python3.12 python3.11 python3.10 \
               /opt/homebrew/bin/python3.13 /opt/homebrew/bin/python3.12 \
               /opt/homebrew/bin/python3.11 /opt/homebrew/bin/python3.10 \
               /usr/local/bin/python3.13 /usr/local/bin/python3.12 \
               /usr/local/bin/python3.11 /usr/local/bin/python3.10 \
               /Library/Frameworks/Python.framework/Versions/3.13/bin/python3 \
               /Library/Frameworks/Python.framework/Versions/3.12/bin/python3 \
               /Library/Frameworks/Python.framework/Versions/3.11/bin/python3; do
        if command -v "$PY" &>/dev/null 2>&1 || [ -f "$PY" ]; then
            MINOR=$("$PY" -c "import sys; print(sys.version_info.minor)" 2>/dev/null)
            MAJOR=$("$PY" -c "import sys; print(sys.version_info.major)" 2>/dev/null)
            if [ "$MAJOR" = "3" ] && [ "$MINOR" -ge 10 ] && [ "$MINOR" -le 13 ] 2>/dev/null; then
                if "$PY" -c "import tkinter" &>/dev/null 2>&1; then
                    echo "$PY"
                    return 0
                fi
            fi
        fi
    done
    return 1
}

GOOD_PY=$(find_good_python 2>/dev/null || true)

if [ -z "$GOOD_PY" ]; then
    # Текущий python3 — проверяем версию
    if command -v python3 &>/dev/null; then
        CUR_MINOR=$(python3 -c "import sys; print(sys.version_info.minor)" 2>/dev/null)
        CUR_MAJOR=$(python3 -c "import sys; print(sys.version_info.major)" 2>/dev/null)

        if [ "$CUR_MAJOR" = "3" ] && [ "$CUR_MINOR" -ge 14 ] 2>/dev/null; then
            echo -e "${YELLOW}Обнаружен Python 3.$CUR_MINOR (pre-release) — tkinter может отсутствовать.${RESET}"
            echo -e "${YELLOW}Пробуем установить python-tk через Homebrew...${RESET}"
            if command -v brew &>/dev/null; then
                brew install python-tk@3.$CUR_MINOR 2>/dev/null || true
                # Пробуем снова после установки
                if python3 -c "import tkinter" &>/dev/null 2>&1; then
                    GOOD_PY="python3"
                fi
            fi
        fi

        if [ -z "$GOOD_PY" ]; then
            # Устанавливаем Python 3.12 через Homebrew (стабильный, с tkinter)
            echo -e "${YELLOW}Устанавливаем Python 3.12 через Homebrew...${RESET}"
            if ! command -v brew &>/dev/null; then
                echo "Homebrew не найден. Устанавливаем Homebrew..."
                /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
                if [ -f "/opt/homebrew/bin/brew" ]; then
                    eval "$(/opt/homebrew/bin/brew shellenv)"
                fi
            fi
            brew install python@3.12
            brew install python-tk@3.12
            GOOD_PY="$(brew --prefix python@3.12)/bin/python3.12"
        fi
    else
        echo -e "${RED}Python3 не найден!${RESET}"
        echo "Установите Python 3.12 с https://www.python.org/downloads/"
        exit 1
    fi
fi

PY_VERSION=$("$GOOD_PY" -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}')")
echo -e "  ${GREEN}✓ Python $PY_VERSION ($GOOD_PY)${RESET}"

# ── 2. Проверяем ffmpeg ───────────────────────────────────────────────────
echo ""
echo -e "${BOLD}[2/4] Проверяем ffmpeg...${RESET}"
if ! command -v ffmpeg &>/dev/null; then
    echo -e "${YELLOW}ffmpeg не найден. Устанавливаем через Homebrew...${RESET}"
    if ! command -v brew &>/dev/null; then
        echo "Homebrew не найден. Устанавливаем Homebrew..."
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
        if [ -f "/opt/homebrew/bin/brew" ]; then
            eval "$(/opt/homebrew/bin/brew shellenv)"
        fi
    fi
    brew install ffmpeg
    echo -e "  ${GREEN}✓ ffmpeg установлен${RESET}"
else
    FFMPEG_VERSION=$(ffmpeg -version 2>&1 | head -1 | awk '{print $3}')
    echo -e "  ${GREEN}✓ ffmpeg $FFMPEG_VERSION${RESET}"
fi

# ── 3. Создаём виртуальное окружение ─────────────────────────────────────
echo ""
echo -e "${BOLD}[3/4] Создаём виртуальное окружение Python...${RESET}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Если существующий venv создан другим Python — удаляем
if [ -d "venv" ]; then
    VENV_PY=$(cat venv/pyvenv.cfg 2>/dev/null | grep "^home" | awk -F= '{print $2}' | tr -d ' ')
    GOOD_PY_DIR=$(dirname "$GOOD_PY")
    if [ -n "$VENV_PY" ] && [ "$VENV_PY" != "$GOOD_PY_DIR" ]; then
        echo -e "  ${YELLOW}venv создан другим Python, пересоздаём...${RESET}"
        rm -rf venv
    else
        echo -e "  ${GREEN}✓ venv уже существует${RESET}"
    fi
fi

if [ ! -d "venv" ]; then
    "$GOOD_PY" -m venv venv
    echo -e "  ${GREEN}✓ venv создан${RESET}"
fi

source venv/bin/activate

# ── 4. Устанавливаем зависимости ─────────────────────────────────────────
echo ""
echo -e "${BOLD}[4/4] Устанавливаем Python-зависимости...${RESET}"
python3 -m pip install --upgrade pip --quiet
python3 -m pip install -r requirements.txt

echo ""
echo -e "${GREEN}${BOLD}✅ Установка завершена!${RESET}"
echo ""
echo -e "Для запуска программы используйте:"
echo -e "  ${BOLD}double-click на run.command${RESET}"
echo -e "или в терминале:"
echo -e "  ${BOLD}source venv/bin/activate && python3 app.py${RESET}"
echo ""
