"""
keyword_extractor.py — Gemini или ChatGPT как режиссёр огородного видео.
Генерирует детальные промпты для огородных/садоводческих инфографик.
Поддерживает два AI-бэкенда: Gemini (Google) и ChatGPT (OpenAI).
"""

import json
import re
import time
from typing import Any

from config import GEMINI_API_KEY, GEMINI_MODEL, GPT_MAX_RETRIES, OPENAI_API_KEY, OPENAI_MODEL, AI_BACKEND

# Injected by app.py before each run; overrides AI prompts when set
_custom_prompts: list[str] | None = None


def _fmt_time(seconds: float) -> str:
    m = int(seconds) // 60
    s = int(seconds) % 60
    return f"{m:02d}:{s:02d}"


# ---------------------------------------------------------------------------
# Промпт для плакатного стиля (один крупный объект + минимум текста)
# ---------------------------------------------------------------------------

_POSTER_PROMPT_TEMPLATE = (
    "Professional garden photography, {subject}. "
    "Shot like a popular gardening blogger — natural sunlight, shallow depth of field, "
    "warm earthy tones, vibrant greens. "
    "Close-up or mid-shot showing natural beauty and texture. "
    "Real garden or vegetable patch setting, rich soil or green foliage in background. "
    "No people, no text, no watermarks, no labels, no overlays. "
    "Ultra-realistic DSLR photo, crisp details, high resolution."
)

# Порядок важен: более конкретные слова должны идти раньше
_KEYWORD_MAP: list[tuple[str, str]] = [
    # ── Овощи ────────────────────────────────────────────────────────────────
    ("томат",          "cluster of ripe red tomatoes hanging on the vine in a sunny garden"),
    ("помидор",        "cluster of ripe red tomatoes hanging on the vine in a sunny garden"),
    ("огурец",         "fresh cucumbers growing on a vine with bright yellow flowers in the garden"),
    ("огурц",          "fresh cucumbers growing on a vine with bright yellow flowers in the garden"),
    ("кабачок",        "large zucchini with bright yellow flower growing in a garden bed"),
    ("кабачк",         "large zucchini with bright yellow flower growing in a garden bed"),
    ("перец",          "colorful bell peppers red and yellow ripening on a plant in a garden"),
    ("болгарск",       "colorful bell peppers red and yellow ripening on a plant in a garden"),
    ("морков",         "freshly harvested carrots with green tops lying on garden soil"),
    ("картофел",       "freshly dug potatoes in dark garden soil with green potato tops"),
    ("картошк",        "freshly dug potatoes in dark garden soil with green potato tops"),
    ("баклажан",       "glossy purple eggplants ripening on a plant in a warm garden"),
    ("капуст",         "large green cabbage head growing in a vegetable garden"),
    ("свёкл",          "beet plants with colorful red stems and leaves in a garden bed"),
    ("свекл",          "beet plants with colorful red stems and leaves in a garden bed"),
    ("тыкв",           "big orange pumpkins on green vines in a garden"),
    ("кукуруз",        "golden corn cobs with green husks on tall stalks in a field"),
    ("горох",          "green pea pods on climbing tendrils in a garden"),
    ("фасол",          "green bean pods hanging on a vine in a vegetable garden"),
    ("брокколи",       "fresh green broccoli head in a garden bed with morning dew"),
    ("цветная капуст", "white cauliflower head surrounded by large green leaves in a garden"),
    ("редис",          "round red radishes freshly pulled from dark garden soil"),
    ("редьк",          "round red radishes freshly pulled from dark garden soil"),
    # ── Ягоды и фрукты ───────────────────────────────────────────────────────
    ("клубник",        "ripe red strawberries with white flowers on a plant in the garden"),
    ("земляник",       "wild strawberries with tiny red berries in a forest clearing"),
    ("малин",          "clusters of ripe red raspberries on a cane in the garden"),
    ("смородин",       "black currant clusters hanging on a branch with green leaves"),
    ("крыжовник",      "translucent green gooseberries hanging on a bush branch"),
    ("голубик",        "ripe blue blueberries on a bush with green leaves in a garden"),
    ("черник",         "wild blueberries and bilberries growing in a forest setting"),
    ("ежевик",         "ripe blackberries on a thorny cane in the garden"),
    ("облепих",        "bright orange sea buckthorn berries on a thorny branch"),
    ("брусник",        "red lingonberries growing on a low bush in the forest"),
    ("жимолост",       "elongated dark blue honeysuckle berries on a garden bush"),
    ("шелковиц",       "mulberry berries ripening on a tree branch"),
    ("виноград",       "bunches of ripe grapes on a vine in warm sunlight"),
    ("яблок",          "ripe red apples on a branch with green leaves in an orchard"),
    ("груш",           "golden ripe pears hanging on a tree branch"),
    ("слив",           "juicy purple plums ripening on a tree branch"),
    ("вишн",           "bright red cherries hanging on a branch with green leaves"),
    ("черешн",         "sweet yellow-red cherries on a branch in an orchard"),
    ("абрикос",        "ripe orange apricots on a tree branch in a garden"),
    ("персик",         "fuzzy ripe peaches hanging on a tree branch"),
    ("айв",            "yellow quince fruit on a tree branch"),
    # ── Зелень и травы ───────────────────────────────────────────────────────
    ("чеснок",         "freshly harvested garlic bulbs with dry skins on a rustic wooden surface"),
    ("лук",            "green onion tops growing in rows in a vegetable garden"),
    ("базилик",        "lush green basil herb growing in a garden in warm sunlight"),
    ("укроп",          "fresh dill with feathery fronds and yellow umbels in the garden"),
    ("петрушк",        "fresh parsley bunch with curly leaves in a garden"),
    ("мята",           "mint herb with lush green textured leaves growing in a pot"),
    ("шалфей",         "sage herb with silver-green velvety leaves in a herb garden"),
    ("тимьян",         "thyme with tiny green leaves and purple flowers in a garden"),
    ("розмарин",       "rosemary bush with needle-like leaves in a sunny herb garden"),
    ("кориандр",       "coriander with delicate feathery green leaves in a garden"),
    # ── Цветы ────────────────────────────────────────────────────────────────
    ("подсолнух",      "tall sunflowers with bright yellow petals and dark centers in a field"),
    ("бархатц",        "bright orange and yellow marigolds in a garden bed"),
    ("настурц",        "vibrant orange nasturtium flowers with round leaves in a garden"),
    # ── Дикоросы и сорняки в огороде ─────────────────────────────────────────
    ("крапив",         "stinging nettle plants with serrated leaves and tiny flowers growing wild near a garden"),
    ("одуванчик",      "bright yellow dandelion flowers and fluffy seed heads in a green meadow"),
    ("лопух",          "large burdock leaves with round spiky seed heads growing at a garden edge"),
    ("пырей",          "dense green couch grass growing in a garden bed close-up"),
    ("осот",           "sow thistle weed with yellow flowers growing in a garden"),
    ("подорожник",     "plantain leaves with ribbed texture growing low to the ground"),
    # ── Уход ─────────────────────────────────────────────────────────────────
    ("полив",          "garden beds being watered in the morning with visible water drops on leaves"),
    ("лейк",           "garden beds being watered in the morning with visible water drops on leaves"),
    ("компост",        "rich dark compost and fertile garden soil in a vegetable bed"),
    ("удобрен",        "healthy lush vegetable plants growing in a well-fertilized garden"),
    ("настой",         "large bucket with fermenting green plant liquid fertilizer in a garden"),
    ("мульч",          "vegetable garden bed with straw mulch layer around plants"),
    ("листов",         "autumn leaves being raked into a pile as garden mulch material"),
    ("перегной",       "rich dark humus compost being added to a vegetable garden bed"),
    ("грядк",          "neat raised vegetable garden beds with rows of growing plants"),
    ("рассад",         "young seedlings sprouting in small cells in a seedling tray"),
    ("семен",          "vegetable seeds and seedlings in early spring garden"),
    ("инструмент",     "garden tools trowel and gloves on rich dark garden soil"),
    ("лопат",          "freshly turned dark garden soil ready for planting"),
    ("тяпк",           "cultivated loose garden soil between vegetable rows"),
    ("теплиц",         "lush plants and vegetables growing inside a sunny greenhouse"),
    ("парник",         "young plants sheltered under a garden cold frame in spring"),
    ("обрезк",         "pruning a garden shrub with fresh green growth"),
    ("прищипк",        "pinching young plant shoots to encourage bushy growth"),
    ("пересадк",       "young plant being transplanted into rich garden soil"),
    ("вредител",       "close-up of plant pest insects on a vegetable leaf in the garden"),
    ("болезн",         "plant disease spots on a vegetable leaf in a garden close-up"),
    ("гусениц",        "caterpillar on a green leaf in a vegetable garden close-up"),
    ("тля",            "aphids colony on a plant stem close-up in a garden"),
    # ── Плоды и урожай ───────────────────────────────────────────────────────
    ("ягод",           "ripe colorful berries growing on a bush in a summer garden"),
    ("плод",           "ripe vegetable fruits hanging on plants in a summer garden"),
    ("урожай",         "abundant vegetable harvest in a basket on garden ground"),
    ("сбор",           "harvesting ripe vegetables from garden beds by hand"),
    ("варень",         "homemade jam jars with fresh berries on a rustic table"),
    ("заготовк",       "preserved vegetables and jars of pickles on a kitchen table"),
    ("малин",          "ripe red raspberries on a bush with green leaves"),
    ("смородин",       "clusters of currant berries on a garden bush"),
    ("крыжовник",      "gooseberries on a thorny bush in a garden"),
    ("голубик",        "ripe blueberries on a bush with green leaves"),
    ("черник",         "blueberries and bilberries growing on low bushes"),
    ("ежевик",         "ripe blackberries on a thorny cane"),
    ("облепих",        "bright orange sea buckthorn berries on a branch"),
    ("брусник",        "red lingonberries on a low bush"),
    ("жимолост",       "dark blue honeysuckle berries on a garden bush"),
    ("вишн",           "ripe red cherries on a branch"),
    ("черешн",         "sweet ripe cherries on a tree branch"),
    ("яблок",          "ripe apples on a tree branch in an orchard"),
    ("груш",           "ripe pears hanging on a tree branch"),
    ("слив",           "ripe purple plums on a tree branch"),
    ("виноград",       "bunch of grapes growing on a vine in a garden"),
    # ── Огород общее ─────────────────────────────────────────────────────────
    ("огород",         "neat vegetable garden with rows of growing plants in sunlight"),
    ("дач",            "cozy Russian dacha vegetable garden with wooden raised beds"),
    ("участок",        "garden plot with vegetable beds and pathways in summer"),
    ("почв",           "rich dark fertile garden soil ready for planting"),
    ("земл",           "freshly dug dark garden soil with garden tools nearby"),
    ("корен",          "root vegetables freshly dug from dark garden soil"),
    ("стебл",          "close-up of thick plant stem and leaves in a garden"),
    ("лист",           "bright green plant leaves with morning sunlight in a garden"),
    ("цвет",           "colorful vegetable flowers and blossoms in a garden"),
    ("корм",           "feeding garden plants with organic fertilizer by hand"),
    ("сорняк",         "weeds being removed from a vegetable garden bed"),
    ("прополк",        "hand weeding between rows of vegetable plants in a garden"),
    ("окучива",        "hilling soil around vegetable plant stems in a garden"),
    # ── English fallback ─────────────────────────────────────────────────────
    ("tomato",         "cluster of ripe red tomatoes hanging on the vine in a sunny garden"),
    ("cucumber",       "fresh cucumbers growing on a vine with yellow flowers in the garden"),
    ("carrot",         "freshly harvested carrots with green tops on garden soil"),
    ("pepper",         "colorful red and yellow bell peppers ripening on a plant"),
    ("garlic",         "freshly harvested garlic bulbs on a rustic wooden surface"),
    ("onion",          "green onion tops growing in rows in a vegetable garden"),
    ("potato",         "freshly dug potatoes in dark garden soil"),
    ("strawberry",     "ripe red strawberries with white flowers in the garden"),
    ("pumpkin",        "big orange pumpkins on green vines in a garden"),
    ("zucchini",       "large zucchini with yellow flower growing in a garden bed"),
    ("basil",          "lush green basil herb growing in warm sunlight"),
    ("sunflower",      "tall sunflowers with bright yellow petals in a field"),
    ("compost",        "rich dark compost and fertile soil in a vegetable garden"),
    ("seedling",       "young green seedlings sprouting in a tray in early spring"),
    ("watering",       "garden being watered in the morning with drops on green leaves"),
]

# Резервный список для сегментов без ключевых слов — все разные
_POSTER_FALLBACKS: list[str] = [
    "lush vegetable garden with rows of growing plants in warm sunlight",
    "freshly harvested vegetables from the garden on rustic wooden table",
    "morning dew on green vegetable leaves in a garden bed",
    "raised vegetable garden beds with variety of growing plants",
    "ripe tomatoes and cucumbers in a summer garden",
    "garden path between vegetable beds with thriving plants",
    "close-up of green plant leaves with morning sunlight",
    "vegetable seedlings in small pots in spring garden",
    "rich dark garden soil being prepared for planting",
    "colorful mix of ripe vegetables freshly picked from garden",
    "sunflowers and vegetable garden in golden afternoon light",
    "strawberries ripening on plants in a green garden",
    "green beans and peas climbing on a garden trellis",
    "fresh herbs growing in a kitchen garden in sunlight",
    "watering vegetable garden in the morning with dew on leaves",
    "garden in full summer bloom with tall plants and flowers",
    "freshly dug root vegetables on garden soil",
    "green peas in pods on climbing vines in garden",
    "lush garden greenhouse with tomatoes and cucumbers growing",
    "cozy vegetable garden corner with wooden raised beds",
    "berry bushes with ripe fruit in a summer garden",
    "garlic and onion freshly harvested laid on garden ground",
    "pepper plants with colorful fruits in a sunny garden",
    "autumn harvest of pumpkins and squash in a garden",
    "spring garden with seedlings and fresh green growth",
    "garden close-up of soil and emerging green sprouts",
    "basil and herbs in a sunny herb garden",
    "apple tree branch with ripe fruit in an orchard",
    "garden bed with mulch and healthy vegetable plants",
    "fresh vegetables growing in a dacha garden in Russia",
]


def _dominant_subject(segments: list[dict[str, Any]]) -> str | None:
    """
    Определяет доминирующую тему видео по частоте ключевых слов
    ТОЛЬКО в сыром транскрипте (не в AI-промптах).
    AI-промпты могут содержать посторонние растения и искажать результат.
    """
    counts: dict[str, int] = {}
    for s in segments:
        # Только оригинальный текст речи — никакого prompt/queries
        text = s.get("text", "").lower()
        for kw, subj in _KEYWORD_MAP:
            if kw in text:
                counts[subj] = counts.get(subj, 0) + 1
    if not counts:
        return None
    return max(counts, key=lambda k: counts[k])


def _subject_for_segment(
    segment_text: str,
    context_text: str,
    infographic_prompt: str,
    used_subjects: set | None,
) -> str:
    """
    Выбирает subject для плаката. Приоритетная цепочка:

    1. Ключевое слово в ТЕКСТЕ РЕЧИ сегмента — самый точный источник
    2. Ключевое слово в AI-промпте инфографики этого сегмента
    3. Ключевое слово в КОНТЕКСТЕ соседних сегментов ±5
    4. Fallback из резервного списка

    Доминирующая тема (global) намеренно исключена: упоминание «клубники»
    в видео про крапиву не должно делать клубнику темой всех плакатов.
    """
    seg_lower  = segment_text.lower()
    ctx_lower  = context_text.lower()
    info_lower = infographic_prompt.lower()

    def _match_any(text: str) -> str | None:
        """Совпадение БЕЗ проверки used_subjects — для поиска по тексту сегмента."""
        for kw, subj in _KEYWORD_MAP:
            if kw in text:
                return subj
        return None

    def _match_unused(text: str) -> str | None:
        """Совпадение с проверкой used_subjects — для fallback-путей."""
        for kw, subj in _KEYWORD_MAP:
            if kw in text and (used_subjects is None or subj not in used_subjects):
                return subj
        return None

    # 1. Текст самого сегмента — АБСОЛЮТНЫЙ ПРИОРИТЕТ, без проверки used_subjects.
    #    Лучше повторить тему сегмента, чем показать несвязанное растение.
    hit = _match_any(seg_lower)
    if hit:
        return hit

    # 2. AI-промпт инфографики этого же сегмента — сгенерирован по тексту
    #    именно этого сегмента, поэтому он точнее любой глобальной темы.
    hit = _match_any(info_lower)
    if hit:
        return hit

    # 3. Контекст соседних сегментов ±5 (prefer unused)
    hit = _match_unused(ctx_lower)
    if hit:
        return hit

    # Доминирующая тема намеренно НЕ используется: в видео про крапиву
    # упоминание «клубники» как примера не должно делать клубнику темой плаката.

    # 4. Резервный fallback — красивые общие фото огорода (разные за счёт хэша)
    available = [s for s in _POSTER_FALLBACKS
                 if used_subjects is None or s not in used_subjects]
    if not available:
        available = _POSTER_FALLBACKS
    return available[hash(segment_text) % len(available)]


def _make_poster_prompt(segment_text: str, language: str,
                        used_subjects: set | None = None,
                        infographic_prompt: str = "",
                        context_text: str = "") -> str:
    """
    Генерирует плакатный промпт на основе текста сегмента.

    infographic_prompt — AI-промпт инфографики этого сегмента
    context_text       — текст соседних сегментов ±5
    used_subjects      — уже использованные subject-строки (для разнообразия)
    """
    subject = _subject_for_segment(
        segment_text=segment_text or "",
        context_text=context_text or "",
        infographic_prompt=infographic_prompt or "",
        used_subjects=used_subjects,
    )

    if used_subjects is not None:
        used_subjects.add(subject)

    return _POSTER_PROMPT_TEMPLATE.format(subject=subject, language=language)


def mix_poster_prompts(
    segments: list[dict[str, Any]],
    ratio: float = 0.35,
    language: str = "English",
) -> list[dict[str, Any]]:
    """
    Заменяет ~ratio долю инфографик плакатным промптом.
    Плакаты равномерно распределены и гарантированно не повторяются.
    """
    import math as _math

    active = [s for s in segments if s.get("show_image")]
    n_posters = max(1, _math.floor(len(active) * ratio))
    n_posters = min(n_posters, len(active))

    # Зональное распределение: каждый плакат в центре своей зоны.
    # Это гарантирует чередование инфографика↔плакат при любом ratio.
    # Пример: 5 плакатов из 15 → индексы [1, 4, 7, 10, 13]  (каждый 3-й)
    # Пример: 9 плакатов из 15 → индексы [0, 2, 4, 5, 7, 9, 10, 12, 14] (равномерно)
    poster_indices: list[int] = []
    for zone in range(n_posters):
        center = int((zone + 0.5) * len(active) / n_posters)
        center = min(center, len(active) - 1)
        if center not in poster_indices:
            poster_indices.append(center)

    used_subjects: set = set()
    poster_id_set = {id(active[i]) for i in poster_indices}

    # Строим индекс позиций сегментов для поиска соседнего контекста
    seg_positions = {id(s): i for i, s in enumerate(segments)}

    # Применяем плакатные промпты к выбранным сегментам
    converted = 0
    for s in segments:
        if s.get("show_image") and id(s) in poster_id_set:
            # Контекст: текст соседних ±5 сегментов (шире — точнее тема)
            pos = seg_positions.get(id(s), 0)
            neighbour_texts = " ".join(
                segments[j].get("text", "")
                for j in range(max(0, pos - 5), min(len(segments), pos + 6))
                if j != pos
            )
            s["prompt"]     = _make_poster_prompt(
                s.get("text", ""), language, used_subjects,
                infographic_prompt=s.get("prompt", ""),
                context_text=neighbour_texts,
            )
            s["queries"]    = [s["prompt"]]
            s["_is_poster"] = True
            converted += 1

    print(f"[poster] Подмешано {converted} плакатов из {len(active)} инфографик")
    for i, s in enumerate([s for s in segments if s.get("_is_poster")]):
        print(f"  плакат {i+1}: {s['prompt'][:80]}...")
    return segments


# ---------------------------------------------------------------------------
# Системный промпт — режиссёр огородного/садоводческого видео
# ---------------------------------------------------------------------------

_GARDEN_DIRECTOR_PROMPT = """\
You are the creative director of a professional gardening and vegetable growing video production studio.

YOUR ROLE: Analyze the transcript and select EXACTLY {n} moments that need
a visual gardening infographic to enhance understanding of the gardening concept.

TARGET AUDIENCE: Home gardeners, vegetable growers, dacha enthusiasts, farming hobbyists.

INFOGRAPHIC STYLE (follow strictly):
- Clear botanical diagrams with labeled plant parts (roots, stems, leaves, flowers, fruits)
- Growth cycle timelines showing stages from seed to harvest with dates
- Soil composition cross-section diagrams with layer labels and nutrient percentages
- Planting calendar charts (month-by-month grid, seasonal icons)
- Pest and disease identification cards with visual symptoms and treatment steps
- Companion planting diagrams (which plants grow well together, spacing guides)
- Watering and fertilization schedule charts (frequency, amounts, icons)
- Harvest yield comparison bar charts
- Step-by-step process flow diagrams (e.g., how to compost, how to graft)
- Creative freedom: you may also design seed germination timelines, raised bed layout plans,
  pH soil charts, crop rotation wheels, winter storage infographics, greenhouse temperature
  curves, pollinator attraction diagrams — any format that best communicates the gardening
  concept visually
- WHITE or very light background always
- Professional gardening color palette: earthy green (#2d6a2d), warm brown (#7a4f1e),
  sky blue (#4a90b8), sunny yellow (#e8c840), orange (#d4762a), soft beige (#f5f0e8)
- Labeled callout lines with bullet-pointed text
- Title at top, tip/note at bottom
- Style: botanical illustration meets modern infographic, clean and educational, NOT cartoon,
  NOT stock photo of real vegetables

STRICT LANGUAGE RULE:
The video is in "{language}". ALL text content inside the infographic — every label,
annotation, title, bullet point, callout text, axis label, legend entry — MUST be
written in "{language}" ONLY. Do NOT use English labels if the video is not in English.
Include this language instruction explicitly in every prompt you write.

WHAT TO SELECT (show_image: true):
- Named vegetables, fruits, herbs, berries, or flowers mentioned
- Soil preparation and amendment techniques
- Planting schedules, spacing, and depth guidelines
- Watering, feeding, and fertilization regimes
- Pest identification and organic treatment methods
- Plant diseases and prevention strategies
- Harvest timing and storage tips
- Composting and mulching practices
- Pruning, pinching, and training techniques
- Seed starting, germination, and propagation methods
- Seasonal garden tasks (spring planting, autumn prep, winter care)
- Garden bed layouts, raised beds, container gardening

WHAT TO SKIP (show_image: false):
- Greetings, introductions, channel promos
- Personal stories without gardening facts
- Transitions ("Now let's talk about...")
- Conclusions and farewells
- Generic weather chit-chat without actionable gardening advice

PROMPT REQUIREMENTS:
- Each prompt describes what to draw in detail (60-120 words)
- Specify: layout, colors, what text labels to include, what shapes/arrows/icons
- ALWAYS include: "white background", "gardening infographic", "educational", "labeled diagram"
- ALWAYS end every prompt with: "All text labels and annotations in {language}."
- Be specific enough that an AI image generator can create the exact infographic

DISTRIBUTION RULE:
The video is divided into {n} equal time zones. Select exactly ONE segment per zone.
DO NOT cluster selections at the beginning — spread them across the full video.

CRITICAL: Return ONLY valid JSON array, one object per segment, same order as input.
No markdown, no explanation. Exactly {n} objects must have show_image: true.

Format:
[
  {{"show_image": false, "prompt": ""}},
  {{"show_image": true, "prompt": "White background gardening infographic showing tomato growth stages from seed to harvest...All text labels and annotations in {language}."}},
  ...
]
"""


# ---------------------------------------------------------------------------
# Парсинг JSON из ответа AI
# ---------------------------------------------------------------------------

def _parse_ai_json(raw: str, n_segments: int, n_infographics: int) -> list[dict[str, Any]] | None:
    """Надёжный парсинг JSON-ответа от любого AI."""
    try:
        start = raw.find("[")
        end   = raw.rfind("]") + 1
        if start != -1 and end > start:
            raw = raw[start:end]
        elif raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
            raw = raw.strip()

        raw = re.sub(r",\s*([}\]])", r"\1", raw)

        try:
            result: list[dict[str, Any]] = json.loads(raw)
        except json.JSONDecodeError:
            last_brace = raw.rfind("}")
            if last_brace != -1:
                raw = raw[:last_brace + 1] + "]"
                raw = re.sub(r",\s*([}\]])", r"\1", raw)
            result = json.loads(raw)

        if len(result) > n_segments:
            result = result[:n_segments]
        while len(result) < n_segments:
            result.append({"show_image": False, "prompt": ""})

        shown = sum(1 for r in result if r.get("show_image"))
        print(f"[director] AI выбрал {shown} инфографик (запрошено {n_infographics})")
        return result

    except Exception as exc:
        print(f"[director] Ошибка парсинга JSON: {exc}")
        return None


# ---------------------------------------------------------------------------
# Gemini-режиссёр
# ---------------------------------------------------------------------------

def _call_gemini_director(
    segments: list[dict[str, Any]],
    n_infographics: int,
    language: str = "English",
) -> list[dict[str, Any]] | None:
    """Gemini анализирует транскрипт и создаёт огородный storyboard."""
    import config as cfg
    if not cfg.GEMINI_API_KEY:
        print("[director] Нет GEMINI_API_KEY!")
        return None

    from google import genai
    from google.genai import types

    transcript_lines = [
        f"[{i}] [{_fmt_time(seg['start'])}] {(seg['text'] or '')[:200]}"
        for i, seg in enumerate(segments)
    ]
    system = _GARDEN_DIRECTOR_PROMPT.format(n=n_infographics, language=language)
    prompt = f"{system}\n\nTranscript ({len(segments)} segments):\n\n" + "\n".join(transcript_lines)

    client = genai.Client(api_key=cfg.GEMINI_API_KEY)

    for attempt in range(cfg.GPT_MAX_RETRIES + 1):
        try:
            print(f"[director] Gemini API вызов (попытка {attempt+1})...")
            response = client.models.generate_content(
                model=cfg.GEMINI_MODEL,
                contents=prompt,
                config=types.GenerateContentConfig(
                    temperature=0.1,
                    max_output_tokens=8192,
                ),
            )
            raw = response.text.strip()
            result = _parse_ai_json(raw, len(segments), n_infographics)
            if result:
                return result
            if attempt < cfg.GPT_MAX_RETRIES:
                time.sleep(2)
        except Exception as exc:
            print(f"[director] Gemini ошибка (попытка {attempt+1}): {exc}")
            if attempt < cfg.GPT_MAX_RETRIES:
                time.sleep(3)

    return None


# ---------------------------------------------------------------------------
# ChatGPT-режиссёр
# ---------------------------------------------------------------------------

def _call_chatgpt_director(
    segments: list[dict[str, Any]],
    n_infographics: int,
    language: str = "English",
) -> list[dict[str, Any]] | None:
    """ChatGPT (OpenAI) анализирует транскрипт и создаёт огородный storyboard.
    Работает как с обычным API-ключом (sk-...), так и с OAuth access_token от Codex."""
    import config as cfg
    token = cfg.OPENAI_API_KEY
    if not token:
        print("[director] Нет OPENAI_API_KEY / OAuth-токена!")
        return None

    try:
        from openai import OpenAI
    except ImportError:
        print("[director] openai не установлен. Запустите: pip install openai")
        return None

    transcript_lines = [
        f"[{i}] [{_fmt_time(seg['start'])}] {(seg['text'] or '')[:200]}"
        for i, seg in enumerate(segments)
    ]
    system_msg = _GARDEN_DIRECTOR_PROMPT.format(n=n_infographics, language=language)
    user_msg   = f"Transcript ({len(segments)} segments):\n\n" + "\n".join(transcript_lines)

    # OpenAI SDK принимает Bearer-токен (OAuth) и sk-ключ одинаково через api_key
    client = OpenAI(api_key=token)
    is_oauth = not token.startswith("sk-")
    if is_oauth:
        print("[director] Режим: OAuth access_token (Codex)")
    preferred = cfg.OPENAI_MODEL or "gpt-4o-mini"

    # ── Шаг 1: узнаём, какие модели реально доступны для этого ключа/проекта ──
    try:
        all_models = [m.id for m in client.models.list()]
        # Фильтруем chat-capable GPT-модели
        chat_keywords = ("gpt-4o", "gpt-4", "gpt-3.5", "o1", "o3", "chatgpt")
        available = [m for m in all_models if any(k in m.lower() for k in chat_keywords)]
        # Ставим выбранную модель первой
        if preferred in available:
            available = [preferred] + [m for m in available if m != preferred]
        elif preferred not in available:
            available = [preferred] + available  # попробуем всё равно
        if available:
            print(f"[director] Доступные модели OpenAI: {', '.join(available[:6])}")
        else:
            print(f"[director] models.list() не вернул GPT-моделей — пробуем стандартный список")
            if is_oauth:
                available = [preferred, "gpt-4o", "gpt-4o-mini", "gpt-3.5-turbo", "gpt-4-turbo"]
            else:
                available = [preferred, "gpt-4o-mini", "gpt-4o", "gpt-3.5-turbo", "gpt-4-turbo"]
    except Exception as exc:
        print(f"[director] Не удалось получить список моделей: {exc}")
        if is_oauth:
            available = [preferred, "gpt-4o", "gpt-4o-mini", "gpt-3.5-turbo", "gpt-4-turbo"]
        else:
            available = [preferred, "gpt-4o-mini", "gpt-4o", "gpt-3.5-turbo", "gpt-4-turbo"]

    # ── Шаг 2: пробуем модели по очереди ─────────────────────────────────────
    for model in available:
        for attempt in range(cfg.GPT_MAX_RETRIES + 1):
            try:
                print(f"[director] ChatGPT API вызов (модель={model}, попытка {attempt+1})...")
                response = client.chat.completions.create(
                    model=model,
                    messages=[
                        {"role": "system", "content": system_msg},
                        {"role": "user",   "content": user_msg},
                    ],
                    temperature=0.1,
                    max_tokens=8192,
                )
                raw = (response.choices[0].message.content or "").strip()
                result = _parse_ai_json(raw, len(segments), n_infographics)
                if result:
                    print(f"[director] ChatGPT успех — модель: {model}")
                    return result
                if attempt < cfg.GPT_MAX_RETRIES:
                    time.sleep(2)
            except Exception as exc:
                err_str = str(exc)
                print(f"[director] ChatGPT ошибка (попытка {attempt+1}): {exc}")
                # Сразу переходим к следующей модели при ошибках доступа или сервера
                skip_immediately = (
                    ("403" in err_str and "model_not_found" in err_str)
                    or "500" in err_str
                    or ("404" in err_str and "model" in err_str.lower())
                )
                if skip_immediately:
                    print(f"[director] Модель {model} недоступна/ошибка сервера, пробую следующую...")
                    break   # переходим к следующей модели
                if attempt < cfg.GPT_MAX_RETRIES:
                    time.sleep(3)
        else:
            continue
        continue   # break из внутреннего цикла — продолжаем внешний

    print()
    print("[director] ⚠ ChatGPT: ни одна модель не сработала.")
    if is_oauth:
        print("[director]   Причина: OAuth-токен от chatgpt.com НЕ работает с OpenAI developer API.")
        print("[director]   Для работы через API нужен обычный ключ: platform.openai.com → API keys.")
        print("[director]   Токен chatgpt.com можно использовать только через интерфейс ChatGPT.")
    else:
        print("[director]   Вероятная причина: Project API key ограничивает доступ к моделям.")
        print("[director]   Решение: замените ключ на Organization key (начинается с sk-, не sk-proj-).")
        print("[director]   Или откройте platform.openai.com → Settings → Project → Models.")
    print()
    return None


# ---------------------------------------------------------------------------
# Claude-режиссёр (Anthropic)
# ---------------------------------------------------------------------------

def _call_claude_director(
    segments: list[dict[str, Any]],
    n_infographics: int,
    language: str = "English",
) -> list[dict[str, Any]] | None:
    """Claude анализирует транскрипт и создаёт огородный storyboard.
    Работает с OAuth access_token от claude.ai или обычным API-ключом (sk-ant-...)."""
    import config as cfg
    token = cfg.CLAUDE_ACCESS_TOKEN
    if not token:
        print("[director] Нет CLAUDE_ACCESS_TOKEN!")
        return None

    try:
        import anthropic
    except ImportError:
        print("[director] anthropic не установлен. Запустите: pip install anthropic")
        return None

    transcript_lines = [
        f"[{i}] [{_fmt_time(seg['start'])}] {(seg['text'] or '')[:200]}"
        for i, seg in enumerate(segments)
    ]
    system_msg = _GARDEN_DIRECTOR_PROMPT.format(n=n_infographics, language=language)
    user_msg   = f"Transcript ({len(segments)} segments):\n\n" + "\n".join(transcript_lines)

    model    = getattr(cfg, "CLAUDE_MODEL", None) or "claude-sonnet-4-5"
    is_oauth = not token.startswith("sk-ant-")

    for attempt in range(3):
        try:
            print(f"[director] Claude API вызов (модель={model}, попытка {attempt+1}, oauth={is_oauth})...")
            if is_oauth:
                # OAuth access_token: прямой HTTP с anthropic-beta заголовком
                import requests as _r
                headers = {
                    "Authorization":     f"Bearer {token}",
                    "anthropic-version": "2023-06-01",
                    "anthropic-beta":    "oauth-2025-04-20",
                    "Content-Type":      "application/json",
                }
                body = {
                    "model":      model,
                    "max_tokens": 8192,
                    "temperature": 0.1,
                    "system":     system_msg,
                    "messages":   [{"role": "user", "content": user_msg}],
                }
                resp = _r.post(
                    "https://api.anthropic.com/v1/messages",
                    headers=headers, json=body, timeout=120,
                )
                if resp.status_code != 200:
                    raise RuntimeError(f"Claude API {resp.status_code}: {resp.text[:200]}")
                raw = resp.json()["content"][0]["text"].strip()
            else:
                # Обычный API-ключ через SDK
                client = anthropic.Anthropic(api_key=token)
                response = client.messages.create(
                    model=model, max_tokens=8192, temperature=0.1,
                    system=system_msg,
                    messages=[{"role": "user", "content": user_msg}],
                )
                raw = (response.content[0].text or "").strip()

            result = _parse_ai_json(raw, len(segments), n_infographics)
            if result:
                print(f"[director] Claude успех — модель: {model}")
                return result
            if attempt < 2:
                time.sleep(2)
        except Exception as exc:
            print(f"[director] Claude ошибка (попытка {attempt+1}): {exc}")
            if attempt < 2:
                time.sleep(3)

    print("[director] ⚠ Claude: все попытки исчерпаны.")
    return None


# ---------------------------------------------------------------------------
# Равномерное распределение инфографик
# ---------------------------------------------------------------------------

def _enforce_even_distribution(
    segments: list[dict[str, Any]],
    n_infographics: int,
    language: str = "English",
) -> list[dict[str, Any]]:
    """Гарантирует равномерное распределение n_infographics по видео."""
    if not segments or n_infographics <= 0:
        return segments

    duration = max(s.get("end", 0.0) for s in segments)
    if duration <= 0:
        return segments

    zone_size = duration / n_infographics
    for i, s in enumerate(segments):
        s["_idx"] = i

    chosen_indices: list[int] = []

    for zone_i in range(n_infographics):
        z_start  = zone_i * zone_size
        z_end    = (zone_i + 1) * zone_size
        z_center = (z_start + z_end) / 2.0

        in_zone = [s for s in segments if s.get("start", 0.0) < z_end and s.get("end", 0.0) > z_start]
        if not in_zone:
            in_zone = [s for s in segments if s["_idx"] not in chosen_indices]
            if not in_zone:
                in_zone = segments

        def _dist(seg: dict[str, Any]) -> float:
            mid = (seg.get("start", 0.0) + seg.get("end", 0.0)) / 2.0
            return abs(mid - z_center)

        selected   = [s for s in in_zone if s.get("show_image") and s["_idx"] not in chosen_indices]
        unselected = [s for s in in_zone if not s.get("show_image") and s["_idx"] not in chosen_indices]

        if selected:
            best = min(selected, key=_dist)
        elif unselected:
            best = min(unselected, key=_dist)
        else:
            not_chosen = [s for s in segments if s["_idx"] not in chosen_indices]
            if not not_chosen:
                break
            best = min(not_chosen, key=_dist)

        chosen_indices.append(best["_idx"])

    chosen_set = set(chosen_indices)
    for s in segments:
        if s["_idx"] in chosen_set:
            s["show_image"] = True
            if not s.get("prompt"):
                text = (s.get("text") or "").strip()
                s["prompt"] = (
                    f"White background gardening infographic illustrating: {text[:150]}. "
                    f"Educational labeled diagram, natural gardening colors (greens and browns). "
                    f"All text labels and annotations in {language}."
                ) if text else (
                    f"White background gardening infographic. Educational labeled diagram, "
                    f"natural gardening colors. All text labels and annotations in {language}."
                )
                s["queries"] = [s["prompt"]]
        else:
            s["show_image"] = False

    for s in segments:
        s.pop("_idx", None)

    print(f"[director] Распределено: {len(chosen_set)} инфографик по {n_infographics} зонам.")
    return segments


# ---------------------------------------------------------------------------
# Главная функция
# ---------------------------------------------------------------------------

def extract_keywords(
    segments: list[dict[str, Any]],
    n_infographics: int = 15,
    language: str = "English",
    ai_backend: str | None = None,
) -> list[dict[str, Any]]:
    """
    AI-режиссёр анализирует транскрипт и создаёт огородный storyboard.

    Args:
        segments:       сегменты транскрипта.
        n_infographics: количество инфографик.
        language:       язык видео.
        ai_backend:     "gemini" или "chatgpt" (если None — берётся из config).

    Returns:
        Сегменты с полями show_image, prompt, queries.
    """
    if not segments:
        return segments

    import config as cfg

    # Выбор бэкенда
    backend = (ai_backend or cfg.AI_BACKEND or "gemini").lower()

    # Разбиваем длинные сегменты пока не наберём нужное количество
    segs = [dict(s) for s in segments]
    while len(segs) < n_infographics:
        longest = max(segs, key=lambda s: s["end"] - s["start"])
        mid = (longest["start"] + longest["end"]) / 2.0
        idx = segs.index(longest)
        segs[idx:idx+1] = [
            {**longest, "end": mid},
            {**longest, "start": mid},
        ]
    segments = segs

    print(f"[director] Бэкенд: {backend.upper()} | Сегментов: {len(segments)} | Инфографик: {n_infographics} | Язык: {language}")

    # Авто-режим: пропускаем AI, сразу равномерное распределение
    if backend == "auto":
        print("[director] Авто-режим: AI не используется, генерируем промпты из текста.")
        result = _enforce_even_distribution(segments, n_infographics, language=language)
        shown_final = sum(1 for s in result if s["show_image"])
        print(f"[director] Итого: {shown_final} инфографик.")
        import config as _cfg_auto
        if getattr(_cfg_auto, "POSTER_MIX", False):
            ratio = float(getattr(_cfg_auto, "POSTER_RATIO", 0.35))
            result = mix_poster_prompts(result, ratio=ratio, language=language)
        return result

    # Вызов нужного AI
    if backend == "claude":
        decisions = _call_claude_director(segments, n_infographics, language=language)
        if decisions is None:
            print("[director] Claude недоступен, переключаюсь на Gemini...")
            decisions = _call_gemini_director(segments, n_infographics, language=language)
            if decisions is None:
                print("[director] Gemini недоступен, пробую ChatGPT...")
                decisions = _call_chatgpt_director(segments, n_infographics, language=language)
    elif backend == "chatgpt":
        decisions = _call_chatgpt_director(segments, n_infographics, language=language)
        if decisions is None:
            print("[director] ChatGPT недоступен (OAuth-токен chatgpt.com не совместим с developer API).")
            # Пробуем Claude если есть токен
            import config as _cfg_fb
            if getattr(_cfg_fb, "CLAUDE_ACCESS_TOKEN", ""):
                print("[director] Переключаюсь на Claude...")
                decisions = _call_claude_director(segments, n_infographics, language=language)
                if decisions is None:
                    print("[director] Claude тоже недоступен, пробую Gemini...")
                    decisions = _call_gemini_director(segments, n_infographics, language=language)
            else:
                print("[director] Нет CLAUDE_ACCESS_TOKEN, переключаюсь на Gemini...")
                decisions = _call_gemini_director(segments, n_infographics, language=language)
    else:
        decisions = _call_gemini_director(segments, n_infographics, language=language)

    # Применяем решения к сегментам
    result: list[dict[str, Any]] = []
    for i, seg in enumerate(segments):
        enriched = dict(seg)
        if decisions is None or i >= len(decisions):
            enriched.update(show_image=False, prompt="", queries=[])
        else:
            d = decisions[i]
            enriched["show_image"] = bool(d.get("show_image", False))
            enriched["prompt"]     = str(d.get("prompt", "")).strip()
            enriched["queries"]    = [enriched["prompt"]] if enriched["prompt"] else []
        result.append(enriched)

    shown = sum(1 for s in result if s["show_image"])
    print(f"[director] Storyboard: {shown}/{len(result)} инфографик назначено.")

    # Равномерное распределение
    result = _enforce_even_distribution(result, n_infographics, language=language)

    shown_final = sum(1 for s in result if s["show_image"])
    print(f"[director] Итого: {shown_final} инфографик.")

    # Применяем кастомные промпты если заданы
    if _custom_prompts:
        shown_segs = [s for s in result if s.get("show_image")]
        injected = 0
        for i, seg in enumerate(shown_segs):
            if i < len(_custom_prompts):
                seg["prompt"]  = _custom_prompts[i]
                seg["queries"] = [seg["prompt"]]
                injected += 1
        print(f"[director] Custom prompts: {injected}/{len(shown_segs)}")

    # Подмешиваем плакаты если включено
    import config as _cfg_mix
    if getattr(_cfg_mix, "POSTER_MIX", False):
        ratio = float(getattr(_cfg_mix, "POSTER_RATIO", 0.35))
        result = mix_poster_prompts(result, ratio=ratio, language=language)

    return result
