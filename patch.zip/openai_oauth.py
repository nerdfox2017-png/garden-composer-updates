"""
openai_oauth.py — PKCE OAuth для OpenAI Codex CLI.

Использует тот же client_id и redirect_uri что и официальный Codex CLI.
Поток:
  1. Генерируем code_verifier + code_challenge (SHA-256 base64url)
  2. Открываем браузер на auth.openai.com/oauth/authorize
  3. Слушаем localhost:1455/auth/callback
  4. Меняем code на access_token + refresh_token
  5. Возвращаем токены вызывающему коду
"""

import base64
import hashlib
import json
import secrets
import threading
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Callable

# ── Константы Codex CLI ──────────────────────────────────────────────────────
CLIENT_ID    = "app_EMoamEEZ73f0CkXaXp7hrann"
REDIRECT_URI = "http://localhost:1455/auth/callback"
SCOPES       = "openid profile email offline_access api.connectors.read api.connectors.invoke"
AUTH_URL     = "https://auth.openai.com/oauth/authorize"
TOKEN_URL    = "https://auth.openai.com/oauth/token"
PORT         = 1455


# ── PKCE-утилиты ─────────────────────────────────────────────────────────────

def _gen_code_verifier() -> str:
    """Случайный code_verifier (96 байт → 128 URL-safe символов)."""
    return secrets.token_urlsafe(96)


def _code_challenge(verifier: str) -> str:
    """SHA-256(verifier) → base64url без padding."""
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")


def build_auth_url(verifier: str, state: str) -> str:
    params = {
        "response_type":              "code",
        "client_id":                  CLIENT_ID,
        "redirect_uri":               REDIRECT_URI,
        "scope":                      SCOPES,
        "code_challenge":             _code_challenge(verifier),
        "code_challenge_method":      "S256",
        "id_token_add_organizations": "true",
        "codex_cli_simplified_flow":  "true",
        "originator":                 "codex_cli_rs",
        "state":                      state,
    }
    return AUTH_URL + "?" + urllib.parse.urlencode(params)


# ── Локальный callback-сервер ─────────────────────────────────────────────────

class _CallbackHandler(BaseHTTPRequestHandler):
    """Обрабатывает один GET /auth/callback?code=...&state=..."""

    on_success: Callable[[str, str], None] | None = None   # (code, state)
    on_error:   Callable[[str], None]       | None = None

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path != "/auth/callback":
            self._respond(404, "Not found")
            return

        qs = urllib.parse.parse_qs(parsed.query)
        code  = (qs.get("code")  or [""])[0]
        state = (qs.get("state") or [""])[0]
        error = (qs.get("error") or [""])[0]

        if error:
            self._respond(400, f"Ошибка авторизации: {error}")
            if self.on_error:
                self.on_error(error)
        elif code:
            self._respond(200,
                "✓ Авторизация успешна! Можно закрыть это окно и вернуться в приложение.")
            if self.on_success:
                self.on_success(code, state)
        else:
            self._respond(400, "Нет кода авторизации.")
            if self.on_error:
                self.on_error("no_code")

    def _respond(self, status: int, body: str):
        page = f"""<!DOCTYPE html><html><head>
<meta charset="utf-8">
<style>body{{font-family:sans-serif;display:flex;align-items:center;
justify-content:center;height:100vh;background:#111;color:#eee;margin:0}}
h2{{font-size:1.4rem}}.ok{{color:#2ecc71}}.err{{color:#e74c3c}}</style></head>
<body><div style="text-align:center">
<h2 class="{'ok' if status==200 else 'err'}">{body}</h2>
</div></body></html>"""
        data = page.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *_):
        pass   # подавляем стандартный лог


# ── Обмен code → token ───────────────────────────────────────────────────────

def exchange_code(code: str, verifier: str) -> dict:
    """
    POST /oauth/token.
    Возвращает dict с полями: access_token, refresh_token, id_token, ...
    Бросает исключение при ошибке.
    """
    import requests as _req

    # Пробуем JSON и form-encoded — разные серверы предпочитают разное
    last_err = ""
    for ct, kw in [
        ("application/json",                  {"json":  {"grant_type": "authorization_code",
                                                          "client_id": CLIENT_ID,
                                                          "code": code,
                                                          "redirect_uri": REDIRECT_URI,
                                                          "code_verifier": verifier}}),
        ("application/x-www-form-urlencoded", {"data":  {"grant_type": "authorization_code",
                                                          "client_id": CLIENT_ID,
                                                          "code": code,
                                                          "redirect_uri": REDIRECT_URI,
                                                          "code_verifier": verifier}}),
    ]:
        try:
            resp = _req.post(TOKEN_URL, headers={"Content-Type": ct}, timeout=15, **kw)
            print(f"[openai_oauth] token [{ct[:16]}] → {resp.status_code}: {resp.text[:120]}")
            if resp.status_code == 200:
                try:
                    return resp.json()
                except Exception:
                    raise RuntimeError(f"Сервер вернул не-JSON: {resp.text[:300]}")
            # Пробуем распарсить тело как JSON для понятного сообщения об ошибке
            try:
                err_body = resp.json()
                err_msg  = (err_body.get("error_description")
                            or err_body.get("error")
                            or err_body.get("message")
                            or str(err_body))
            except Exception:
                err_msg = resp.text[:200] or f"HTTP {resp.status_code}"
            last_err = err_msg
        except RuntimeError:
            raise
        except Exception as exc:
            last_err = str(exc)

    raise RuntimeError(last_err)


def refresh_access_token(refresh_token: str) -> dict:
    """Обновляет access_token через refresh_token."""
    import requests as _req
    resp = _req.post(
        TOKEN_URL,
        headers={"Content-Type": "application/json"},
        json={
            "grant_type":    "refresh_token",
            "client_id":     CLIENT_ID,
            "refresh_token": refresh_token,
        },
        timeout=15,
    )
    if resp.status_code != 200:
        raise RuntimeError(f"Token refresh failed {resp.status_code}: {resp.text[:300]}")
    return resp.json()


def get_user_info(access_token: str) -> dict:
    """Получает профиль пользователя (email, name). Никогда не бросает исключений."""
    import requests as _req
    try:
        resp = _req.get(
            "https://auth.openai.com/userinfo",
            headers={"Authorization": f"Bearer {access_token}"},
            timeout=8,
        )
        if resp.status_code == 200:
            try:
                return resp.json()
            except Exception:
                pass  # сервер вернул HTML (аккаунт забанен и т.д.)
    except Exception:
        pass
    return {}


# ── Главная функция ──────────────────────────────────────────────────────────

def start_oauth(
    on_tokens: Callable[[dict], None],
    on_error:  Callable[[str], None],
):
    """
    Запускает полный PKCE-поток в фоновом потоке:
      1. Генерирует verifier/state
      2. Открывает браузер
      3. Запускает HTTP-сервер на порту 1455
      4. При получении code — обменивает на токен и вызывает on_tokens(token_dict)
    on_tokens и on_error вызываются из фонового потока — используй after() в UI.
    """
    verifier = _gen_code_verifier()
    state    = secrets.token_urlsafe(32)
    url      = build_auth_url(verifier, state)

    result_event = threading.Event()

    class _Handler(_CallbackHandler):
        pass

    def _success(code: str, returned_state: str):
        if returned_state != state:
            on_error("state_mismatch")
            result_event.set()
            return
        try:
            tokens = exchange_code(code, verifier)
            on_tokens(tokens)
        except Exception as exc:
            on_error(str(exc))
        finally:
            result_event.set()

    def _err(msg: str):
        on_error(msg)
        result_event.set()

    _Handler.on_success = staticmethod(_success)
    _Handler.on_error   = staticmethod(_err)

    def _serve():
        try:
            server = HTTPServer(("127.0.0.1", PORT), _Handler)
            server.timeout = 1.0
            # Ждём callback максимум 3 минуты
            deadline = 180
            elapsed  = 0
            while not result_event.is_set() and elapsed < deadline:
                server.handle_request()
                elapsed += 1
            server.server_close()
        except OSError as exc:
            on_error(f"Порт {PORT} занят: {exc}")

    threading.Thread(target=_serve, daemon=True).start()
    webbrowser.open(url)
