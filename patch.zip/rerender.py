"""rerender.py — повторный рендер для упавших сегментов."""
import json
import os
import sys
from typing import Any

from config import CACHE_DIR
from compositor import compose
from image_fetcher import fetch_image
from utils import log_exception, sanitize_filename, setup_logger

logger = setup_logger(__name__)


def rerender(input_path: str, output_path: str, quality: str = "720fast") -> None:
    base  = os.path.splitext(os.path.basename(input_path))[0]
    sb_path = os.path.join(CACHE_DIR, f"{base}_storyboard.json")

    if not os.path.isfile(sb_path):
        print(f"No storyboard found: {sb_path}")
        return

    with open(sb_path, encoding="utf-8") as f:
        segments = json.load(f)

    failed = [s for s in segments if s.get("show_image") and not (
        s.get("image_path") and os.path.isfile(str(s.get("image_path", "")))
    )]
    print(f"[rerender] Failed segments: {len(failed)}")

    for seg in failed:
        prompt    = seg.get("prompt", "")
        cache_key = f"gen_{sanitize_filename(prompt)[:80]}"
        path = fetch_image(prompt, "generate", "NARWHAL", cache_key)
        if path:
            seg["image_path"] = path
            print(f"  OK: {path}")
        else:
            print(f"  FAIL: {prompt[:60]}")

    with open(sb_path, "w", encoding="utf-8") as f:
        json.dump(segments, f, ensure_ascii=False, indent=2)

    compose(input_path, segments, output_path, quality=quality)
    print(f"[rerender] Done: {output_path}")
