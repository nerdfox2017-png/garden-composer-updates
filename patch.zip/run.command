#!/bin/bash
# ============================================================
#  Garden Infographic Composer — Запуск на macOS
#  Двойной клик по этому файлу открывает программу.
# ============================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Добавляем Homebrew в PATH (Apple Silicon и Intel)
if [ -f "/opt/homebrew/bin/brew" ]; then
    eval "$(/opt/homebrew/bin/brew shellenv)"
elif [ -f "/usr/local/bin/brew" ]; then
    eval "$(/usr/local/bin/brew shellenv)"
fi

# ── Если venv не создан — запускаем установку автоматически ──────────────
if [ ! -d "venv" ]; then
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  Первый запуск — устанавливаем зависимости..."
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    bash install.sh
    if [ $? -ne 0 ]; then
        echo ""
        echo "Установка завершилась с ошибкой. Нажмите Enter для закрытия..."
        read
        exit 1
    fi
fi

# ── Активируем venv ───────────────────────────────────────────────────────
source venv/bin/activate

# ── Проверяем tkinter (критическая зависимость) ───────────────────────────
if ! python3 -c "import tkinter" 2>/dev/null; then
    echo "⚠ tkinter не найден — venv создан проблемным Python (3.14?)."
    echo "  Пересоздаём окружение с правильным Python..."
    deactivate 2>/dev/null || true
    rm -rf venv
    bash install.sh
    if [ $? -ne 0 ]; then
        echo ""
        echo "Установка завершилась с ошибкой. Нажмите Enter для закрытия..."
        read
        exit 1
    fi
    source venv/bin/activate
fi

# ── Быстрая проверка customtkinter ───────────────────────────────────────
if ! python3 -c "import customtkinter" 2>/dev/null; then
    echo "customtkinter не найден, устанавливаем..."
    python3 -m pip install customtkinter --quiet
fi

# ── Запуск ────────────────────────────────────────────────────────────────
echo "🌱 Запускаем Garden Infographic Composer..."
python3 app.py

if [ $? -ne 0 ]; then
    echo ""
    echo "Программа завершилась с ошибкой."
    echo "Нажмите Enter для закрытия..."
    read
fi
