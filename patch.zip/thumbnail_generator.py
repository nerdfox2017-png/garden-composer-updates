"""
thumbnail_generator.py — генерация превью в огородном стиле.
Совместим с macOS, Windows и Linux.
"""

import os, json, re, subprocess, tempfile
from concurrent.futures import ThreadPoolExecutor, TimeoutError as _FuturesTimeout
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
import sys as _sys

ROOT = (os.path.dirname(_sys.executable)
        if getattr(_sys, "frozen", False)
        else os.path.dirname(os.path.abspath(__file__)))


# ─────────────────────────────────────────────────────────────────────────────
def generate_thumbnails(
    video_path: str,
    ref_images: list[str],
    n: int = 5,
    gemini_key: str = "",
    asm_key: str = "",
    lang: str | None = None,
    cached_transcript: str | None = None,
    status_cb=None,
) -> list[str]:
    def status(msg):
        if status_cb:
            status_cb(msg)

    out_dir = os.path.join(ROOT, "output", "thumbnails")
    os.makedirs(out_dir, exist_ok=True)

    if cached_transcript and cached_transcript.strip():
        status("Используем кэш транскрипта  ✓")
        transcript_text = cached_transcript.strip()
    else:
        status("Получаем транскрипт...")
        transcript_text = _get_transcript(video_path, asm_key)
        if not transcript_text:
            status("Транскрипт не найден — используем имя файла")
            transcript_text = os.path.splitext(os.path.basename(video_path))[0]

    status("Gemini генерирует подписи из транскрипта...")
    captions = _get_viral_captions(
        transcript=transcript_text, n=n, lang=lang,
        gemini_key=gemini_key, ref_images=ref_images,
    )
    if not captions:
        status("Gemini не ответил — используем тему из транскрипта")
        words = transcript_text.split()[:6]
        captions = [" ".join(words)] * n
    status(f"Подписи готовы: {len(captions)}")

    status("Извлекаем кадры из видео...")
    frames = _extract_frames(video_path, n)

    ref_style = _analyze_ref_style(ref_images)

    saved = []
    for i, caption in enumerate(captions[:n]):
        status(f"Рендеринг {i+1}/{n}: {caption[:50]}...")
        frame = frames[i % len(frames)] if frames else None
        path = _render_thumbnail(
            frame_path=frame, caption=caption, index=i,
            out_dir=out_dir, ref_style=ref_style,
        )
        saved.append(path)

    status(f"Готово!  {len(saved)} превью → output/thumbnails/")
    return saved


# ─────────────────────────────────────────────────────────────────────────────
def _get_transcript(video_path: str, asm_key: str) -> str:
    base  = os.path.splitext(os.path.basename(video_path))[0]
    cache = os.path.join(ROOT, "cache", f"{base}_transcript.json")
    if os.path.isfile(cache):
        try:
            with open(cache, encoding="utf-8") as f:
                data = json.load(f)
            text = " ".join(s.get("text", "") for s in data if s.get("text"))
            if text.strip():
                return text[:6000]
        except Exception:
            pass
    if not asm_key:
        return ""
    try:
        import assemblyai as aai
        aai.settings.api_key = asm_key
        result = aai.Transcriber().transcribe(video_path)
        return (result.text or "")[:6000]
    except Exception:
        return ""


# ─────────────────────────────────────────────────────────────────────────────
def _get_viral_captions(
    transcript: str, n: int, lang: str | None,
    gemini_key: str, ref_images: list[str] | None = None,
) -> list[str]:
    if not gemini_key:
        return []

    from google import genai
    from google.genai import types
    client   = genai.Client(api_key=gemini_key)
    lang_str = lang or "the same language as the transcript"
    contents: list = []

    if ref_images:
        contents.append(
            "These are REFERENCE thumbnails. Study style, energy, hooks. "
            "DO NOT copy text — only understand the tone.")
        for p in (ref_images or [])[:5]:
            try:
                ext  = os.path.splitext(p)[1].lower()
                mime = "image/jpeg" if ext in (".jpg", ".jpeg") else "image/png"
                with open(p, "rb") as f:
                    img_bytes = f.read()
                contents.append(types.Part.from_bytes(data=img_bytes, mime_type=mime))
            except Exception as e:
                print(f"[thumbnail] ref image error: {e}")

    text_prompt = f"""You are a viral YouTube thumbnail copywriter for gardening/vegetable growing content.

VIDEO TRANSCRIPT:
\"\"\"
{transcript[:4000]}
\"\"\"

Generate exactly {n} short, punchy thumbnail captions in {lang_str}.
Rules: MAX 6 words each, viral hooks (shocking fact, number, question, bold claim),
based ONLY on transcript, no hashtags/emoji, language: {lang_str} ONLY.
Return ONLY valid JSON array of {n} strings.

Example: ["5 ОШИБОК ПРИ ПОСАДКЕ ТОМАТОВ", "ВОТ ПОЧЕМУ ОГУРЦЫ НЕ РАСТУТ", "УРОЖАЙ В 3 РАЗА БОЛЬШЕ"]
"""
    contents.append(text_prompt)

    def _do_gemini():
        return client.models.generate_content(
            model="gemini-2.0-flash", contents=contents,
            config=types.GenerateContentConfig(temperature=0.95, max_output_tokens=800),
        )

    try:
        with ThreadPoolExecutor(max_workers=1) as ex:
            future = ex.submit(_do_gemini)
            try:
                response = future.result(timeout=45)
            except _FuturesTimeout:
                return []
        raw   = response.text.strip()
        start = raw.find("["); end = raw.rfind("]") + 1
        if start != -1 and end > start:
            data = json.loads(raw[start:end])
            if isinstance(data, list) and data:
                return [str(c).strip() for c in data if str(c).strip()][:n]
    except Exception as exc:
        print(f"[thumbnail] Gemini error: {exc}")
    return []


# ─────────────────────────────────────────────────────────────────────────────
def _extract_frames(video_path: str, n: int) -> list[str]:
    frames = []
    try:
        result = subprocess.run(
            ["ffprobe", "-v", "quiet", "-print_format", "json", "-show_format", video_path],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=15)
        dur = float(json.loads(result.stdout)["format"]["duration"])
    except Exception:
        dur = 60.0

    tmp = tempfile.mkdtemp()
    for i in range(n):
        t   = dur * (i + 0.5) / n
        out = os.path.join(tmp, f"frame_{i:02d}.jpg")
        try:
            subprocess.run(
                ["ffmpeg", "-y", "-ss", str(t), "-i", video_path,
                 "-vframes", "1", "-q:v", "2", out],
                capture_output=True, timeout=15)
            if os.path.isfile(out):
                frames.append(out)
        except Exception:
            pass
    return frames


# ─────────────────────────────────────────────────────────────────────────────
def _analyze_ref_style(ref_images: list[str]) -> dict:
    style = {"accent": (45, 106, 45), "bg_dark": (10, 25, 10), "bg_mid": (20, 50, 20)}
    if not ref_images:
        return style
    all_pixels: list = []
    for rp in ref_images[:4]:
        try:
            img = Image.open(rp).convert("RGB")
            img.thumbnail((160, 90), Image.LANCZOS)
            all_pixels.extend(list(img.getdata()))
        except Exception:
            pass
    if not all_pixels:
        return style
    try:
        max_sat = 0.0
        for pr, pg, pb in all_pixels:
            mx = max(pr, pg, pb); mn = min(pr, pg, pb)
            sat = (mx - mn) / max(mx, 1)
            if sat > max_sat and mx > 100:
                max_sat = sat
                style["accent"] = (pr, pg, pb)
        r = sum(p[0] for p in all_pixels) // len(all_pixels)
        g = sum(p[1] for p in all_pixels) // len(all_pixels)
        b = sum(p[2] for p in all_pixels) // len(all_pixels)
        style["bg_mid"]  = (max(0, r // 3), max(0, g // 3), max(0, b // 3))
        style["bg_dark"] = (max(0, r // 6), max(0, g // 6), max(0, b // 6))
    except Exception:
        pass
    return style


# ─────────────────────────────────────────────────────────────────────────────
def _find_bold_font(size: int) -> ImageFont.FreeTypeFont:
    """Ищет жирный шрифт для macOS / Windows / Linux."""
    candidates = [
        # macOS
        "/Library/Fonts/Arial Bold.ttf",
        "/Library/Fonts/Arial.ttf",
        "/System/Library/Fonts/Supplemental/Impact.ttf",
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
        "/System/Library/Fonts/HelveticaNeue.ttc",
        # Windows
        "C:/Windows/Fonts/arialbd.ttf",
        "C:/Windows/Fonts/impact.ttf",
        "C:/Windows/Fonts/verdanab.ttf",
        # Linux
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
    ]
    for p in candidates:
        if os.path.isfile(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    # Попытка найти любой .ttf в системных папках macOS
    for search_dir in ["/Library/Fonts", "/System/Library/Fonts/Supplemental"]:
        if os.path.isdir(search_dir):
            for fname in os.listdir(search_dir):
                if "bold" in fname.lower() and fname.lower().endswith(".ttf"):
                    try:
                        return ImageFont.truetype(os.path.join(search_dir, fname), size)
                    except Exception:
                        pass
    return ImageFont.load_default()


# ─────────────────────────────────────────────────────────────────────────────
def _render_thumbnail(
    frame_path: str | None, caption: str, index: int,
    out_dir: str, ref_style: dict, size: tuple[int, int] = (1280, 720),
) -> str:
    W, H   = size
    accent = ref_style.get("accent",  (45, 140, 45))
    bg_d   = ref_style.get("bg_dark", (10, 25, 10))
    bg_m   = ref_style.get("bg_mid",  (20, 50, 20))

    canvas = Image.new("RGB", size, bg_d)
    draw   = ImageDraw.Draw(canvas)

    # Левая часть: градиент в зелёных тонах
    left_w = int(W * 0.48)
    for x in range(left_w):
        t = x / left_w
        r = int(bg_d[0] + (bg_m[0] - bg_d[0]) * t)
        g = int(bg_d[1] + (bg_m[1] - bg_d[1]) * t)
        b = int(bg_d[2] + (bg_m[2] - bg_d[2]) * t)
        draw.line([(x, 0), (x, H)], fill=(r, g, b))

    ar, ag, ab = accent
    for i, y in enumerate(range(20, H - 20, 55)):
        alpha = 0.08 + 0.04 * (i % 3)
        lc = (int(ar * alpha), int(ag * alpha), int(ab * alpha))
        draw.line([(0, y), (left_w, y)], fill=lc, width=1)

    for y in range(H):
        t = abs(y - H // 2) / (H // 2)
        draw.line([(left_w, y), (left_w + 6, y)],
                  fill=(min(255, ar), min(255, ag), min(255, ab)))

    # Правая часть: кадр из видео
    right_w = W - left_w
    if frame_path and os.path.isfile(frame_path):
        try:
            doc = Image.open(frame_path).convert("RGB")
            dw, dh = doc.size
            sc = max(right_w / dw, H / dh)
            doc = doc.resize((int(dw * sc), int(dh * sc)), Image.LANCZOS)
            cx = (doc.width  - right_w) // 2
            cy = (doc.height - H)       // 2
            doc = doc.crop((cx, cy, cx + right_w, cy + H))
            canvas.paste(doc, (left_w, 0))
        except Exception as e:
            print(f"[thumb] frame paste error: {e}")

    # Тёмный градиент снизу для текста
    grad_h   = int(H * 0.52)
    grad_top = H - grad_h
    overlay  = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    od       = ImageDraw.Draw(overlay)
    for y in range(grad_top, H):
        t     = (y - grad_top) / grad_h
        alpha = int(235 * (t ** 0.65))
        od.line([(0, y), (W, y)], fill=(0, 0, 0, alpha))
    canvas = canvas.convert("RGBA")
    canvas = Image.alpha_composite(canvas, overlay).convert("RGB")
    draw   = ImageDraw.Draw(canvas)

    # Разбиваем текст на строки
    words = caption.upper().split()
    lines: list[str] = []
    cur   = ""
    for w in words:
        test = (cur + " " + w).strip()
        if len(test) > 20:
            if cur:
                lines.append(cur)
            cur = w
        else:
            cur = test
    if cur:
        lines.append(cur)
    lines = lines[:3]
    n_lines = len(lines)

    font_sz  = 110 if n_lines == 1 else (95 if n_lines == 2 else 80)
    font_use = _find_bold_font(font_sz)
    line_h   = int(font_sz * 1.18)

    # Цвета строк: акцентный → белый → оранжевый
    LINE_COLORS = [accent, (255, 255, 255), (212, 118, 42)]

    text_y = H - n_lines * line_h - 28
    PAD_X  = 22

    for li, ln in enumerate(lines):
        ty  = text_y + li * line_h
        col = LINE_COLORS[li % len(LINE_COLORS)]
        for dx in range(-6, 7, 2):
            for dy in range(-6, 7, 2):
                if dx or dy:
                    draw.text((PAD_X + dx, ty + dy), ln, font=font_use, fill=(0, 0, 0))
        draw.text((PAD_X, ty), ln, font=font_use, fill=col)

    safe = re.sub(r'[^\w\s-]', '', caption)[:50].strip().replace(" ", "_")
    out  = os.path.join(out_dir, f"thumb_{index+1:02d}_{safe}.jpg")
    canvas.save(out, "JPEG", quality=95)
    return out
