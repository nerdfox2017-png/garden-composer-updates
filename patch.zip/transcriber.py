"""transcriber.py — транскрипция через AssemblyAI."""
import json
import os
import subprocess
import tempfile
import time
from typing import Any

import config as _cfg               # динамическая ссылка — ключ читается в момент вызова
from config import CACHE_DIR
from utils import ensure_dirs, log_exception, setup_logger

logger = setup_logger(__name__)


def _extract_audio_wav(video_path: str) -> str | None:
    """Extract 16kHz mono WAV — universally supported by AssemblyAI SDK."""
    try:
        tmp = tempfile.mktemp(suffix=".wav")
        r = subprocess.run(
            ["ffmpeg", "-y", "-i", video_path,
             "-vn", "-ar", "16000", "-ac", "1", tmp],
            capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=300)
        if r.returncode == 0 and os.path.isfile(tmp) and os.path.getsize(tmp) > 1024:
            size_kb = os.path.getsize(tmp) // 1024
            print(f"[transcriber] Audio WAV: {size_kb} KB")
            return tmp
        print(f"[transcriber] ffmpeg WAV failed: {r.stderr[-200:]}")
        return None
    except Exception as exc:
        print(f"[transcriber] WAV extract error: {exc}")
        return None


def _transcribe_assemblyai(audio_path: str) -> list[dict[str, Any]] | None:
    """Transcribe via AssemblyAI SDK — same proven pattern as working software."""
    api_key = _cfg.ASSEMBLYAI_API_KEY   # читаем в момент вызова
    if not api_key:
        print("[transcriber] No AssemblyAI key — skipping.")
        return None

    import assemblyai as aai
    aai.settings.api_key = api_key
    size_kb = os.path.getsize(audio_path) // 1024
    print(f"[transcriber] AssemblyAI key: {api_key[:6]}...  file: {os.path.basename(audio_path)} ({size_kb} KB)")

    # AssemblyAI API now requires speech_models to be specified explicitly
    sm = ["universal-2"]
    configs = [
        aai.TranscriptionConfig(speech_models=sm, language_detection=True,
                                auto_highlights=False, content_safety=False, iab_categories=False),
        aai.TranscriptionConfig(speech_models=sm, language_code="en",
                                auto_highlights=False, content_safety=False, iab_categories=False),
        aai.TranscriptionConfig(speech_models=sm, language_code="es",
                                auto_highlights=False, content_safety=False, iab_categories=False),
        aai.TranscriptionConfig(speech_models=sm,
                                auto_highlights=False, content_safety=False, iab_categories=False),
    ]

    for i, cfg in enumerate(configs):
        max_tries = 2
        for attempt in range(1, max_tries + 1):
            try:
                print(f"[transcriber] AssemblyAI config {i+1}/4 attempt {attempt}...")
                transcriber = aai.Transcriber(config=cfg)
                result = transcriber.transcribe(str(audio_path))

                if result.status == aai.TranscriptStatus.error:
                    print(f"[transcriber] AssemblyAI error: {result.error}")
                    break  # next config

                # Success — convert words → 5-second chunks
                segments: list[dict] = []
                lang = getattr(result, "language_code", None) or "en"

                if result.words:
                    chunk: list[str] = []
                    chunk_start = 0.0
                    for word in result.words:
                        if not chunk:
                            chunk_start = word.start / 1000.0
                        chunk.append(word.text)
                        if word.end / 1000.0 - chunk_start >= 5.0 or word is result.words[-1]:
                            segments.append({
                                "start":    chunk_start,
                                "end":      word.end / 1000.0,
                                "text":     " ".join(chunk),
                                "language": lang,
                            })
                            chunk = []
                elif result.text:
                    segments = [{"start": 0.0, "end": 60.0,
                                 "text": result.text, "language": lang}]

                if segments:
                    print(f"[transcriber] AssemblyAI OK: {len(segments)} segments, lang={lang}")
                    return segments

                print(f"[transcriber] AssemblyAI returned empty transcript.")
                break

            except Exception as exc:
                err_msg = str(exc)
                print(f"[transcriber] AssemblyAI exception: {err_msg}")
                if attempt < max_tries and any(x in err_msg.lower()
                                               for x in ("connect", "timeout", "disconnect")):
                    print(f"[transcriber] Retrying in 15s...")
                    time.sleep(15)
                else:
                    break

    return None


def transcribe(video_path: str, no_cache: bool = False) -> list[dict[str, Any]]:
    asm_key = _cfg.ASSEMBLYAI_API_KEY   # читаем в момент вызова
    asm_hint = (asm_key[:6] + "...") if asm_key else "EMPTY"
    print(f"[transcriber] ASSEMBLYAI_KEY={asm_hint}")

    ensure_dirs(CACHE_DIR)
    base  = os.path.splitext(os.path.basename(video_path))[0]
    cache = os.path.join(CACHE_DIR, f"{base}_transcript.json")

    if not no_cache and os.path.isfile(cache):
        try:
            with open(cache, encoding="utf-8") as f:
                data = json.load(f)
            if data:
                print(f"[transcriber] Loaded from cache: {cache}")
                return data
        except Exception:
            pass

    print("[transcriber] Extracting audio via ffmpeg...")
    audio_path = _extract_audio_wav(video_path)

    segments = None
    if audio_path:
        segments = _transcribe_assemblyai(audio_path)
        try:
            os.remove(audio_path)
        except Exception:
            pass

    if not segments:
        raise RuntimeError("Transcription failed. Check ASSEMBLYAI_API_KEY and internet connection.")

    with open(cache, "w", encoding="utf-8") as f:
        json.dump(segments, f, ensure_ascii=False, indent=2)
    print(f"[transcriber] Saved {len(segments)} segments to cache.")
    return segments
