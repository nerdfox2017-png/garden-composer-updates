"""
updater.py — Проверка и установка обновлений Garden Infographic Composer
Обновления хостятся на GitHub, скачиваются без git и без сторонних зависимостей.
"""
from __future__ import annotations

import hashlib
import json
import urllib.request
import urllib.error
import zipfile
import io
from pathlib import Path
from typing import Optional

# ── Конфиг репозитория ────────────────────────────────────────────────────────
# Заменить на свой репо после создания на GitHub
GITHUB_REPO      = "nerdfox2017-png/garden-composer-updates"
VERSION_JSON_URL = f"https://raw.githubusercontent.com/{GITHUB_REPO}/main/version.json"
VERSION_API      = f"https://api.github.com/repos/{GITHUB_REPO}/contents/version.json"
PATCH_URL        = f"https://raw.githubusercontent.com/{GITHUB_REPO}/main/patch.zip"

# ── Защищённые пути — никогда не перезаписываются при обновлении ──────────────
SKIP_ON_INSTALL = {
    "settings.json",   # настройки пользователя
    "venv/",           # виртуальное окружение Python
    "cache/",          # кеш транскрипций и storyboard
    "generated/",      # сгенерированные изображения
    "output/",         # готовые видео
    "logs/",           # логи
    "input/",          # входные видеофайлы пользователя
    "publisher.py",    # инструмент публикации (dev-файл)
}


# ── Вспомогательные функции ───────────────────────────────────────────────────

def _md5(path: Path) -> str:
    h = hashlib.md5()
    h.update(path.read_bytes())
    return h.hexdigest()


def _fetch(url: str, token: str | None = None, timeout: int = 15) -> bytes:
    headers = {"User-Agent": "garden-composer-updater/1.0"}
    if token:
        headers["Authorization"] = f"token {token}"
    req = urllib.request.Request(url, headers=headers)
    return urllib.request.urlopen(req, timeout=timeout).read()


def _fetch_version_json(token: str | None = None) -> dict:
    """Получает version.json через GitHub API (надёжнее raw CDN при кешировании)."""
    import base64
    headers = {
        "User-Agent": "garden-composer-updater/1.0",
        "Accept": "application/vnd.github.v3+json",
    }
    if token:
        headers["Authorization"] = f"token {token}"
    req = urllib.request.Request(VERSION_API, headers=headers)
    data = json.loads(urllib.request.urlopen(req, timeout=15).read())
    return json.loads(base64.b64decode(data["content"]))


def _version_tuple(v: str) -> tuple[int, ...]:
    """Конвертирует "1.2" → (1, 2) для сравнения версий."""
    try:
        return tuple(int(x) for x in v.strip().split("."))
    except Exception:
        return (0,)


def _is_protected(name: str) -> bool:
    """Возвращает True если файл/папка защищены от перезаписи."""
    for protected in SKIP_ON_INSTALL:
        if name == protected or name.startswith(protected):
            return True
    return False


# ── Публичный API ─────────────────────────────────────────────────────────────

def check_updates(root: Path, local_version: str = "0") -> dict:
    """
    Проверяет наличие обновлений на GitHub.

    Args:
        root:          корневая папка приложения (Path(__file__).parent)
        local_version: текущая версия приложения (например "1.1")

    Returns:
        {
          'available':       bool,
          'version':         str,        # версия на сервере
          'changelog':       [str, ...], # список изменений
          'changed_files':   [str, ...], # файлы которые изменились
          'requires_restart':bool,
          'error':           str | None,
        }
    """
    token = None  # опционально: положить GITHUB_TOKEN в settings.json

    try:
        data = _fetch_version_json(token)
    except Exception:
        # Фоллбэк на raw CDN если GitHub API недоступен
        try:
            raw  = _fetch(VERSION_JSON_URL, token)
            data = json.loads(raw)
        except Exception as exc:
            return {"available": False, "error": str(exc)}

    remote_version = data.get("version", "0")

    # Сравниваем MD5 файлов — это единственный надёжный критерий наличия обновления.
    # Версионная строка используется только для отображения, не для блокировки.
    remote_files = data.get("files", {})
    changed = []
    for rel, remote_md5 in remote_files.items():
        local_path = root / rel
        if not local_path.exists():
            changed.append(rel)
        elif _md5(local_path) != remote_md5:
            changed.append(rel)

    print(f"[updater] remote={remote_version} local={local_version} "
          f"files={len(remote_files)} changed={len(changed)}")

    return {
        "available":        len(changed) > 0,
        "version":          remote_version,
        "changelog":        data.get("changelog", []),
        "changed_files":    changed,
        "requires_restart": data.get("requires_restart", True),
        "error":            None,
    }


def install_update(root: Path, progress_cb=None) -> dict:
    """
    Скачивает patch.zip с GitHub и устанавливает обновление.

    Args:
        root:        корневая папка приложения
        progress_cb: функция progress_cb(msg: str) для отображения прогресса

    Returns:
        {'ok': bool, 'installed': [str, ...], 'requires_restart': bool, 'error': str | None}
    """
    def log(msg: str):
        if progress_cb:
            progress_cb(msg)

    token = None
    requires_restart = True

    try:
        log("Загрузка version.json...")
        try:
            data = _fetch_version_json(token)
            requires_restart = data.get("requires_restart", True)
        except Exception as ve:
            log(f"Предупреждение: {ve} — продолжаем")

        log("Скачивание патча...")
        patch_bytes = _fetch(PATCH_URL, token, timeout=120)
        log(f"Скачано: {len(patch_bytes) / 1024:.0f} КБ")

        log("Установка файлов...")
        installed = []
        with zipfile.ZipFile(io.BytesIO(patch_bytes)) as zf:
            for name in zf.namelist():
                if _is_protected(name):
                    continue
                dest = root / Path(name)
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(zf.read(name))
                installed.append(name)
                log(f"  ✓ {name}")

        log(f"Установлено файлов: {len(installed)}")

        # Очищаем __pycache__ — иначе Python запустит старый .pyc
        import shutil
        removed_cache = 0
        for cache_dir in root.rglob("__pycache__"):
            try:
                shutil.rmtree(cache_dir)
                removed_cache += 1
            except Exception:
                pass
        if removed_cache:
            log(f"Очищено кешей: {removed_cache}")

        return {
            "ok":               True,
            "installed":        installed,
            "requires_restart": requires_restart,
            "error":            None,
        }

    except Exception as exc:
        return {
            "ok":               False,
            "installed":        [],
            "requires_restart": False,
            "error":            str(exc),
        }
