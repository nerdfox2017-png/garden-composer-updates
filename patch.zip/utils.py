"""utils.py — вспомогательные функции."""
import logging
import os
import re
import sys
import traceback


class _DynamicStderrHandler(logging.StreamHandler):
    """Always writes to current sys.stderr — works even if stderr is None at startup."""
    @property  # type: ignore[override]
    def stream(self):
        s = sys.stderr
        if s is None:
            s = getattr(sys, "__stderr__", None)
        return s

    @stream.setter
    def stream(self, value):
        pass  # ignore captured stream; always use live sys.stderr

    def emit(self, record):
        if self.stream is None:
            return  # nowhere to write — swallow silently
        try:
            super().emit(record)
        except Exception:
            pass  # never crash the pipeline over a log message


def setup_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = _DynamicStderrHandler()
        handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
        logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    return logger


def ensure_dirs(*dirs: str) -> None:
    for d in dirs:
        os.makedirs(d, exist_ok=True)


def sanitize_filename(name: str) -> str:
    return re.sub(r'[^\w\-_.]', '_', name)


def format_duration(seconds: float) -> str:
    m = int(seconds) // 60
    s = int(seconds) % 60
    return f"{m}m {s}s"


def log_exception(logger: logging.Logger, msg: str) -> None:
    logger.error(f"{msg}\n{traceback.format_exc()}")
